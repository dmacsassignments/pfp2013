#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define n 2000
#define m 3000

void main()
{
  double **a, **b, c;
  register double norm;
  register int i, j, l;
  
  a = (double**)malloc(n*sizeof(double*));
  b = (double**)malloc(n*sizeof(double*));

  for(i=0; i<n; i++)
    {
      a[i] = (double*)malloc(m*sizeof(double));
      for(j=0; j<n; j+=4) 
       { a[i][j] = drand48();
         a[i][j+1] = drand48();
         a[i][j+2] = drand48();
         a[i][j+3] = drand48();
        }
    }
    
  for(i=0; i<n; i++) b[i] = (double*)calloc(m, sizeof(double));
 
  c = 13.0;

  for(i=0; i<n; i++)
    {
           double * bb = (b[i]) ;
            double * aa = (a[i]);
      for( j=0; j<m; j+=5)
      {    double a = bb[j];
            double b = bb[j+1];
          double e = bb[j+2];
          double d = bb[j+3];
          double f = bb[j+4];
          double a1 = aa[j];
          double a2 = aa[j+1];
          double a3 = aa[j+2];
            double a4 = aa[j+3];
        double a5 = aa[j+4];
	  for(l=1 ;l<=30; l+=6)	    
	   { 
                 a = (c*a) + a1;
                 b = (c*b) + a2;
                 e = (c*e) + a3;
                 d = (c*d) + a4;
                f = (c*f) + a5;
                 a = (c*a) + a1;
                 b = (c*b) + a2;
                 e = (c*e) + a3;
                 d = (c*d) + a4;
                f = (c*f) + a5;

                 a = (c*a) + a1;
                 b = (c*b) + a2;
                 e = (c*e) + a3;
                 d = (c*d) + a4;
                 f = (c*f) + a5;

                 a = (c*a) + a1;
                 b = (c*b) + a2;
                 e = (c*e) + a3;
                 d = (c*d) + a4;
               f = (c*f) + a5;

                 a = (c*a) + a1;
                 b = (c*b) + a2;
                 e = (c*e) + a3;
                 d = (c*d) + a4;
                f = (c*f) + a5;

                 a = (c*a) + a1;
                 b = (c*b) + a2;
                 e = (c*e) + a3;
                 d = (c*d) + a4;
               f = (c*f) + a5;
                 
          }  bb[j] = a; bb[j+1] = b; bb[j+2] = e; bb[j+3] = d;
               bb[j+4] = f; 
      }	      
    }

  norm = 0.0;

  for(i=0; i<n; i++)
  { double *bb = b[i];
    for(j=0; j<m; j++)
    { double x = bb[j];
     double        y =  x * x;
       norm = (norm + y) ;
         
          
        }
}       
  printf("norm: %10.4e    Value: %10.4e\n",norm, b[10][10]);
}
