#include<stdio.h>
int main()
{ int array[100000000];
  int sum = 0,i;
  for(i=0;i<100000000;i++)
  { array[i]=rand(); }

 for(i=0;i<100000000;i++)
 { sum += array[i]; }
 return 0;
}
