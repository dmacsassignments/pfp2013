#include<stdio.h>
int main()
{ int array[100000000];
  int sum = 0,i, sum1=0,sum2=0,sum3=0,sum4=0,sum5=0;
  for(i=0;i<100000000;i++)
  { array[i]=rand(); }

 for(i=0;i<100000000;i+=5)
 { sum += array[i]; sum1 += array[i+1]; sum2 += array[i+2]; sum3 += array[i+3]; sum4 += array[i+4]; //sum5 += array[i+5];
   sum = sum + sum1 + sum2 + sum3 + sum4 ;}
 return 0;
}
