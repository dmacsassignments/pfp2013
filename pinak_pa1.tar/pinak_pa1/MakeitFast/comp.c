/*
 * comp.c - contains the function superslow that you need to optimize
 *
 *
 */

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


/* f(x, i, j) multiplies or divides by a sine expression depending
   on i + j being odd or even
*/
inline double f(double x, int i, int j)
{
    if((i + j) & 0x1)
        return x / (1 + sin(M_PI/(i+1)));
    else
        return x * sin(M_PI/(i+1));
}

/* This is the function you need to optimize. It takes one
   square matrix as input
*/
void superslow(smat_t *a)
{
    int i, j;
    double x,x2;

    // i is the column of a we're computing right now
    for(i = 0; i < a->n; i++)
    {
        // j is the row of a we're computing right now
        for(j = 0; j < a->n; j++)
        {            
                // First, compute f(A) for the element of a in question
			x = get_elt(a, i, j);
                x = f(x, i, j);
                
                // Add this to the value of a we're computing and store it
                x2 = get_elt(a, i, j);
			x = x * x2;
                set_elt(a, i, j, x);
            
        }
    }
}

void superslow1(smat_t *a)
{
    int i, j;
    double x,x2;

    // i is the column of a we're computing right now
    for(i = 0; i < a->n; i++)
    {
        // j is the row of a we're computing right now
        for(j = 0; j < a->n; j++)
        {            
                // First, compute f(A) for the element of a in question
//			x = get_elt(a, i, j);
	          x = (a->mat)[(i*(a->n))+j];
                x2 = f(x, i, j);
                
                // Add this to the value of a we're computing and store it
               // x2 = get_elt(a, i, j);
			x = x * x2;
                //set_elt(a, i, j, x);
                (a->mat)[(i*(a->n))+j] = x;
            
        }
    }
}

void superslow2(smat_t *a)
{
    int i, j;
    double x,x2;
    int n = a->n;
    double* mat = a->mat;
    int k;
    // i is the column of a we're computing right now
    for(i = 0; i < n; i++)
    {
        // j is the row of a we're computing right now
        for( k = i*n,j = 0; j < n; j++)
        {       // k = i*n;    
                // First, compute f(A) for the element of a in question
//			x = get_elt(a, i, j);
	          x = f((mat)[(k)+j],i,j);
    //            x2 = f(x, i, j);
                
                // Add this to the value of a we're computing and store it
               // x2 = get_elt(a, i, j);
		//	x = x * x2;
                //set_elt(a, i, j, x);
                (mat)[(k)+j] *= x;
            
        }
    }
}


void superslow3(smat_t *a)
{
    int i, j;
//    double x,x2;
    int n = a->n;
    double* mat = a->mat;
    int k;
    // i is the column of a we're computing right now
    for(i = 0; i < n; i++)
    {             double sin1 = sin(M_PI/(i+1));
                  double sin2 = 1+sin(M_PI/(i+1));
        // j is the row of a we're computing right now
        for(k=i*n, j = 0; j < n; j++)
        {           double *m = &mat[k]; 
                m[j] *= m[j]*sin1;
                     j++;
                          m[j] *= m[j] /sin2;
            }
                 i++;
         sin1 = sin(M_PI/(i+1)); 
         sin2 = 1+sin(M_PI/(i+1));
       for(k=i*n, j = 0; j < n; j++)
        {        double *m = &mat[k];          
                 m[j] *= (m)[j] / sin2;
                   j++;
                           (m)[j] *= (m)[j]*sin1;
             }
   }
}
 




void superslow4(smat_t *a)
{
    int i, j;
    int n = a->n;
    double* mat = a->mat;
    int k;
    // i is the column of a we're computing right now
    for(i = 0; i < n; i++)
    {             double sin1 = sin(M_PI/(i+1));
                  double sin2 = 1+sin1;
        // j is the row of a we're computing right now
        for(k=i*n, j = 0; j < n; j++)
        {           double *m = &mat[k]; 
                m[j] *= m[j]*sin1;
                     j++;
                          m[j] *= m[j] /sin2;
                     j++;
                   m[j] *= m[j]*sin1; j++;
                   m[j] *= m[j] /sin2; j++;
                        m[j] *= m[j]*sin1; j++;
                   m[j] *= m[j] /sin2;


            }
                 i++;
         sin1 = sin(M_PI/(i+1)); 
         sin2 = 1+sin1;
       for(k=i*n, j = 0; j < n; j++)
        {        double *m = &mat[k];          
                 m[j] *= (m)[j] / sin2;
                   j++;
                           (m)[j] *= (m)[j]*sin1; j++;
                  m[j] *= (m)[j] / sin2; j++;
                  (m)[j] *= (m)[j]*sin1; j++;
                      m[j] *= (m)[j] / sin2; j++;
                 (m)[j] *= (m)[j]*sin1;
             } 
  }
}

void superslow5(smat_t *a)
{
    int i, j;
    int n = a->n;
    double* mat = a->mat;
    int k;
    // i is the column of a we're computing right now
    for(i = 0; i < n; i++)
    {             double sin1 = sin(M_PI/(i+1));
                  double sin2 = 1+sin1;
        // j is the row of a we're computing right now
        for( k=i*n,j = 0; j < n; j++)
        {           double *m = &mat[k]; 
                m[j] *= m[j]*sin1;
                     j++;
                          m[j] *= m[j] /sin2;
            }
                 i++;
         sin1 = sin(M_PI/(i+1)); 
         sin2 = 1+sin1;
       for(k=i*n, j = 0; j < n; j++)
        {        double *m = &mat[k];          
                 m[j] *= (m)[j] / sin2;
                   j++;
                           (m)[j] *= (m)[j]*sin1;
             }
   }
}
 

inline void superslow6(smat_t *a)
{
   register int i, j, l;
   register const int n = a->n;
   register double* mat = a->mat;
   register int k;
    // i is the column of a we're computing right now
    for(i = 0, k=0; i < n; i++, k+=n)
    {  const  double sin1 = sin(M_PI/(i+1));
        const double sin2 =1/( 1+sin1);
             register double *m = &mat[k];
            

        // j is the row of a we're computing right now
        for( j = (i & 0x1), l = (j ^ 0x1); j < n; j+=20, l+=20)
        {    
              

         m[j] *= m[j]*sin1;
                m[j+2] *= m[j+2]*sin1;
               m[j+4] *= m[j+4]*sin1; m[j+6] *= m[j+6]*sin1; m[j+8] *= m[j+8] *sin1;
               m[j+10] *= m[j+10]*sin1;
m[j+12] *= m[j+12]*sin1;m[j+14] *= m[j+14]*sin1;m[j+16] *= m[j+16]*sin1;m[j+18] *= m[j+18]*sin1;
                m[l] *= m[l]*sin2;
                m[l+2] *= m[l+2]*sin2;
            m[l+4] *= m[l+4]*sin2; m[l+6] *= m[l+6]*sin2; m[l+8] *= m[l+8] *sin2;
              m[l+10] *= m[l+10]*sin2;
m[l+12] *= m[l+12]*sin2;m[l+14] *= m[l+14]*sin2;m[l+16] *= m[l+16]*sin2;m[l+18] *= m[l+18]*sin2;

         } 
   }
}
 

inline void superslow7(smat_t *a)
{
    register int i;
    register int j;
    register int l;
    const int n = a->n;
    register double* mat = a->mat;
    register int k;
    // i is the column of a we're computing right now
    for(i = 0, k=0; i < n; i++, k+=n)
    {           const  double sin1 = sin(M_PI/(i+1));
               const   double sin2 =1/( 1+sin1);
             register  double * m = &mat[k];
                    // int j,l;
        // j is the row of a we're computing right now
        for( j = (i & 0x1), l = (j ^ 0x1); j < n; j+=10, l+=10)
        {  register    double e1 = m[j]; 
            register   double e2 = m[j+2];
          register     double e3 = m[j+4];
           register    double e4 = m[j+6];
          register     double e5 = m[j+8];
          // register    double e6 = m[j+10];
          register    double o1 = m[l];
          register     double o2 = m[l+2];
           register  double o3 = m[l+4];
            register   double o4 = m[l+6];
            register      double o5 = m[l+8];
        //     register    double o6 = m[l+10];
                e1 *= e1*sin1;  
                e2 *= e2*sin1;
               e3 *= e3*sin1;
                e4 *= e4*sin1; e5 *= e5*sin1;
                    //e6 *= e6*sin1;
                o1 *= o1*sin2;
                o2 *= o2*sin2;
                o3 *= o3*sin2;
                o4 *= o4*sin2; o5 *= o5*sin2;
                    //o6 *= o6*sin2;
                m[j] = e1; m[j+2] = e2; m[j+4] = e3; m[j+6] = e4; m[j+8]=e5;
              //    m[j+10] = e6;
                m[l] = o1; m[l+2] = o2; m[l+4] = o3; m[l+6] = o4; m[l+8]=o5;
            //      m[l+10] = o6;
         } 
   }
} 

/* Called by the driver to register your functions
 * Use add_function(func, description) to add your own functions
* 
 * Called by the driver to register your functions
 * Use add_function(func, description) to add your own functions
 */
void register_functions()
{
    // Registers comp_superslow with the driver
    add_function(&superslow, "superslow: original function");
	
    add_function(&superslow1, "superslow1: function calls to get and set element of a removed");
    
    add_function(&superslow2, "superslow2: ");
 //   add_function(&superslow2, "superslow2: computation distributed across two loop pairs");
    
    add_function(&superslow3, "superslow3: getting rid of call to f in addition to optimizations in superslow1");
    add_function(&superslow4, "superslow4: unrolled ");
    add_function(&superslow5, "superslow5: small modification over over superslow 3 ");
    add_function(&superslow6, "superslow6: one inner loop !! ");
    add_function(&superslow7, "superslow7: use more registers !! ");
      

	//Add your functions here
	//add_function(&superslow2, "superslow: Optimization X");
	
	
}
