

#include <stdio.h>
#include <math.h>
#include "rdtsc.h"


#define N 100000
 typedef float data_t;

inline void Unroll5(data_t* buffer)
{
data_t a = 0,a1,a2,a3,a4,a5; 

int x; 

//for (x=0; x<10000; x++)   
 //a += buffer[x]; 
 // Unrolled code by 4 (you will need to try with different degrees of unroll)
  a = a1= a2= a3= a4=a5=0;  
for (x=0; x<N; x+=6) {   
a += buffer[x];    
a1 += buffer[x+1];   
 a2 += buffer[x+2]; 
   a3 += buffer[x+3];
   a4 += buffer[x+4];
   a5 += buffer[x+5];  
} 
a=a+a1+a2+a3+a4+a5; 
}
inline void Unroll2(float *y)
{
	float t1;
        int i;   
	for ( i = 0; i < N; i=i+2)
	{
		y[i] = 0;
		y[i+1] = 0;
		//y[i+2] = 0;
		//y[i+3] = 0;
	}
}


inline void Unroll3(float *y)
{
	float t1;
        int i;
        for(i=0;i<N;i+=3)       
	{
		y[i] = 0;
               y[i+1] = 0;
                y[i+2] = 0;
         }
}                
inline data_t Unroll0(data_t *buffer)
{
                    int i;
             for(i=1;i<N;i++)
                     buffer[i]+=buffer[i-1]; 
             return buffer[i-1];             
}


int main()
{	
	 data_t *buffer;
        data_t check;
	tsc_counter a, b;
	double cycles, baseline;
         int i;
	//N is a define
	buffer = (data_t*)malloc(sizeof(data_t)*N);
        float *x = (float*)_mm_malloc(sizeof(float)*N,16);
	data_t *y = (data_t*)_mm_malloc(sizeof(data_t)*N,16);
	//y_vec = (float*)malloc(sizeof(float)*N,16);

	if ( x == NULL || y == NULL)
		return 1;

	//init vars
	for ( i = 0; i<N; i++){
			buffer[i] = rand();	
	}
			

	

	
	//-----------------------------------------Timing 1
	//warm up	

	//-----------------No Vec Warmup-------------------
	//lookup task b from the HW here
	//
	//State the Asm. Instructions used by the compiler as a comment here:
	//
	// <--- List of Instructions --->
	//-----------------------------------------Timing 1
	//warm up
		//Unroll0(x);
                Unroll6(buffer); 
              check =  Unroll0(buffer);     

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	//for( i=0; i<NUM_RUNS;i++)
	 
		Unroll6(buffer);
	
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a));// / ((double) NUM_RUNS);
	printf("%lf cycles through partially unrolled code - %1.0f\n",cycles,y[0]);


        if(check == buffer[N-1])
                       printf("Check success\n");
        else
                     printf("Check failed\n");  
           


/*      

	//-----------------------------------------Timing 2
	//warm up
		Unroll4(buffer,a);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(int i=0; i<NUM_RUNS; ++i)
	{ 
		Unroll4(buffer,a);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through vectorized code - %1.0f\n",cycles,baseline/cycles,y_vec[0]);
	
*/	

	//_mm_free(M);
	free(buffer);
	_mm_free(y);
	_mm_free(x);


	return 0;
}

