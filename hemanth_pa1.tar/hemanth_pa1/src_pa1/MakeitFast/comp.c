/*
 * comp.c - contains the function superslow that you need to optimize
 *
 *
 */

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


/* f(x, i, j) multiplies or divides by a sine expression depending
   on i + j being odd or even
*/
double f(double x, int i, int j)
{
    if((i + j) & 0x1)
        return x / (1 + sin(M_PI/(i+1)));
    else
        return x * sin(M_PI/(i+1));
}

/* This is the function you need to optimize. It takes one
   square matrix as input
*/
void superslow(smat_t *a)
{
    int i, j;
    double x,x2;

    // i is the column of a we're computing right now
    for(i = 0; i < a->n; i++)
    {
        // j is the row of a we're computing right now
        for(j = 0; j < a->n; j++)
        {            
                // First, compute f(A) for the element of a in question
			x = get_elt(a, i, j);
                x = f(x, i, j);
                
                // Add this to the value of a we're computing and store it
                x2 = get_elt(a, i, j);
			x = x * x2;
                set_elt(a, i, j, x);
            
        }
    }
}

void superslow_opt1(smat_t *a)
{
    int i, j,n=a->n;
    double x,x2;
    for(i = 0; i < n; i++)
    {
        for(j = 0; j < n; j++)
        {            
                // First, compute f(A) for the element of a in question
			x = get_elt(a, i, j);
                x2 = f(x, i, j);
                //x2 = get_elt(a, i, j);
			x = x * x2;
                set_elt(a, i, j, x);
        }
    }
}

void superslow_opt2(smat_t *a)
{
    int i, j,n=a->n;
    double *x,x2;
    for(i = 0; i < n; i++)
    {   x = get_row(a,i);
        for(j = 0; j < n; j++)
        {            
            x2 = f(x[j],i,j);
            x[j] *= x2;
                
        }
        set_row(a,i,x);
    }
}
        
void superslow_opt3(smat_t *a)
{
     
     int i,j;register int n=a->n;double *curr;
     register double *x,sin1,sin2,sin3,sin4;
    register double *x2,*x1,*x3,*x4; 
    x = a->mat;
    for(i=0;i<n;i+=2){
         x[i]=0;x[i+1]=x[i+1]*x[i+1];;
     x[i+n]=x[i+n]*0.5*x[i+n];x[i+n+1]=x[i+n+1]*x[i+n+1];
    }
        //sval[i] = sin(M_PI/(i));
    for(i = 2; i < n; i+=2)
    {   //x = get_row(a,i);
      curr=x+i*n;
      sin1 = sin(M_PI/(i+1));
      sin2 = sin(M_PI/(i+2));
      sin3 = 1/(1+sin1);
      sin4 = 1/(1+sin2);
      for(j=0;j<n;j+=20)
      {   

         x1 = curr+j; //x2 = x4+j+1;
          x2 = curr+1+j;x3 = x1+2;
          x4 = x2+2;
         *x1 = *x1 * sin1* *x1;//x1+=4;
         *x2 =*x2 * sin3 * *x2;x1+=4;//x2+=4;
         *x3 = *x3 * (sin1* *x3);x2+=4;//x3+=4;
         *x4 =*x4 * (sin3 * *x4);x3+=4;//x4+=4;
         *x1 = *x1 * sin1* *x1;x4+=4;//x1+=4;
         *x2 =*x2 * sin3 * *x2;x1+=4;//x2+=4;
         *x3 = *x3 * (sin1* *x3);x2+=4;//x3+=4;
         *x4 =*x4 * (sin3 * *x4);x3+=4;//x4+=4;
         *x1 = *x1 * sin1* *x1;x4+=4;//x1+=4;
         *x2 =*x2 * sin3 * *x2;x1+=4;//x2+=4;
         *x3 = *x3 * (sin1* *x3);x2+=4;//x3+=4;
         *x4 =*x4 * (sin3 * *x4);x3+=4;//x4+=4;
         *x1 = *x1 * sin1* *x1;x4+=4;//x1+=4;
         *x2 =*x2 * (sin3 * *x2);x1+=4;//x2+=4;
         *x3 = *x3 * (sin1* *x3);x2+=4;//x3+=4;
         *x4 =*x4 * (sin3 * *x4);//x4+=4;
         *x1 = *x1 * (sin1* *x1);x3+=4;//x1+=4;
         *x2 =*x2 * sin3* *x2;x4+=4;//x2+=4;//x2--;
         *x3 = *x3 * (sin1* *x3);
         *x4 =*x4 * (sin3 * *x4);//x2--;
         //*x2 = x[i*n+j];i
         //*x2 = *x2 * sin1*(*x2);
         //x2 = x+(i+1)*n+j+1;
         x4 =x1+(n+3);x3 = x2+n+1;  
         //x2 = x4-2;x1 = x3-2;
         //x1 = x3+n;
         //*x2  =  (*x2 * sin4) * *x2;x2++;
         *x4 = *x4 * (sin2 * *x4);
         x1 = x3-2;
         //x3 = x1+n+2;
          x4-=4;
         //x2 = x3-1; x1=x4+1; 
         //*x2 = x[(i+1)*n+j];
         *x3  =  (*x3 * sin4) * *x3;
          x2 = x4 + 2;
          x3-=4;//x3++;
         *x2 = *x2 * (sin2* *x2);//x2-=4;
         *x1  =  *x1 * (sin4 * *x1);x2-=4;//x1-=4;//x3++;
         *x4 = *x4 * (sin2* *x4);x1-=4;//x4-=4;
         *x3  =  *x3 * sin4 * *x3;x4-=4;//x3-=4;
         *x2 = *x2 * (sin2* *x2);x3-=4;//x2-=4;
         *x1  =  *x1 * (sin4 * *x1);x2-=4;//x1-=4;//x3++;
         *x4 = *x4 * (sin2* *x4);x1-=4;//x4-=4;
         *x3  =  *x3 * sin4 * *x3;x4-=4;//x3-=4;
         *x2 = *x2 * (sin2* *x2);x3-=4;//x2-=4;
         *x1  =  *x1 * (sin4 * *x1);x2-=4;//x1-=4;//x3++;
         *x4 = *x4 * (sin2* *x4);x1-=4;//x4-=4;
         *x3  =  *x3 * sin4 * *x3;x4-=4;//x3-=4;
         *x2 = *x2 * (sin2* *x2);//x3-=4;//x2-=4;
         *x1  =  *x1 * sin4 * *x1;x3-=4;//x1-=4;//x3++;
         *x4 = *x4 * (sin2* *x4);x2-=4;//x4-=4;
         *x3  =  *x3 * sin4 * *x3;x1-=4;//x3-=4;//x3++;
         *x2 = *x2 * sin2 * *x2;
         *x1  =  *x1 * sin4 * *x1;//x3++;
          
      }
      //sin1 = sin(M_PI/(i+3));
      //sin2 = sin(M_PI/(i+4));
       //sin3 = 1/(1+sin1);
      //sin4 = 1/(1+sin2);
   }
}


/*
 * Called by the driver to register your functions
 * Use add_function(func, description) to add your own functions
 */
void register_functions()
{
    // Registers comp_superslow with the driver
    add_function(&superslow, "superslow: original function");
    add_function(&superslow_opt1, "superslow: Optimization on x");
    add_function(&superslow_opt2, "superslow: Optimization with row");
    add_function(&superslow_opt3, "superslow: Optimization with column");
	
	//Add your functions here
	//add_function(&superslow2, "superslow: Optimization X");
	
	
}
