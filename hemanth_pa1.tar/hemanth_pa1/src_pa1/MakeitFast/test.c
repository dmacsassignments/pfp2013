#include<stdio.h>
#include<math.h>


int main(){
int i;
for(i=1;i<=2;i++)
printf("%f \t",sin(M_PI/i));}
