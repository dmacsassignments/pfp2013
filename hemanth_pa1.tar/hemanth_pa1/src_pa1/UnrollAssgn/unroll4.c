#include <stdio.h>
#include <math.h>
#include "rdtsc.h"



#define N 10000

typedef double data_t;


inline data_t Unroll4(data_t* buffer)
{int x;
data_t a,a1,a2,a3,a4,a5,a6,a7,a8,a9;
a = a1= a2= a3=a4=0;
for (x=0; x<N; x+=4) {
a += buffer[x];
a1 += buffer[x+1];
a2 += buffer[x+2];
a3 += buffer[x+3];
//a4 += buffer[x+4];
}
a=a+a1+a2+a3;
return a;
}
inline data_t Unroll0(data_t* buffer)
{int x;
 data_t a= 0;
for (x=0; x<N; x++)
a += buffer[x];
return a;
}
 





int main()
{	
	 data_t * buffer,unrolled,original;
	tsc_counter a, b;
	double cycles, baseline;

	//N is a define
	buffer = (data_t*)malloc(sizeof(data_t)*N);
	//x = (float*)_mm_malloc(sizeof(float)*N,16);
	//y = (float*)_mm_malloc(sizeof(float)*N,16);
	//y_vec = (float*)_mm_malloc(sizeof(float)*N,16);

	if ( buffer == NULL)
		return 1;
        int i;          
	//init vars
	for ( i = 0; i<N; i++){
			buffer[i] = rand();	
	}
			

	

	
	//-----------------------------------------Timing 1
	//warm up	

	//-----------------No Vec Warmup-------------------
	//lookup task b from the HW here
	//
	//State the Asm. Instructions used by the compiler as a comment here:
	//
	// <--- List of Instructions --->
	//-----------------------------------------Timing 1
	//warm up
		unrolled=Unroll4(buffer);
           
                original = Unroll0(buffer); 

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	
		unrolled=Unroll4(buffer);
	
	RDTSC(b);
        if(original == unrolled){
	cycles = ((double)COUNTER_DIFF(b, a));
	printf("Results correct:%lf cycles  through partially unrolled code \n",cycles);
        }
        else
           printf("Result incorrect\n");  

   /*

	//-----------------------------------------Timing 2
	//warm up
		Unroll4(buffer,a);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(int i=0; i<NUM_RUNS; ++i)
	{ 
		Unroll4(buffer,a);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through vectorized code - %1.0f\n",cycles,baseline/cycles,y_vec[0]);
	*/
	

	free(buffer);
	//_mm_free(y);
	//_mm_free(x);


	return 0;
}

