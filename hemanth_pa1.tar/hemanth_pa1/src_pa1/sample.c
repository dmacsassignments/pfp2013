#include<stdio.h>
#include<math.h>


int main(){
int l;
double temp=1.0;
for(l=1;l<30;l++)
  temp+=pow(13.0,l);
printf("%f\n",temp);
}
