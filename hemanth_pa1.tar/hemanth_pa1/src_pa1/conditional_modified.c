#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define n 2000
#define m 3000
int main()
{
  register double **a, **b;
   register double temp=1.0;
  register int i, j,l;
  
  a = (double**)malloc(n*sizeof(double*));
  b = (double**)malloc(n*sizeof(double*));

    
  for(l=1; l<30; l++)
       temp += pow(13.0,l);

 register double  norm = 0.0;

  for(i=0; i<n; i++)
  {
      a[i] = (double*)malloc(m*sizeof(double));
   b[i] = (double*)calloc(m, sizeof(double));
    for(j=0; j<n; j+=2){
                a[i][j] = drand48();           
	        b[i][j] = temp*a[i][j];
                a[i][j+1] = drand48();           
                b[i][j+1] = -temp*a[i][j+1];
               norm = norm + (b[i][j]*b[i][j]) + (b[i][j+1]*b[i][j+1]);
      }
    for(;j<m;j+=2){
                b[i][j] = temp*a[i][j];
                b[i][j+1] = -temp*a[i][j+1];
                norm = norm + (b[i][j]*b[i][j]) + (b[i][j+1]*b[i][j+1]);

    }
  }
  printf("norm: %10.4e    Value: %10.4e\n",norm, b[10][10]);
}
