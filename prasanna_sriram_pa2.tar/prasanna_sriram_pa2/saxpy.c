/*
 * SAXPY
 */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
//#include <iacaMarks.h>
#include <tmmintrin.h>

#include "utils.h"
#include "rdtsc.h"

#define N 1024

// Procedure saxpy: Serial code (do not need to modify)

void saxpy(float a, float const * x, float const * y, float * z) {
  int i;
  for(i = 0; i < N; i++){
    z[i] = a*x[i] + y[i];
  }

}



// Procedure vec_saxpy: vector code (implement)

void vec_saxpy(float a, float const * x, float const * y, float * z) 
{ // IACA_START
  int length = N;
  __m128 a1 = _mm_set1_ps(a);
  for(;length!=0;length-=32){
   const __m128 x0 = _mm_load_ps(x);
   const __m128 x1 = _mm_load_ps(x+4);
   const __m128 x2 = _mm_load_ps(x+8);
   const __m128 x3 = _mm_load_ps(x+12);
   const __m128 x4 = _mm_load_ps(x+16);
   const __m128 x5 = _mm_load_ps(x+20);
   const __m128 x6 = _mm_load_ps(x+24);
   const __m128 x7 = _mm_load_ps(x+28);
    

   const __m128 z0 = _mm_add_ps(_mm_mul_ps(a1,x0),_mm_load_ps(y));
   const __m128 z1 = _mm_add_ps(_mm_mul_ps(a1,x1),_mm_load_ps(y+4));
   const __m128 z2 = _mm_add_ps(_mm_mul_ps(a1,x2),_mm_load_ps(y+8));
   const __m128 z3 = _mm_add_ps(_mm_mul_ps(a1,x3),_mm_load_ps(y+12));
   const __m128 z4 = _mm_add_ps(_mm_mul_ps(a1,x4),_mm_load_ps(y+16));
   const __m128 z5 = _mm_add_ps(_mm_mul_ps(a1,x5),_mm_load_ps(y+20));
   const __m128 z6 = _mm_add_ps(_mm_mul_ps(a1,x6),_mm_load_ps(y+24));
   const __m128 z7 = _mm_add_ps(_mm_mul_ps(a1,x7),_mm_load_ps(y+28));

   _mm_store_ps(z,z0);
   _mm_store_ps(z+4,z1);
   _mm_store_ps(z+8,z2);
   _mm_store_ps(z+12,z3);
   _mm_store_ps(z+16,z4);
   _mm_store_ps(z+20,z5);
   _mm_store_ps(z+24,z6);
   _mm_store_ps(z+28,z7);
  
   x += 32;
   y += 32;
   z += 32;
  } // IACA_END

}




/*
 * Do not need to modify from here on
 */

#define RUNS     400
#define CYCLES_REQUIRED 1e7

void verify(float a, float const * x, float const * y, float const * z)
{
  int i;
  double err;
  float * temp = (float *) _mm_malloc(sizeof(float)*N, 16);
  setzero(temp, N, 1);

  for(i = 0; i < N; i++) {
      temp[i] = a*x[i] + y[i];
      err = fabs(z[i] - temp[i]);
      if(err > 1E-5)
        {
          printf("Error at z[%d]\n", i);
        }
  }

  _mm_free(temp);

}

void test_vec_saxpy(float a, float const * x, float const * y, float * z)
{
  tsc_counter start, end;
  double cycles = 0.;
  size_t num_runs = RUNS;
  int i;


  //Cache warm-up
  // RDTSCP reads ts register guaranteeing that the execution of all the code
  // we wanted to measure is completed. This way we avoid including the
  // execution of a CPUID in between. The last CPUID guarantees no other
  // instruction can be scheduled before it (and so also before RDTSCP)

  CPUID(); RDTSC(start); CPUID(); RDTSC(end);
  CPUID(); RDTSC(start); CPUID(); RDTSC(end);
  CPUID(); RDTSC(start); CPUID(); RDTSC(end);

  while(1) {
      CPUID(); RDTSC(start);
      for (i = 0; i < num_runs; ++i) {
          vec_saxpy(a, x, y, z);
      }
      CPUID(); RDTSC(end);

      cycles = (double)(COUNTER_DIFF(end, start));

      if(cycles >= CYCLES_REQUIRED) break;

      num_runs *= 2;

  }

  CPUID(); RDTSC(start);
  for (i = 0; i < num_runs; ++i) {
      vec_saxpy(a, x, y, z);
  }
  CPUID(); RDTSC(end);

  cycles = (double)(COUNTER_DIFF(end, start))/num_runs;

  printf("Test vec_saxpy  - Performance [flops/cycle]: %f\n", 2.*N/cycles);

#ifdef VERIFY
  verify(a, x, y, z);
#endif

}

int main()
{
  float a = 2.5;
  float * x = (float *) _mm_malloc(sizeof(float)*N, 16);
  float * y = (float *) _mm_malloc(sizeof(float)*N, 16);
  float * z = (float *) _mm_malloc(sizeof(float)*N, 16);

  setrandom(x, N, 1);
  setrandom(y, N, 1);

  test_vec_saxpy(a, x, y, z);

  return 0;
}
