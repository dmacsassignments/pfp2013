#include<stdio.h>
#include<sys/time.h>
#include "rdtsc.h"

double time_diff(struct timeval x , struct timeval y)
{
    double x_ms , y_ms , diff;
    x_ms = (double)x.tv_sec*1000000 + (double)x.tv_usec;
    y_ms = (double)y.tv_sec*1000000 + (double)y.tv_usec;
    diff = (double)y_ms - (double)x_ms;
    return diff;
}

void freq()
{

volatile int v = 0;
volatile int vr = 0;
register int r1 = vr;
register int r2 = vr;
tsc_counter start, end;
double cycles,t;
int i=0,U=1000000;
struct timeval before , after;
CPUID(); RDTSC(start); CPUID(); RDTSC(end);
CPUID(); RDTSC(start); CPUID(); RDTSC(end);
CPUID(); RDTSC(start); CPUID(); RDTSC(end);
gettimeofday(&before , NULL);

CPUID(); RDTSC(start);

for(;i<U;i++)
switch (v)
{
case 0: r1 += r2;
case 1: r1 += r2;
case 2: r1 += r2;
case 3: r1 += r2;
case 4: r1 += r2;
case 5: r1 += r2;
case 6: r1 += r2;
case 7: r1 += r2;
case 8: r1 += r2;
case 9: r1 += r2;
}
if (!v)
{ 
  CPUID(); RDTSC(end);
  gettimeofday(&after , NULL);
  cycles = (double)(COUNTER_DIFF(end, start));
  printf("\nNo.Of.cycles[RTDSC COUNT] = %.6f",cycles); 
  cycles=U*10;
  printf("\nTotal time elapsed : %.6f us\n\nFrequency = %f GHz\n\n" , time_diff(before , after) ,cycles/(1000*time_diff(before , after)));
}
else
{
vr = r1;
vr = r2;
}



}

int main()
{

  //warm up 
  printf("Warm UP:\n");
  freq();
  
  //Actual execution
  printf("\n\nOUTPUT:\n");
  freq();


}

