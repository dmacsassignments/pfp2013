/*
 * MVM 5x5
 */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

#include <tmmintrin.h>
#include <smmintrin.h>
#include <nmmintrin.h>

#include "utils.h"
#include "rdtsc.h"


// Procedure mvm5: Serial code (do not need to modify)

void mvm5(float const * A, float const * x, float * y) {
  int i;
  float t;
  int j;
  for(i = 0; i < 5; i++) {
      t = 0.f;
      for(j = 0; j < 5; j++)
        t += A[i*5+j]*x[j];
      y[i] = t;
  }

}



// Procedure vec_mvm5: vector code
// Implement WITHOUT unaligned instructions

void vec_mvm5(register float const * A, register float const * x,register float * y) {

   register float const* a = A;
  // Substitute from here..


   __m128 A0 = _mm_load_ps(a);
   __m128i i1 = _mm_castps_si128(_mm_load_ps((a+4)));   
   __m128i i2 = _mm_castps_si128(_mm_load_ps((a+8)));
   __m128 A1 = _mm_castsi128_ps(_mm_alignr_epi8(i2,i1,4));
   __m128i i3 = _mm_castps_si128(_mm_load_ps((a+12)));
   __m128 A2 = _mm_castsi128_ps(_mm_alignr_epi8(i3,i2,8));
   __m128i i4 = _mm_castps_si128(_mm_load_ps((a+16)));
   __m128 A3 = _mm_castsi128_ps(_mm_alignr_epi8(i4,i3,12));
   __m128 A4 = _mm_load_ps((a+20));
   
   const __m128 X = _mm_load_ps(x);   
   const __m128 X1 = _mm_set1_ps(x[4]);
   
    __m128 y0 = _mm_dp_ps(A0,X,241);
    A0 = _mm_dp_ps(A1,X,242);
    A1 = _mm_dp_ps(A2,X,244);
    A2 = _mm_dp_ps(A3,X,248);    
    __m128 y11 = _mm_dp_ps(A4,X,241);

   y0 = _mm_add_ps(_mm_add_ps(y0,A0),_mm_add_ps(A1,A2));

   __m128 A00 = _mm_set_ps(*(a+19),*(a+14),*(a+9),*(a+4));
   __m128 A10 = _mm_set_ps(0,0,0,*(a+24));
 
   y0 = _mm_add_ps(y0,_mm_mul_ps(A00,X1));
   y11 = _mm_add_ps(y11,_mm_mul_ps(A10,X1));
   
   _mm_store_ps(y,y0);
   _mm_store_ps(y+4,y11);

  // ...to here

}




/*
 * Do not need to modify from here on
 */

#define RUNS     400
#define CYCLES_REQUIRED 1e7

void verify(float const * A, float const * x, float const * y)
{
  int i;
  double err;
  int j;
  float * temp = (float *) _mm_malloc(sizeof(float)*5, 16);
  setzero(temp, 5, 1);

  for(i = 0; i < 5; i++) {
      for(j = 0; j < 5; j++)
        temp[i] += A[i*5+j]*x[j];
      err = fabs(y[i] - temp[i]);
      if(err > 1E-5)
        {
          printf("Error at y[%d]\n", i);
        }
  }

  _mm_free(temp);

}

void test_vec_mvm5(float const * A, float const * x, float * y)
{
  tsc_counter start, end;
  double cycles = 0.;
  size_t num_runs = RUNS;
  int i;

  //Cache warm-up
  // RDTSCP reads ts register guaranteeing that the execution of all the code
  // we wanted to measure is completed. This way we avoid including the
  // execution of a CPUID in between. The last CPUID guarantees no other
  // instruction can be scheduled before it (and so also before RDTSCP)

  CPUID(); RDTSC(start); CPUID(); RDTSC(end);
  CPUID(); RDTSC(start); CPUID(); RDTSC(end);
  CPUID(); RDTSC(start); CPUID(); RDTSC(end);

  while(1) {
      CPUID(); RDTSC(start);
      for (i = 0; i < num_runs; ++i) {
          vec_mvm5(A, x, y);
      }
      CPUID(); RDTSC(end);

      cycles = (double)(COUNTER_DIFF(end, start));

      if(cycles >= CYCLES_REQUIRED) break;

      num_runs *= 2;

  }

  CPUID(); RDTSC(start);
  for (i = 0; i < num_runs; ++i) {
      vec_mvm5(A, x, y);
  }
  CPUID(); RDTSC(end);

  cycles = (double)(COUNTER_DIFF(end, start))/num_runs;

  printf("Test vec_mvm5  - Performance [flops/cycle]: %f\n", 45/cycles);

#ifdef VERIFY
  verify(A, x, y);
#endif

}


int main()
{
  float * A = (float *) _mm_malloc(sizeof(float)*25, 16);
  float * x = (float *) _mm_malloc(sizeof(float)*5, 16);
  float * y = (float *) _mm_malloc(sizeof(float)*5, 16);

  setrandom(A, 5, 5);
  setrandom(x, 5, 1);

  test_vec_mvm5(A, x, y);

  return 0;
}
