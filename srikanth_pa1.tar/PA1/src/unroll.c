#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "rdtsc.h"
#define N 10000
#define NUM_RUNS 1000

#define data_t double

void Unroll(data_t *y)
{
       
        int i;
        data_t a = 0;
        
        for (i = 0; i < N; i++)
         {  a+=y[i];
         } 
     //printf("RESULT for Unroll: %d\n",a);  
} 

void Unroll1(data_t *y)
{
       
        int i,j;
        data_t a,a1;
        a = a1 = 0;
        for (i = 0; i < N-1; i+=2)
         {  a+=y[i];
            a1+=y[i+1];
         } 
        for (j=i;j<N;j++)
        a1 +=y[j];
  
        a = a+a1; 
    // printf("RESULT for Unroll: %d\n",a);  

}

void Unroll2(data_t *y)
{
        int i,j;
        data_t a1,a2,a;
        a = a1 = a2 = 0;

        for (i = 0; i < N-2; i=i+3)
        {
           a+=y[i];
           a1+=y[i+1];
           a2+=y[i+2];
        }
    
        for(j = i;j<N;j++)
        a2+=y[j];  
        
        a = a+a1+a2; 
     //printf("RESULT for Unroll: %d\n",a);  
}


void Unroll3(data_t *y)
{
        int i,j;
        data_t a1,a2,a3,a;
        a = a1 = a2 = a3 = 0;

        for (i = 0; i < N-3; i=i+4)
        {
           a+=y[i];
           a1+=y[i+1];
           a2+=y[i+2];
           a3+=y[i+3];
        }
   
       for (j=i;j<N;j++)
        a3+=y[j];
        

        a = a+a1+a2+a3; 
     //printf("RESULT for Unroll: %d\n",a);  
}

void Unroll4(data_t *y)
{
        int i,j;
        data_t a1,a2,a3,a,a4;
        a = a1 = a2 = a3 = a4 = 0;

        for (i = 0; i < N-4; i=i+5)
        {
           a+=y[i];
           a1+=y[i+1];
           a2+=y[i+2];
           a3+=y[i+3];
           a4+=y[i+4]; 
        }

        for(j=i;j<N;j++) 
        a4+=y[j];       
        a = a+a1+a2+a3+a4; 

    //printf("RESULT for Unroll: %d\n",a);  
}

void Unroll5(data_t *y)
{
        int i,j;
        data_t a1,a2,a3,a,a4,a5;
        a = a1 = a2 = a3 = a4 = a5 = 0;

        for (i = 0; i < N-5; i=i+6)
         {
           a+=y[i];
           a1+=y[i+1];
           a2+=y[i+2];
           a3+=y[i+3];
           a4+=y[i+4];
           a5+=y[i+5];
        }
        
        for(j=i;j<N;j++)
        a5+=y[i];
        a = a+a1+a2+a3+a4+a5;
     //printf("RESULT for Unroll: %d\n",a);  
}

void Unroll6(data_t *y)
{
        int i,j;
        data_t a1,a2,a3,a,a4,a5,a6;
        a = a1 = a2 = a3 = a4 = a5 = a6 = 0;
           
        for (i = 0; i < N-6; i=i+7)
        {
           a+=y[i];
           a1+=y[i+1];
           a2+=y[i+2];
           a3+=y[i+3];
           a4+=y[i+4];
           a5+=y[i+5];
           a6+=y[i+6];
        }

       for(j=i;j<N;j++)
       a6+=y[j];     

       a = a+a1+a2+a3+a4+a5+a6;
       //printf("RESULT for Unroll: %d\n",a);  
}

void Unroll7(data_t *y)
{
        int i,j;
        data_t a1,a2,a3,a,a4,a5,a6,a7;
        a = a1 = a2 = a3 = a4 = a5 = a6 = a7 =0;
           
        for (i = 0; i < N-7; i=i+8)
        {
           a+=y[i];
           a1+=y[i+1];
           a2+=y[i+2];
           a3+=y[i+3];
           a4+=y[i+4];
           a5+=y[i+5];
           a6+=y[i+6];
           a7+=y[i+7];
        }
        
        for(j=i;j<N;j++)
        a7+=y[j];
        a = a+a1+a2+a3+a4+a5+a6+a7;
     //printf("RESULT for Unroll: %d\n",a);  
}

void Unroll8(data_t *y)
{
        int i,j;
        data_t a1,a2,a3,a,a4,a5,a6,a7,a8;
        a = a1 = a2 = a3 = a4 = a5 = a6 = a7 = a8 =0;
           
        for (i = 0; i < N-8; i=i+9)
        {
           a+=y[i];
           a1+=y[i+1];
           a2+=y[i+2];
           a3+=y[i+3];
           a4+=y[i+4];
           a5+=y[i+5];
           a6+=y[i+6];
           a7+=y[i+7];
           a8+=y[i+8];
        }

        for(j=i;j<N;j++)
        a8+=y[j]; 
        a = a+a1+a2+a3+a4+a5+a6+a7+a8;
     //printf("RESULT for Unroll: %d\n",a);  
}

void Unroll9(data_t *y)
{
        int i,j;
        data_t a1,a2,a3,a,a4,a5,a6,a7,a8,a9;
        a = a1 = a2 = a3 = a4 = a5 = a6 = a7 = a8 = a9 =0;

        for (i = 0; i < N-9; i=i+10)
        {
           a+=y[i];
           a1+=y[i+1];
           a2+=y[i+2];
           a3+=y[i+3];
           a4+=y[i+4];
           a5+=y[i+5];
           a6+=y[i+6];
           a7+=y[i+7];
           a8+=y[i+8];
           a9+=y[i+9];   
        }

        for(j=i;j<N;j++)
        a9+=y[j];
        a = a+a1+a2+a3+a4+a5+a6+a7+a8+a9;
     //printf("RESULT for Unroll: %d\n",a);  
}

int main(int argc,char**argv)
{       
        data_t * buffer;
        tsc_counter a, b;
        double cycles, baseline;
        int i=0;
        
        if(argc!=2){
        printf("Usage: unroll <unroll factor>\n");
        exit(1);
        }

        buffer = (data_t*)malloc(sizeof(data_t)*N);
       
        if(buffer == NULL){
        printf("Out of memory\n");
        exit(2);        
        }

        
        for (i = 0; i<N; i++){
         buffer[i] = rand()%1000;
        }

        switch(atoi(*++argv))
        {
        case 0:  
        Unroll(buffer);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);

        RDTSC(a);
        for(i=0; i<NUM_RUNS; i++)
        {
                Unroll(buffer);
        }
        RDTSC(b);
        cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
        printf("Unroll : %lf Cycles:\n",cycles);
        break;
        
        case 1:
        Unroll1(buffer);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);

        RDTSC(a);
        for(i=0; i<NUM_RUNS; ++i)
        {
                Unroll1(buffer);
        }
        RDTSC(b);
        cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
        printf("Unroll1 :%lf Cycles:\n",cycles);   
        break;
        
        case 2:       
        Unroll2(buffer);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);

        RDTSC(a);
        for(i=0; i<NUM_RUNS; ++i)
        {
                Unroll2(buffer);
        }
        RDTSC(b);
        cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
        printf("Unroll2 :%lf Cycles:\n",cycles);
        break;

        case 3:
        Unroll3(buffer);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);

        RDTSC(a);
        for(i=0; i<NUM_RUNS; ++i)
        {
                Unroll3(buffer);
        }
        RDTSC(b);
        cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
        printf("Unroll3 :%lf Cycles:\n",cycles);
        
        break;

        case 4:
        Unroll4(buffer);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);

        RDTSC(a);
        for(i=0; i<NUM_RUNS; ++i)
        {
                Unroll4(buffer);
        }
        RDTSC(b);
        cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
        printf("Unroll4 :%lf Cycles:\n",cycles);
        break;

        case 5:
        Unroll5(buffer);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);

        RDTSC(a);
        for(i=0; i<NUM_RUNS; ++i)
        {
                Unroll5(buffer);
        }
        RDTSC(b);
        cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
        printf("Unroll5:%lf Cycles:\n",cycles);
        break;  

        case 6:
        Unroll6(buffer);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);

        RDTSC(a);
        for(i=0; i<NUM_RUNS; ++i)
        {
                Unroll6(buffer);
        }
        RDTSC(b);
        cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
        printf("Unroll6:%lf Cycles:\n",cycles);
        break;
  
        case 7:
        Unroll7(buffer);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);

        RDTSC(a);
        for(i=0; i<NUM_RUNS; ++i)
        {
                Unroll7(buffer);
        }
        RDTSC(b);
        cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
        printf("Unroll7:%lf Cycles:\n",cycles);
        break; 

        case 8:
        Unroll8(buffer);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);

        RDTSC(a);
        for(i=0; i<NUM_RUNS; ++i)
        {
                Unroll8(buffer);
        }
        RDTSC(b);
        cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
        printf("Unroll8:%lf Cycles:\n",cycles);
        break; 
        
        case 9:
        Unroll9(buffer);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);

        RDTSC(a);
        for(i=0; i<NUM_RUNS; ++i)
        {
                Unroll9(buffer);
        }
        RDTSC(b);
        cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
        printf("Unroll9:%lf Cycles:\n",cycles);
        break;


        default:
        printf("default case executed unroll factor is 0\n");  
        Unroll(buffer);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);

        RDTSC(a);
        for(i=0; i<NUM_RUNS; i++)
        {
                Unroll(buffer);
        }
        RDTSC(b);
        cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
        printf("Unroll: %lf Cycles:\n",cycles);
        }

 
        free(buffer);
        return 0;
}
                                                                                                                                                              

