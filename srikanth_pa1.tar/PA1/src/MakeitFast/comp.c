/*
 * comp.c - contains the function superslow that you need to optimize
 *
 *
 */

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


/* f(x, i, j) multiplies or divides by a sine expression depending
   on i + j being odd or even
*/
double inline f(double x, int i, int j)
{
    if((i + j) & 0x1)
        return x / (1 + sin(M_PI/(i+1)));
    else
        return x * sin(M_PI/(i+1));
}

/* This is the function you need to optimize. It takes one
   square matrix as input
*/
void superslow(smat_t *a)
{
    int i, j;
    double x,x2;

    // i is the column of a we're computing right now
        for(i = 0; i < a->n; i++)
           {
             // j is the row of a we're computing right now
             for(j = 0; j < a->n; j++)
              {
                // First, compute f(A) for the element of a in question
               x = get_elt(a, i, j);
               x = f(x, i, j);
              // Add this to the value of a we're computing and store it
              x2 = get_elt(a, i, j);
              x = x * x2;
              set_elt(a, i, j, x);
                                                                                                                                                                                }
                                                                                                                                                                               }
                                                                                                                                                                              }
  

void superslow1(smat_t *a)
{

 int i, j;
 double x,x2;
 int n = a->n,n1 = 0,n2 = 0; 
 
// i is the column of a we're computing right now
 for(i = 0; i < a->n; i++)
  {
     n1 = i * n;
     for(j = 0; j < a->n; j++)
       {
         n2 = j+n1;
         x = a->mat[n2];
         if((i + j) & 0x1)
         x = x / (1 + sin(M_PI/(i+1)));
         else
         x = x * sin(M_PI/(i+1));
         x2 = a->mat[n2];
         x = x*x2;
         a->mat[n2] = x;
       }
    }
}


void superslow2(smat_t *a)
{
 int i, j;
 double x,x2;
 register int n = a->n,n1 = 0,n2 = 0; 
 
 for(i = 0; i < a->n; i++)
  {
     n1 = i * n;
     for(j = 0; j < a->n; j++)
       {
         n2 = j+n1;
         x = a->mat[n2];
         if((i + j) & 0x1)
         x = x / (1 + sin(M_PI/(i+1)));
         else
         x = x * sin(M_PI/(i+1));
         x2 = a->mat[n2];
         x = x*x2;
         a->mat[n2] = x;
       }
    }
 }


void superslow3(smat_t *a)
{
 register int i, j;
 register double x=0,x2=0,amatval=0,sinval=0.0;
 register int n = a->n,n1 = 0,n2 = 0;

 for(i = 0; i < a->n; i++)
  {
     n1 = i * n;
     sinval = sin(M_PI/(i+1));
     for(j = 0; j < a->n; j++)
       {
         n2 = j+n1;
         amatval = a->mat[n2]; 
         x = amatval;
         if((i + j) & 0x1)
         x = x / (1 + sinval);
         else
         x = x * sinval;
         x2 = amatval;
         x = x*x2;
         a->mat[n2] = x;
       }
    }
 }

void superslow4(smat_t *a)
{
 register int i, j;
 register double x=0,x2=0,amatval=0,sinval=0.0;
 register int n = a->n,n1 = 0,n2 = 0;

 for(i = 0; i < a->n; i+=2)
  {
     n1 = i * n;
     sinval = sin(M_PI/(i+1));
     for(j = 0; j < a->n; j+=2)
       {
         n2 = j+n1;
         amatval = a->mat[n2]; 
         x = amatval;
         x = x * sinval;
         x2 = amatval;
         x = x*x2;
         a->mat[n2] = x;
         
         n2 = j+n1+1;
         amatval = a->mat[n2]; 
         x = amatval;
         x = x / (1 + sinval);
         x2 = amatval;
         x = x*x2;
         a->mat[n2] = x;
         
       }
    }
   
  for(i = 1; i < a->n; i+=2)
     {
      n1 = i * n;
      sinval = sin(M_PI/(i+1));
      for(j = 0; j < a->n; j+=2)
       {
         n2 = j+n1;
         amatval = a->mat[n2];
         x = amatval;
         x = x / (1 + sinval);
         x2 = amatval;
         x = x*x2;
         a->mat[n2] = x;

         n2 = j+n1+1;
         amatval = a->mat[n2];
         x = amatval;
         x = x * sinval;
         x2 = amatval;
         x = x*x2;
         a->mat[n2] = x;

       }
    }  
 }

void superslow5(smat_t *a)
{
 register int i, j;
 register double x=0,x2=0,amatval=0;
 register int n = a->n,n1 = 0,n2 = 0,n3 = 0;

 for(i = 0; i < a->n; i+=2)
  {
     n1 = i * n;
     register const double sinval = sin(M_PI/(i+1));
     for(j = 0; j < a->n; j+=2)
       {
         n2 = j+n1;
         amatval = a->mat[n2];
         x = amatval;
         x = x * sinval;
         x2 = amatval;
         x = x*x2;
         a->mat[n2] = x;

         n3 = n2+1;
         amatval = a->mat[n3];
         x = amatval;
         x = x *(1/ (1 + sinval));
         x2 = amatval;
         x = x*x2;
         a->mat[n3] = x;
         
         

       }
    }
  
  for(i = 1; i < a->n; i+=2)
     {
      n1 = i * n;
      register const double sinval2 = sin(M_PI/(i+1));
      for(j = 0; j < a->n; j+=2)
       {
         n2 = j+n1;
         amatval = a->mat[n2];
         x = amatval;
         x = x*(1/ (1 + sinval2));
         x2 = amatval;
         x = x*x2;
         a->mat[n2] = x;

         n3 = n2+1;
         amatval = a->mat[n3];
         x = amatval;
         x = x * sinval2;
         x2 = amatval;
         x = x*x2;
         a->mat[n3] = x;
       }
    }      
  
 }

    
void superslow6(smat_t *a)
{
 register int i, j;
 register double x=0,x2=0,x3=0,x4=0,amatval=0,amatval2=0,amatval3=0,sinval=0.0,sinval2=0.0;
 register int n = a->n,n1 = 0,n2 = 0,n3 = 0,n4 =0,n5 =0;

 for(i = 0; i < a->n; i+=2)
  {
    n1=i*n;
    sinval = sin(M_PI/(i+1));
    sinval2 = 1+sinval;
    for(j = 0; j < a->n; j+=4)
       {
         n2 = j+n1;
         
         amatval = a->mat[n2];
         n3 = n2+1;
         x = amatval*amatval*sinval;
         amatval2 = a->mat[n3];
         a->mat[n2] = x;

         n4 = n2+2;
         x2 = amatval2*amatval2/(sinval2);
         amatval3 = a->mat[n4];
         a->mat[n3] = x2;
         
         n5 = n2+3;         
         x3 = amatval3*amatval3*sinval;
         amatval = a->mat[n5];
         a->mat[n4] = x3;

        
         x4 = amatval*amatval/(sinval2);
         a->mat[n5] = x4;       

       }
    }
    
  for(i = 1; i < a->n; i+=2)
     {
      n1 = i * n;
      sinval = sin(M_PI/(i+1));
      sinval2 = 1+sinval;
      for(j = 0; j < a->n; j+=4)
       {
         n2 = j+n1;
         
         amatval = a->mat[n2];
         n3 = n2+1;
         x = amatval*amatval/(sinval2);
         amatval2 = a->mat[n3];
         a->mat[n2] = x;

        
         n4 = n2+2;
         x2 = amatval2*amatval2*sinval;
         amatval3 = a->mat[n4];
         a->mat[n3] = x2;
         
         x3 = amatval3*amatval3/(sinval2);
         n5 = n2+3;
         a->mat[n4] = x3;

         amatval = a->mat[n5];
         x4 = amatval*amatval*sinval;
         a->mat[n5] = x4;
         
       }
    }  
    
 }


void superslow7(smat_t *a)
{
 register int i, j;
 register double amatval=0,amatval2=0,amatval3=0,sinval=0.0,sinval2=0.0;
 register int n = a->n,n1 = 0,n2 = 0,n3 = 0,n4 =0,n5 =0;

 for(i = 0; i < n; i+=2)
  {
    n1=i*n;
    sinval = sin(M_PI/(i+1));
    sinval2 = 1/(1+sinval);
    
    for(j = 0; j < a->n; j+=4)
       {
         n2 = j+n1;

         amatval = a->mat[n2];
         n3 = n2+1;
         a->mat[n2] = amatval*amatval*sinval;
         amatval2 = a->mat[n3];

         n4 = n2+2;
         a->mat[n3] = amatval2*amatval2*(sinval2);
         amatval3 = a->mat[n4];

         n5 = n2+3;
         a->mat[n4] = amatval3*amatval3*sinval;
         amatval = a->mat[n5];
         
         a->mat[n5] = amatval*amatval*(sinval2);
         
                
         
        }
    }

  for(i = 1; i < n; i+=2)
     {
      n1 = i * n;
      sinval = sin(M_PI/(i+1));
      sinval2 = 1/(1+sinval);
      for(j = 0; j < a->n; j+=4)
       {
         n2 = j+n1;

         amatval = a->mat[n2];
         n3 = n2+1;
         a->mat[n2] = amatval*amatval*(sinval2);
         amatval2 = a->mat[n3];

         n4 = n2+2;
         a->mat[n3] = amatval2*amatval2*sinval;
         amatval3 = a->mat[n4];

         a->mat[n4] = amatval3*amatval3*(sinval2);
         n5 = n2+3;

         amatval = a->mat[n5];
         a->mat[n5] = amatval*amatval*sinval;
         
        
       }
    }

 }
                                                          
  
/* 
 * Called by the driver to register your functions
 * Use add_function(func, description) to add your own functions
 */
void register_functions()
{
    //Registers comp_superslow with the driver
    add_function(&superslow, "superslow: original function");
    add_function(&superslow1, "superslow: superslow1 function");
    add_function(&superslow2, "superslow: superslow2 function");
    add_function(&superslow3, "superslow: superslow3 function");
    add_function(&superslow4,"superslow: superslow4");	
    add_function(&superslow5,"superslow: superslow5");	
    add_function(&superslow6,"superslow: superslow6");	
    add_function(&superslow7,"superslow: superslow7");	
	//Add your functions here
	//add_function(&superslow2, "superslow: Optimization X");

	
}
