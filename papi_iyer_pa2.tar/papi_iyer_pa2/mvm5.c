/*
 * MVM 5x5
 */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

#include <tmmintrin.h>

#include <nmmintrin.h>

#include <smmintrin.h>
#include "utils.h"
#include "rdtsc.h"


// Procedure mvm5: Serial code (do not need to modify)

void mvm5(float const * A, float const * x, float * y) {
  int i;
  float t;
  int j;
  for(i = 0; i < 5; i++) {
      t = 0.f;
      for(j = 0; j < 5; j++)
        t += A[i*5+j]*x[j];
      y[i] = t;
  }

}



// Procedure vec_mvm5: vector code
// Implement WITHOUT unaligned instructions

void vec_mvm5(float const * A, float const * x, float * y) {

      __m128   inter,xvec,avec,yvec,yvec1,yvec2,yvec3,yvec4,yvec5,yvec6,fifth,scalar,vvec; 
      __m128i temp1,temp2,temp3,temp4;
       register float *ptr ;
      // register float last = x[4];
       ptr =A;
       avec = _mm_load_ps(ptr);
       xvec = _mm_load_ps(x);
       yvec1 = _mm_dp_ps(avec,xvec,241);
       
       temp1 = _mm_castps_si128(_mm_load_ps(ptr+4));
       temp2 = _mm_castps_si128(_mm_load_ps(ptr+8));
       avec  = _mm_castsi128_ps(_mm_alignr_epi8(temp2,temp1,4));
       yvec2 = _mm_dp_ps(avec,xvec,242);

       
       temp3 = _mm_castps_si128( _mm_load_ps(ptr+12));
       avec  = _mm_castsi128_ps(_mm_alignr_epi8(temp3,temp2,8));
       yvec3 = _mm_dp_ps(avec,xvec,244);

       
       temp4 = _mm_castps_si128(_mm_load_ps(ptr+16));
       avec  = _mm_castsi128_ps(_mm_alignr_epi8(temp4,temp3,12));
       yvec = _mm_dp_ps(avec,xvec,248);

       fifth =_mm_set_ps(*(ptr+19),*(ptr+14),*(ptr+9),*(ptr+4));
       scalar = _mm_set1_ps(x[4]);
     
       yvec4= _mm_add_ps(yvec1,yvec2);
       yvec5= _mm_add_ps(yvec,yvec3);
      
       yvec6= _mm_add_ps(yvec4,yvec5);
       vvec = _mm_add_ps(yvec6,_mm_mul_ps(fifth,scalar));
       _mm_store_ps(y,vvec);

       


       avec = _mm_load_ps(ptr+20);
       inter = _mm_dp_ps(avec,xvec,241);
       y[4] = _mm_cvtss_f32(inter)+ (A[24]*x[4]);
       


       
}
 












      
                 
          





// Substitute from here..
//  printf("Implement vec_mvm5\n");
 // abort();
  // ...to here






/*
 * Do not need to modify from here on
 */

#define RUNS     400
#define CYCLES_REQUIRED 1e7

void verify(float const * A, float const * x, float const * y)
{
  int i;
  double err;
  int j;
  float * temp = (float *) _mm_malloc(sizeof(float)*5, 16);
  setzero(temp, 5, 1);

  for(i = 0; i < 5; i++) {
      for(j = 0; j < 5; j++)
        temp[i] += A[i*5+j]*x[j];
      err = fabs(y[i] - temp[i]);
      if(err > 1E-5)
        {
          printf("Error at y[%d]\n", i);
        }
  }

  _mm_free(temp);

}

void test_vec_mvm5(float const * A, float const * x, float * y)
{
  tsc_counter start, end;
  double cycles = 0.;
  size_t num_runs = RUNS;
  int i;

  //Cache warm-up
  // RDTSCP reads ts register guaranteeing that the execution of all the code
  // we wanted to measure is completed. This way we avoid including the
  // execution of a CPUID in between. The last CPUID guarantees no other
  // instruction can be scheduled before it (and so also before RDTSCP)

  CPUID(); RDTSC(start); CPUID(); RDTSC(end);
  CPUID(); RDTSC(start); CPUID(); RDTSC(end);
  CPUID(); RDTSC(start); CPUID(); RDTSC(end);

  while(1) {
      CPUID(); RDTSC(start);
      for (i = 0; i < num_runs; ++i) {
          vec_mvm5(A, x, y);
      }
      CPUID(); RDTSC(end);

      cycles = (double)(COUNTER_DIFF(end, start));

      if(cycles >= CYCLES_REQUIRED) break;

      num_runs *= 2;

  }

  CPUID(); RDTSC(start);
  for (i = 0; i < num_runs; ++i) {
      vec_mvm5(A, x, y);
  }
  CPUID(); RDTSC(end);

  cycles = (double)(COUNTER_DIFF(end, start))/num_runs;

  printf("Test vec_mvm5  - Performance [flops/cycle]: %f\n", 45/cycles);

#ifdef VERIFY
  verify(A, x, y);
#endif

}


int main()
{
  float * A = (float *) _mm_malloc(sizeof(float)*25, 16);
  float * x = (float *) _mm_malloc(sizeof(float)*5, 16);
  float * y = (float *) _mm_malloc(sizeof(float)*5, 16);

  setrandom(A, 5, 5);
  setrandom(x, 5, 1);

  test_vec_mvm5(A, x, y);

  return 0;
}
