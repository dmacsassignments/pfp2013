#include<stdio.h>
#include <sys/time.h>
#include<sys/types.h>
int main()
{
  struct timeval start;
  struct timeval end;
  
 
 long int R,U,i,diff;
 volatile int v =0;
 volatile int vr = 0;
 register int r1 = vr;
 register int r2 = vr;
 
   R= 10000000;
   U= 10; 
  
  i = R / U;
  gettimeofday(&start,NULL);
switch (v)
{
 case 0: loop:
 case 1: r1 += r2;
 case 2: r1 += r2;
 case 3: r1 += r2;
 case 4: r1 += r2;
 case 5: r1 += r2;
 case 6: r1 += r2;
 case 7: r1 += r2;
 case 8: r1 += r2;
 case 9: r1 += r2;
 case 10:r1 += r2;
 if(--i)
  goto loop;
 }
  gettimeofday(&end,NULL);

if (!v)
{  diff = ((end.tv_sec)*1000000000+(end.tv_usec)*1000)-((start.tv_sec)*1000000000+(start.tv_usec)*1000);
  printf(" Time : %ld nanoseconds \n",diff);
  printf(" Frequency : %ld Ghz \n ",10000000/diff); }
 else
 {
  vr = r1;
  vr = r2;
 }
}
  


