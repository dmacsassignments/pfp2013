#include <stdio.h>

/*
    Read a set of values from the user.
    Store the sum in the sum variable and return the average i.e., sum/values. 
*/
int read_values(double sum)
{
  int values=0,input=0;
  sum = 0;
  printf("Enter input values (enter 0 to finish):\n");
  scanf("%d",&input);
  while(input != 0) {
    values++;
    sum += input;
    scanf("%d",&input);
  }
  return sum/values;
}

int main()
{
  double sum;
  double avg;
  avg = read_values(sum);
  printf("Average: %g\n",avg);
  return 0;
}

