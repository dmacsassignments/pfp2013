                               AUM SRI SAI RAM
The changes that I have made to the given code are mentioned below :

1. Removed the accessing of function calls (get & set elements).
2. In the process removed temporary variables. (sum1 & sum2).
3. Put register keyword for variables.
4. Removed loop invariant operations. (moved them out of the loop).
5. Removed function call ( call to function f).
6. Used -mavx flag.

superslow: original function:
Size 300: 60.820 MFLOPs
Size 600: 55.393 MFLOPs
Average: 58.107 MFLOPs

a1: first function:
Size 300: 4000.444 MFLOPs
Size 600: 4500.563 MFLOPs
Average: 4250.504 MFLOPs

a2: second function:
Size 300: 3600.360 MFLOPs
Size 600: 4235.792 MFLOPs
Average: 3918.076 MFLOPs

Best: a1: first function
Perf: 4250.504 MFLOPs

