#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

void transpose( int n, int blocksize, int *dst, int *src ) {
    int i,j;
    /* to do: implement blocking (two more loops) */
    for( i = 0; i < n; i++ )
        for( j = 0; j < n; j++ )
            dst[j+i*n] = src[i+j*n];
}

void transpose_factor(int n,int blocksize,int *dst,int *src){
   int i,j,i1,j1;
   
   for(i=0;i<n;i+=blocksize)
     for(j=0;j<n;j+=blocksize)
        for(i1=i;i1<i+blocksize;i1++)
         for(j1=j;j1<j+blocksize;j1++)
                 dst[j1+i1*n] = src[i1+j1*n];
}
   
 


void transpose_notfactor(int n,int blocksize,int *dst,int *src){
          
         int i,j,i1,j1,q;
         q=n/blocksize;
         q=q*blocksize;
         for(i=0;i<q;i+=blocksize)
         for(j=0;j<q;j+=blocksize)
         for(i1=i;i1<i+blocksize;i1++)
         for(j1=j;j1<j+blocksize;j1++)
                 dst[j1+i1*n] = src[i1+j1*n];

        for(i=0;i<q;i++)
          for(j=q;j<n;j++)
           dst[j+i*n] = src[i+j*n];

        for(i=q;i<n;i++)
           for(j=0;j<n;j++)
              dst[j+i*n] = src[i+j*n];
 }


              
int main( int argc, char *argv[] ) {
    int n = 2000,i,j,r;
    int blocksize ; /* to do: find a better block size */

    /* allocate an n*n block of integers for the matrices */
    int *A = (int*)malloc( n*n*sizeof(int) );
    int *B = (int*)malloc( n*n*sizeof(int) );

    /* initialize A,B to random integers */
    srand48( time( NULL ) );
    for( i = 0; i < n*n; i++ ) A[i] = lrand48( );
    for( i = 0; i < n*n; i++ ) B[i] = lrand48( );

    /* measure performance */
    struct timeval start, end;
    
    
    for(blocksize=1;blocksize<450;blocksize++)
    {
      r=n%blocksize; 
      if(r==0)
      {
        gettimeofday( &start, NULL );
        transpose_factor( n, blocksize, B, A );
       gettimeofday( &end, NULL );

       double seconds = (end.tv_sec - start.tv_sec) + 1.0e-6 * (end.tv_usec - start.tv_usec);
       printf( "blocksize=%d : %g milliseconds\n", blocksize,seconds*1e3 );
     }
     else
     {
        gettimeofday( &start, NULL );
        transpose_notfactor( n, blocksize, B, A );
        gettimeofday( &end, NULL );

       double seconds = (end.tv_sec - start.tv_sec) + 1.0e-6 * (end.tv_usec - start.tv_usec);
       printf( "blocksize=%d : %g milliseconds\n", blocksize,seconds*1e3 );
     }
}

    /* check correctness */
    for( i = 0; i < n; i++ )
        for( j = 0; j < n; j++ )
            if( B[j+i*n] != A[i+j*n] ) {
	        printf("Error!!!! Transpose does not result in correct answer!!\n");
	        exit( -1 );
            }
  
    /* release resources */
    free( A );
    free( B );
    return 0;
}

