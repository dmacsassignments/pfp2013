#include <ia32intrin.h>
#include <stdlib.h>
#include <stdio.h>

#pragma auto_inline(off)
void t3(float A[512][512])
{
	unsigned long long start_c, end_c, diff_c;
	start_c = _rdtsc();
	#pragma novector
	for (int nl = 0; nl < 1000; nl++)
	    	for (int i = 1; i < 512; i++) {
	    		for (int j = 1; j < 512; j++) {
					A[i][j] = A[i-1][j] + A[i][j-1];
	    		}
	    	}
	
	end_c=_rdtsc();
	diff_c = end_c - start_c;
	float giga_cycle = diff_c / 1000000000.0;
	float ret = 0.;
	#pragma novector
	for (int i = 0; i < 512; i++) {
	  #pragma novector
		for (int j = 0; j < 512; j++)
			ret += A[i][j];
	}
	printf("It took %f giga cycles and the result is: %f", giga_cycle, ret);
}

int main(){
	float A[512][512] __attribute__ ((aligned(16)));
	#pragma novector
	for (int i = 0; i < 512; i++) {
	  #pragma novector
		for (int j = 0; j < 512; j++)
		{
			A[i][j] = 0.1/(i+j+1);
		}
	}
	t3(A);
	printf("\n");
}
