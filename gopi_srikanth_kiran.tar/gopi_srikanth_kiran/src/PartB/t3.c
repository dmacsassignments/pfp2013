#include <ia32intrin.h>
#include <stdlib.h>
#include <stdio.h>

#pragma auto_inline(off)
void t3(float AA[512][512], float BB[512][512])
{
	unsigned long long start_c, end_c, diff_c;
	start_c = _rdtsc();
	#pragma novector
	for (int nl = 0; nl < 5000; nl++)
	    	for (int j = 0; j < 512; j++) {
	    		for (int i = 0; i < j; i++) {
					AA[i][j] = AA[j][i] + BB[i][j];
	    		}
	    	}
	
	end_c=_rdtsc();
	diff_c = end_c - start_c;
	float giga_cycle = diff_c / 1000000000.0;
	float ret = 0.;
#pragma novector
	for (int i = 0; i < 512; i++) {
#pragma novector
		for (int j = 0; j < 512; j++)
			ret += AA[i][j];
	}
	printf("It took %f giga cycles and the result is: %f", giga_cycle, ret);
}

int main(){
	static float AA[512][512] __attribute__ ((aligned(16)));
	static float BB[512][512] __attribute__ ((aligned(16)));
	#pragma novector
	for (int i = 0; i < 512; i++) {
	  #pragma novector
		for (int j = 0; j < 512; j++)
		{
			AA[i][j] = 1./(i+j+1);
			BB[i][j] = 2./(i+j+2);
		}
	}
	t3(AA, BB);
	printf("\n");
}
