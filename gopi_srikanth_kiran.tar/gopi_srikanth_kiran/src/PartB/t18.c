#include <ia32intrin.h>
#include <stdlib.h>
#include <stdio.h>
#include <xmmintrin.h>

#pragma auto_inline(off)
void t1(float A[128][128], float B[128][128], float C[128][128])
{
	float temp;
	unsigned long long start_c, end_c, diff_c;
	start_c = _rdtsc();
	#pragma novector
	for (int nl = 0; nl < 2000; nl++){
	  for (int i = 0; i < 128; i++){
	    for (int j = 0; j < 128; j++){
	      //	      temp = C[i][j];
	      //	      				#pragma vector always
	      for (int  k = 0; k < 128; k++){
				C[i][j] += A[i][k]*B[k][j];
		//		temp += A[i][k] * B[k][j];
	      }
	      //	      C[i][j] = temp;
	    }
	  }
	}
	end_c=_rdtsc();
	diff_c = end_c - start_c;
	float giga_cycle = diff_c / 1000000000.0;
	float ret = 0;
	#pragma novector
	for (int i = 0; i < 128; i++) {
#pragma novector
	  for (int j = 0; j < 128; j++)
	    ret += C[i][j];
	}
	printf("It took %f giga cycles and the result is: %f \n", giga_cycle, ret);
}

int main(){
	float A[128][128] __attribute__ ((aligned (16)));
	float B[128][128] __attribute__ ((aligned (16)));
	float C[128][128] __attribute__ ((aligned (16)));
	#pragma novector
	for (int i = 0; i < 128; i++){
	  #pragma novector
		for (int j = 0; j < 128; j++){
			A[i][j] = j*1. / (i+1);
			B[i][j] = j*2. / (i+1);
			C[i][j] = 0.;
		}
	}
	t1(A,B,C);
}
