/*
 * comp.c - contains the function superslow that you need to optimize
 *
 *
 */

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


/* f(x, i, j) multiplies or divides by a sine expression depending
   on i + j being odd or even
*/
double f(double x, int i, int j)
{
    if((i + j) & 0x1)
        return x / (1 + sin(M_PI/(i+1)));
    else
        return x * sin(M_PI/(i+1));
}

/* This is the function you need to optimize. It takes one
   square matrix as input
*/
void superslow(smat_t *a)
{
    int i, j;
    double x,x2;

    // i is the column of a we're computing right now
    for(i = 0; i < a->n; i++)
    {
        // j is the row of a we're computing right now
        for(j = 0; j < a->n; j++)
        {            
                // First, compute f(A) for the element of a in question
			x =get_elt(a, i, j);
                x = f(x, i, j);
                
                // Add this to the value of a we're computing and store it
                x2 = get_elt(a, i, j);
			x = x * x2;
                set_elt(a, i, j, x);
            
        }
    }
}
void naidu_superslow(smat_t *a)
{
 int i,j;
 double x1,x2;
 double value1;
  double *mat =a->mat;
 int len=a->n; 
 int ni=0;
 int limit=len-1; 
 
  for(i=0;i<len;i++)
  {
       
     value1=sin(M_PI/(i+1));
        if(!(i&0x1))
        {
           
          for(j=0;j<limit;j+=2)
          {
           
            x1= mat[ni+j]; 
            x2=mat[ni+j+1];
            mat[ni+j]=(x1*value1)*x1;
     
            mat[ni+j+1]=(x2/(1+value1))*x2;
          }
          for(;j<len;j++)
           {
              x1=mat[ni+j];
              mat[ni+j]=(x1*value1)*x1;
           }
       }
       else
       {
         for(j=0;j<limit;j+=2)
         {
         
          x1=mat[ni+j];
          x2=mat[ni+j+1];
          mat[ni+j]=(x1/(1+value1))*x1;
        
          mat[ni+j+1]=(x2*value1)*x2;
        }
         for(;j<len;j++)
         {
        
            x1=mat[ni+j];
            mat[ni+j]=(x1/(1+value1))*x1;
         }
       
      }  
         
     ni+=len;                               
                  
    /*  if((i+j)&0x1)
      
        mat[ni+j]=(x1/(1+value1))x1;
      
      else
      
        mat[ni+j]=(x1*value1)*x1;
      
     }
    ni+=len;*/
   
 }
}
void register_functions()
{
    // Registers comp_superslow with the driver
    add_function(&superslow, "superslow: original function");
    add_function(&naidu_superslow,"superslow:naidu_superslow"); 	
	//Add your functions here
	//add_function(&superslow2, "superslow: Optimization X");
}
