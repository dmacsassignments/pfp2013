#include <stdio.h>
#include <math.h>
#include<stdlib.h>
#include "rdtsc.h"
#define N 10000
#define NUM_RUNS 15
typedef double data_t;
/*inline void Unroll2(data_t *y)
{
	float t1;
	for (int i = 0; i < N; i=i+4)
	{
		y[i] = 0;
		y[i+1] = 0;
		y[i+2] = 0;
		y[i+3] = 0;
	}
}*/
data_t noUnroll(data_t *v)
{
 data_t value,d1;
  value=d1=0.0;
 long int i=0;
  for(;i<N;i++)
  {
    value+=v[i];

  }
  return value;
}

data_t Unroll3(data_t *v)
{
 data_t value,d1,d2,d3;
  value=d1=d2=d3=0.0;
 long int i=0;  
 long int limit = N-N%3;
  for(;i<limit;i+=3)
  {
    d1+=v[i+0];
    d2+=v[i+1];
    d3+=v[i+2];
 }
  value=d1+d2+d3;
 for(;i<N;i++)
 {
  value+=v[i];

 }
 return value; 
}    
data_t Unroll4(data_t *v)
{
 data_t value,d1,d2,d3,d4;
 value=d1=d2=d3=d4=0.0; 
 long int i=0;
 long int limit = N-N%4;
  for(;i<limit;i+=4)
  {
    d1+=v[i+0];
    d2+=v[i+1];
    d3+=v[i+2];
    d4+=v[i+3]; 
 }

  value=d1+d2+d3+d4;
 for(;i<N;i++)
 {
  value+=v[i];

 }
return value;
}

data_t Unroll5(data_t *v)
{
 
 data_t value,d1,d2,d3,d4,d5;
  value = d1=d2=d3=d4=d5=0.0;
 long int i=0;
 long int limit = N-N%5;
  for(;i<limit;i+=5)
  {
    d1+=v[i+0];
    d2+=v[i+1];
    d3+=v[i+2];
    d4+=v[i+3]; 
    d5+=v[i+4];
 }

  value=d1+d2+d3+d4+d5;
 for(;i<N;i++)
 {
  value+=v[i];
 }
 return value;
}

data_t Unroll6(data_t *v)
{
 data_t value,d1,d2,d3,d4,d5,d6;
  value=d1=d2=d3=d4=d5=d6=0.0;
 long int i=0;
 long int limit = N-N%6;
  for(;i<limit;i+=6)
  {
    d1+=v[i+0];
    d2+=v[i+1];
    d3+=v[i+2];
    d4+=v[i+3]; 
    d5+=v[i+4];
    d6+=v[i+5];
 }

  value=d1+d2+d3+d4+d5+d6;
 for(;i<N;i++)
 {
  value+=v[i];
 }
 return value;

}

data_t Unroll7(data_t *v)
{
 data_t value,d1,d2,d3,d4,d5,d6,d7;
 value=d1=d2=d3=d4=d5=d6=d7=0.0;
 long int i=0;
 long int limit = N-N%7;
  for(;i<limit;i+=7)
  {
    d1+=v[i+0];
    d2+=v[i+1];
    d3+=v[i+2];
    d4+=v[i+3]; 
    d5+=v[i+4];
    d6+=v[i+5];
    d7+=v[i+6];
 }


  value=d1+d2+d3+d4+d5+d6+d7;
 for(;i<N;i++)
 {
  value+=v[i];
 }
 return value;
}
data_t Unroll8(data_t *v)
{
 data_t value,d1,d2,d3,d4,d5,d6,d7,d8;
  value=d1=d2=d3=d4=d5=d6=d7=d8=0.0;
 long int i=0;
 long int limit = N-N%8;
  for(;i<limit;i+=8)
  {
    d1+=v[i+0];
    d2+=v[i+1];
    d3+=v[i+2];
    d4+=v[i+3]; 
    d5+=v[i+4];
    d6+=v[i+5];
    d7+=v[i+6];
    d8+=v[i+7];
 }


  value=d1+d2+d3+d4+d5+d6+d7+d8;
 for(;i<N;i++)
 {
  value+=v[i];
  }
  return value;
}

data_t Unroll9(data_t *v)
{
 data_t value,d1,d2,d3,d4,d5,d6,d7,d8,d9;
  value=d1=d2=d3=d4=d5=d6=d7=d8=d9=0.0;
 long int i=0;
 long int limit = N-N%9;
  for(;i<limit;i+=9)
  {
    d1+=v[i+0];
    d2+=v[i+1];
    d3+=v[i+2];
    d4+=v[i+3]; 
    d5+=v[i+4];
    d6+=v[i+5];
    d7+=v[i+6];
    d8+=v[i+7];
    d9+=v[i+8];
 }


  value=d1+d2+d3+d4+d5+d6+d7+d8+d9;
 for(;i<N;i++)
 {
  value+=v[i];
  }
 return value;
}

data_t Unroll10(data_t *v)
{
 data_t value,d1,d2,d3,d4,d5,d6,d7,d8,d9,d10;
 long int i=0;
 long int limit = N-N%10;
  for(;i<limit;i+=10)
  {
    d1+=v[i+0];
    d2+=v[i+1];
    d3+=v[i+2];
    d4+=v[i+3]; 
    d5+=v[i+4];
    d6+=v[i+5];
    d7+=v[i+6];
    d8+=v[i+7];
    d9+=v[i+8];
    d10+=v[i+9];
 }


  value=d1+d2+d3+d4+d5+d6+d7+d8+d9+d10;
 for(;i<N;i++)
 {
  value+=v[i];
  }
 return value;
}


int main()
{	
	data_t * buffer;
	tsc_counter a, b;
	double cycles, baseline;
        data_t result;
        int i,j;
         i=j=0;
	//N is a define
	buffer = (data_t*)malloc(sizeof(data_t)*N);
	//x = (float*)_mm_malloc(sizeof(float)*N,16);
	//y = (float*)_mm_malloc(sizeof(float)*N,16);
	//y_vec = (float*)_mm_malloc(sizeof(float)*N,16);

	/*if (M == NULL || x == NULL || y == NULL || y_vec == NULL)
		return 1;*/

	//init vars
	for (; i<N; i++){

			buffer[i] = rand();	
	}
			

	

	
	//-----------------------------------------Timing 1
	//warm up	

	//-----------------No Vec Warmup-------------------
	//lookup task b from the HW here
	//
	//State the Asm. Instructions used by the compiler as a comment here:
	//
	// <--- List of Instructions --->
	//-----------------------------------------Timing 1
	//warm up
       result=Unroll10(buffer);
      //  printf("%f\n",result); 

         CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(; j<NUM_RUNS; ++j)
	{ 
         result=Unroll10(buffer);   
      		
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
        printf("%lf cycles \n",cycles);
         printf("%f value\n",result);
	//printf("%lf cycles -> Speedup: %2.2f x through partially unrolled code - %1.0f\n",cycles,baseline/cycles,y[0]);


	//-----------------------------------------Timing 2
	//warm up
	/*	Unroll4(buffer,a);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(int i=0; i<NUM_RUNS; ++i)
	{ 
		Unroll4(buffer,a);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through vectorized code - %1.0f\n",cycles,baseline/cycles,y_vec[0]);
	
	

//	_mm_free(M);
//	_mm_free(y);
//	_mm_free(x);

*/
        free(buffer);  
	return 0;
}

