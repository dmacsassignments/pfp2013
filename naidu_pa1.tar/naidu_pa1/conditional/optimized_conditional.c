#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define n 2000
#define m 3000

int main()
{
  double **a, **b,  norm;
  int i, j, l;
  double temp1,temp2;
  a = (double**)malloc(n*sizeof(double*));
  b = (double**)malloc(n*sizeof(double*));
 int limit;
  for(i=0; i<n; i++)
    {
      a[i] = (double*)malloc(m*sizeof(double));
   
      b[i] = (double*)calloc(m, sizeof(double));
      for(j=0;j<n;j++) 
      {
           a[i][j] = drand48();    
         //  a[i][j+1]=drand48();
          // a[i][j+2]=drand48();
          // a[i][j+3]=drand48();
        //   a[i][j+4]=drand48();
          // a[i][j+5]=drand48();
         //  a[i][j+6]=drand48();
          // a[i][j+7]=drand48();
     }
    /*  for(;j<n;j++)
      {
         a[i][j]=drand48();
      }*/
    }
    
 //for(i=0; i<n; i++) b[i] = (double*)calloc(m, sizeof(double));
 

  for(l=1; l<=30; l++)
    {
     for(i=0;i<n;i++)
      {
        for(j=0;j<m;j+=8)
           {
              b[i][j] = 13.0*b[i][j]+a[i][j];
              b[i][j+2]=13.0*b[i][j+2]+a[i][j+2];
              b[i][j+4]=13.0*b[i][j+4]+a[i][j+4];
              b[i][j+6]=13.0*b[i][j+6]+a[i][j+6]; 
           }
         for(j=1;j<m;j+=8) 
           {           
             b[i][j] = 13.0*b[i][j]-a[i][j];
	     b[i][j+2]=13.0*b[i][j+2]-a[i][j+2];
            b[i][j+4]=13.0*b[i][j+4]-a[i][j+4];	
            b[i][j+6]=13.0*b[i][j+6]-a[i][j+6];
            }

	 
    }
 }

  norm = 0.0;
  temp1=temp2=0.0;//=temp3=temp4=0.0;
  limit=n-n%2; 
  for(i=0; i<limit; i+=2)
   {
     for(j=0; j<m; j++)
     {
       temp1+=fabs(b[i][j]*b[i][j]);
       temp2+=fabs(b[i+1][j]*b[i+1][j]);
       //temp3+=fabs(b[i+2][j]*b[i+2][j]);
       // temp4+=fabs(b[i+3][j]*b[i+3][j]);
     }
   }
     norm=temp1+temp2;//+temp3+temp4;
    for(;i<n;i++)
    {
      for(j=0;j<m;j++)
       {
         norm+=fabs(b[i][j]*b[i][j]);
        }
    }
  printf("norm: %10.4e    Value: %10.4e\n",norm, b[10][10]);
}
