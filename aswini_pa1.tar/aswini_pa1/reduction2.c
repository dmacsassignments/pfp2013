#include<stdio.h>
main()
{
  register int x=0,a=0,a1,a2,a3;
  register int* ptr;
  int buffer[100000000];
  //for(;x<100000000;x++) buffer[x] = 1;
  ptr = buffer;
  a1 = a2 = a3 = 0;
  for(x=0;x<100000000;x+=4){
     buffer[x]=1;
     buffer[x+1]=1;
     buffer[x+2]=1;
     buffer[x+3]=1;
     a+= *ptr++;
     a1+= *ptr++;
     a2+= *ptr++;
     a3+= *ptr++;
  }
  a = a+a1+a2+a3;
}
