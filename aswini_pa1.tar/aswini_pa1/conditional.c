#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define n 2000
#define m 3000

main()
{
  register double **a, **b, c, norm;
  register int i, j,l,k;
  
  a = (double**)malloc(n*sizeof(double*));
  b = (double**)malloc(n*sizeof(double*));

  for(i=0; i<n; i++)
    {
      a[i] = (double*)malloc(m*sizeof(double));
      b[i] = (double*)calloc(m, sizeof(double));
      for(j=0; j<n; j++) a[i][j] = drand48();
    }
    
  //for(i=0; i<n; i++) b[i] = (double*)calloc(m, sizeof(double));
 
  c = 13.0;

  for(l=1; l<=30; l++)
    {
      for(i=0;i<n;i+=2)
      {
	  for(j=0;j<m;j+=12)
	  {
		  b[i][j]   = c*b[i][j]  +a[i][j];
		  b[i][j+1] = c*b[i][j+1]-a[i][j+1];
		  b[i][j+2] = c*b[i][j+2]+a[i][j+2];
		  b[i][j+3] = c*b[i][j+3]-a[i][j+3];
		  b[i][j+4] = c*b[i][j+4]+a[i][j+4];
		  b[i][j+5] = c*b[i][j+5]-a[i][j+5];
		  b[i][j+6] = c*b[i][j+6]+a[i][j+6];
		  b[i][j+7] = c*b[i][j+7]-a[i][j+7];
		  b[i][j+8] = c*b[i][j+8]+a[i][j+8];
		  b[i][j+9] = c*b[i][j+9]-a[i][j+9];
		  b[i][j+10] = c*b[i][j+10]+a[i][j+10];
		  b[i][j+11] = c*b[i][j+11]-a[i][j+11];
	  }
          k = i+1;
	  for(j=0;j<m;j+=12)
	  {
		  b[k][j]   = c*b[k][j]  +a[k][j];
		  b[k][j+1] = c*b[k][j+1]-a[k][j+1];
		  b[k][j+2] = c*b[k][j+2]+a[k][j+2];
		  b[k][j+3] = c*b[k][j+3]-a[k][j+3];
		  b[k][j+4] = c*b[k][j+4]+a[k][j+4];
		  b[k][j+5] = c*b[k][j+5]-a[k][j+5];
		  b[k][j+6] = c*b[k][j+6]+a[k][j+6];
		  b[k][j+7] = c*b[k][j+7]-a[k][j+7];
		  b[k][j+8] = c*b[k][j+8]+a[k][j+8];
		  b[k][j+9] = c*b[k][j+9]-a[k][j+9];
		  b[k][j+10] = c*b[k][j+10]+a[k][j+10];
		  b[k][j+11] = c*b[k][j+11]-a[k][j+11];
	  }
      }
    }

  norm = 0.0;

  for(i=0; i<n; i++)
    for(j=0; j<m; j++)
      norm = norm + fabs(b[i][j]*b[i][j]);
 
  printf("norm: %10.4e    Value: %10.4e\n",norm, b[10][10]);
}
