/*
* comp.c - contains the function superslow that you need to optimize
*
*
*/

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


/* f(x1,x2, i, j) rotates the input vector
*/
double f(double x1, double x2, double* y1, double * y2, int i, int j)
{
	double m[2][2];	

	if (i %4 == 0)
	{
		m[0][0] = cos(i);
		m[0][1] = sin(i);
		m[1][0] = -sin(i);
		m[1][1] = cos(i);
	}
	else
	{
		m[0][0] = cos(-i);
		m[0][1] = sin(-i);
		m[1][0] = -sin(-i);
		m[1][1] = cos(-i);

	}

	*y1 = m[0][0] * x1 + m[0][1]* x2;
	*y2 = m[1][0] * x1 + m[1][1]* x2;
}

/* This is the function you need to optimize. It takes one
square matrix as input
*/
void superslow(smat_t *a)
{
	int i, j;
	double x1,x2,y1,y2;
	double sum1, sum2;


	// j is the column of a we're computing right now
	for(j = 0; j < a->n; j++)
	{

		// i is the row of a we're computing right now
		for(i = 0; i < a->n; i=i+2)        
		{            
			// First, compute f(A) for the element of a in question
			x1 = get_elt(a,i,j);
			x2 = get_elt(a,i+1,j);
			f(x1,x2,&y1,&y2, i, j);

			// Add this to the value of a we're computing and store it                
			sum1 = get_elt(a, i, j) + y1;
			sum2 = get_elt(a, i+1, j) + y2;
			set_elt(a, i, j, sum1);
			set_elt(a, i+1, j, sum2);            
		}
	}
}

void superslow1(smat_t *a)
{
        int i, j;
        double x1,x2,y1,y2;
        double sum1, sum2;
        int n = a->n;
        double m[2][2];
   
        for(j = 0; j < n; j++)
         {
          for(i = 0; i < n; i=i+2)
              {
               x1 = a->mat[i*n+j];
               x2 = a->mat[(i+1)*n+j];
               /*f(x1,x2,&y1,&y2, i, j);*/
               if (i%4 == 0)
                {
                 m[0][0] = cos(i);
                 m[0][1] = sin(i);
                 m[1][0] = -sin(i);
                 m[1][1] = cos(i);
                }
              else
                {
                 m[0][0] = cos(-i);
                 m[0][1] = sin(-i);
                 m[1][0] = -sin(-i);
                 m[1][1] = cos(-i);
                }

         y1 = m[0][0] * x1 + m[0][1]* x2;
         y2 = m[1][0] * x1 + m[1][1]* x2;
                             
               sum1 = x1 + y1;
               sum2 = x2 + y2;
               a->mat[i*n + j] = sum1;
               a->mat[(i+1)*n+j] = sum2;
              }
        }
}

void superslow2(smat_t *a)
{
        int i, j;
        double x1,x2,y1,y2;
        double sum1, sum2;
        int n = a->n;
        double m[2][2];

        for(i = 0; i < n; i+=2)
         {

               if (i%4 == 0)
                {
                 m[0][0] = cos(i);
                 m[0][1] = sin(i);
                 m[1][0] = -sin(i);
                 m[1][1] = cos(i);
                }
              else
                {
                 m[0][0] = cos(-i);
                 m[0][1] = sin(-i);
                 m[1][0] = -sin(-i);
                 m[1][1] = cos(i);
                }

          for(j = 0; j < n; j++)
              {
               x1 = a->mat[i*n+j];
               x2 = a->mat[(i+1)*n+j];
               /*f(x1,x2,&y1,&y2, i, j);*/
               

           
         y1 = m[0][0] * x1 + m[0][1]* x2;
         y2 = m[1][0] * x1 + m[1][1]* x2;

               sum1 = x1 + y1;
               sum2 = x2 + y2;
               a->mat[i*n + j] = sum1;
               a->mat[(i+1)*n+j] = sum2;
              }
        }
}

void superslow3(smat_t *a)
   {
        int i,j,j1;
        double x1,x2,y1,y2,x3,x4;
        double sum1, sum2 , sum3 ,sum4;
        int n = a->n;
        double m[2][2];

        for(i = 0; i < n; i+=4)
         {

           m[0][0] = cos(i);
           m[0][1] = sin(i);
           m[1][0] = -sin(i);
           m[1][1] = cos(i);
              
          for(j = 0; j < n; j++)
              {
               x1 = a->mat[i*n+j];
               x2 = a->mat[(i+1)*n+j];
               /*f(x1,x2,&y1,&y2, i, j);*/

               y1 = m[0][0] * x1 + m[0][1]* x2;
               y2 = m[1][0] * x1 + m[1][1]* x2;

               sum1 = x1 + y1;
               sum2 = x2 + y2;
               a->mat[i*n + j] = sum1;
               a->mat[(i+1)*n+j] = sum2;
              }
              
               m[0][0] = cos(i+2);
               m[0][1] = -sin(i+2);
               m[1][0] =  sin(i+2);
               m[1][1] =  cos(i+2);
               
               for(j1 = 0; j1 < n; j1++)
              {
               x3 = a->mat[(i+2)*n+j1];
               x4 = a->mat[(i+3)*n+j1];
               /*f(x1,x2,&y1,&y2, i, j);*/

               y1 = m[0][0] * x3 + m[0][1]* x4;
               y2 = m[1][0] * x3 + m[1][1]* x4;

               sum3 = x3 + y1;
               sum4 = x4 + y2;
               a->mat[(i+2)*n+j1] = sum3;
               a->mat[(i+3)*n+j1] = sum4;
              }
               
               
              
        }
}

void superslow4(smat_t *a)
{
        int i,j,i1,i2,j1,j2 ;
        double x1,x2,y1,y2,x3,x4,x5,x6,y3,y4,y5,y6,x7,x8;
        double sum1,sum2,sum3,sum4,sum5,sum6,sum7,sum8;
        int n = a->n;
        double m[2][2];
        double m1[2][2];

        for(i = 0; i < n; i+=12)
         {

           m[0][0] = cos(i);
           m[0][1] = sin(i);
           m[1][0] = -sin(i);
           m[1][1] = cos(i);
           
           
          for(j = 0; j < n; j+=2)
              {
               x1 = a->mat[i*n+j];
               x2 = a->mat[(i+1)*n+j];
               /*f(x1,x2,&y1,&y2, i, j);*/

               y1 = m[0][0] * x1 + m[0][1]* x2;
               y2 = m[1][0] * x1 + m[1][1]* x2;

               sum1 = x1 + y1;
               sum2 = x2 + y2;
               a->mat[i*n + j] = sum1;
               a->mat[(i+1)*n+j] = sum2;
               
               x7 = a->mat[i*n+j+1];
               x8 = a->mat[(i+1)*n+j+1];
               /*f(x1,x2,&y1,&y2, i, j);*/

               y5 = m[0][0] * x7 + m[0][1]* x8;
               y6 = m[1][0] * x7 + m[1][1]* x8;

               sum7 = x7 + y5;
               sum8 = x8 + y6;
               a->mat[i*n + j+1] = sum7;
               a->mat[(i+1)*n+j+1] = sum8;
               
              }
              
               m[0][0] = cos(i+2);
               m[0][1] = -sin(i+2);
               m[1][0] =  sin(i+2);
               m[1][1] =  cos(i+2);
               
               for(j = 0; j < n; j++)
              {
               x3 = a->mat[(i+2)*n+j];
               x4 = a->mat[(i+3)*n+j];
               /*f(x1,x2,&y1,&y2, i, j);*/

               y3 = m[0][0] * x3 + m[0][1]* x4;
               y4 = m[1][0] * x3 + m[1][1]* x4;

               sum3 = x3 + y3;
               sum4 = x4 + y4;
               a->mat[(i+2)*n + j] = sum3;
               a->mat[(i+3)*n + j] = sum4;
              }

           /*unroll2*/
           i1 = i+4;               
           m1[0][0] = cos(i1);
           m1[0][1] = sin(i1);
           m1[1][0] = -sin(i1);
           m1[1][1] = cos(i1);
            
              
          for(j1 = 0; j1 < n; j1++)
              {
               x1 = a->mat[i1*n+j1];
               x2 = a->mat[(i1+1)*n+j1];
               
               y1 = m1[0][0] * x1 + m1[0][1]* x2;
               y2 = m1[1][0] * x1 + m1[1][1]* x2;

               sum5 = x1 + y1;
               sum6 = x2 + y2;
               a->mat[i1*n + j1] = sum5;
               a->mat[(i1+1)*n+j1] = sum6;
              }
              
               m1[0][0] = cos(i1+2);
               m1[0][1] = -sin(i1+2);
               m1[1][0] =  sin(i1+2);
               m1[1][1] =  cos(i1+2);
               
               for(j1 = 0; j1 < n; j1++)
              {
               x3 = a->mat[(i1+2)*n+j1];
               x4 = a->mat[(i1+3)*n+j1];
               

               y3 = m1[0][0] * x3 + m1[0][1]* x4;
               y4 = m1[1][0] * x3 + m1[1][1]* x4;

               sum3 = x3 + y3;
               sum4 = x4 + y4;
               a->mat[(i1+2)*n + j1] = sum3;
               a->mat[(i1+3)*n+j1] = sum4;
              }  
              
             /*Unroll3 */
             i2 = i+8;               
           m[0][0] = cos(i2);
           m[0][1] = sin(i2);
           m[1][0] = -sin(i2);
           m[1][1] = cos(i2);
            
              
          for(j = 0; j < n; j++)
              {
               x3 = a->mat[i2*n+j];
               x4 = a->mat[(i2+1)*n+j];
               
               y1 = m[0][0] * x3 + m[0][1]* x4;
               y2 = m[1][0] * x3 + m[1][1]* x4;

               sum1 = x3 + y1;
               sum2 = x4 + y2;
               a->mat[i2*n + j] = sum1;
               a->mat[(i2+1)*n+j] = sum2;
              }
              
               m[0][0] =  cos(i2+2);
               m[0][1] = -sin(i2+2);
               m[1][0] =  sin(i2+2);
               m[1][1] =  cos(i2+2);
               
               for(j2 = 0; j2 < n; j2+=2)
              {
               x5 = a->mat[(i2+2)*n+j2];
               x6 = a->mat[(i2+3)*n+j2];
       
               y3 = m[0][0] * x5 + m[0][1]* x6;
               y4 = m[1][0] * x5 + m[1][1]* x6;

               sum3 = x5 + y3;
               sum4 = x6 + y4;
               a->mat[(i2+2)*n + j2] = sum3;
               a->mat[(i2+3)*n+j2] = sum4;
               
               /*inner loop unroll*/
               x3 = a->mat[(i2+2)*n+j2+1];
               x4 = a->mat[(i2+3)*n+j2+1];
       
               y1 = m[0][0] * x3 + m[0][1]* x4;
               y2 = m[1][0] * x3 + m[1][1]* x4;

               sum1 = x3 + y1;
               sum2 = x4 + y2;
               a->mat[(i2+2)*n + j2+1] = sum1;
               a->mat[(i2+3)*n+j2+1] = sum2;
              }  
               
              
        }
}



/* 
* Called by the driver to register your functions
* Use add_function(func, description) to add your own functions
*/
void register_functions()
{
	// Registers comp_superslow with the driver
	add_function(&superslow, "superslow: original function");
	add_function(&superslow1, "superslow1: optimized version 1");
	add_function(&superslow2, "superslow2: optimized version 2");
	add_function(&superslow3, "superslow3: optimized version 3");
        add_function(&superslow4, "superslow4: optimized version 4");
        //add_function(&superslow5, "superslow5: optimized version 5");
	//Add your functions here
	//add_function(&superslow2, "superslow: Optimization X");


}
