/*
* comp.c - contains the function superslow that you need to optimize
*
*
*/

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"
#include<immintrin.h>
#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


/* f(x1,x2, i, j) rotates the input vector
*/
inline double f(double x1, double x2, double* y1, double * y2, int i, int j)
{
	double m[2][2];	

	if (i %4 == 0)
	{
		m[0][0] = cos(i);
		m[0][1] = sin(i);
		m[1][0] = -sin(i);
		m[1][1] = cos(i);
	}
	else
	{
		m[0][0] = cos(-i);
		m[0][1] = sin(-i);
		m[1][0] = -sin(-i);
		m[1][1] = cos(-i);

	}

	*y1 = m[0][0] * x1 + m[0][1]* x2;
	*y2 = m[1][0] * x1 + m[1][1]* x2;
}

/* This is the function you need to optimize. It takes one
square matrix as input
*/
void superslow(smat_t *a)
{
	int i, j;
	double x1,x2,y1,y2;
	double sum1, sum2;


	// j is the column of a we're computing right now
	for(j = 0; j < a->n; j++)
	{

		// i is the row of a we're computing right now
		for(i = 0; i < a->n; i=i+2)        
		{            
			// First, compute f(A) for the element of a in question
			x1 = get_elt(a,i,j);
			x2 = get_elt(a,i+1,j);
			f(x1,x2,&y1,&y2, i, j);

			// Add this to the value of a we're computing and store it                
			sum1 = get_elt(a, i, j) + y1;
			sum2 = get_elt(a, i+1, j) + y2;
			set_elt(a, i, j, sum1);
			set_elt(a, i+1, j, sum2);            
		}
	}
}
void superslow1(smat_t *a)
{
	int i, j,ind;
	double x1,x2,y1,y2;
	double sum1, sum2;
	double *mat = a->mat;
        ind = a->n;

	// j is the column of a we're computing right now
	for(j = 0; j < ind; j++)
	{

		// i is the row of a we're computing right now
		for(i = 0; i < ind; i=i+2)        
		{            
			// First, compute f(A) for the element of a in question
			x1 = mat[i*ind+j];
			x2 = mat[(i+1)*ind+j];
			f(x1,x2,&y1,&y2, i, j);
			// Add this to the value of a we're computing and store it                
			sum1 = x1 + y1;
			sum2 = x2 + y2;
			mat[i*ind+j] =  sum1;
			mat[(i+1)*ind+j] = sum2;;           
 
		}
	}
}

void superslow2(smat_t *a)
{
	int i, j,ind;
        double m[2][2];
	double x1,x2,y1,y2;
	double sum1, sum2;
	double *mat = a->mat;
        ind = a->n;

	// j is the column of a we're computing right now
	for(j = 0; j < ind; j++)
	{

		// i is the row of a we're computing right now
		for(i = 0; i < ind; i=i+2)        
		{            
			// First, compute f(A) for the element of a in question
			x1 = mat[i*ind+j];
			x2 = mat[(i+1)*ind+j];
			//f(x1,x2,&y1,&y2, i, j);
			if (i %4 == 0)
 	                {
                	   m[0][0] = cos(i);
	                   m[0][1] = sin(i);
	                   m[1][0] = -sin(i);
 	                   m[1][1] = cos(i);
        		}
		        else
        		{
	                   m[0][0] = cos(-i);
        	           m[0][1] = sin(-i);
                           m[1][0] = -sin(-i);
	                   m[1][1] = cos(-i);
			}
        	

		        y1 = m[0][0] * x1 + m[0][1]* x2;
		        y2 = m[1][0] * x1 + m[1][1]* x2;

			// Add this to the value of a we're computing and store it                
			sum1 = x1 + y1;
			sum2 = x2 + y2;
			mat[i*ind+j] =  sum1;
			mat[(i+1)*ind+j] = sum2;           
 
		}
	}
}

void superslow3(smat_t *a)
{
	register int i, j,ind,ind1,ind2,ind3,ind4;
	double x1,x2,x3,x4,y1,y2,y3,y4;
	double *mat = a->mat;
        ind = a->n;
	double *jmat;
	
	// j is the column of a we're computing right now
	for(i = 0; i < ind; i+=4)
	{ind1 = i*ind;
   	 ind2 = (i+1)*ind;
	 ind3 = (i+2)*ind;
	 ind4 = (i+3)*ind;
		// i is the row of a we're computing right now
		for(j = 0; j < ind; j++)        
		{            
		        jmat = mat +j;
			// First, compute f(A) for the element of a in question
			x1 = jmat[ind1];
			x2 = jmat[ind2];
			x3 = jmat[ind3];
			x4 = jmat[ind4];
		        y1 = cos(i) * x1 + sin(i)* x2;
		        y2 = (-(sin(i))) * x1 + cos(i)* x2;


			// Add this to the value of a we're computing and store it                
			jmat[ind1] =  x1 + y1;
			jmat[ind2] =  x2 + y2;           
		        
	                   
		        y3 = (cos(-(i+2))) * x3 + (sin(-(i+2)))* x4;
		        y4 = (-(sin(-(i+2)))) * x3 + (cos(-(i+2)))* x4;


			// Add this to the value of a we're computing and store it                
			jmat[ind3] = x3 + y3;
			jmat[ind4] = x4 + y4;           
        	
		}
	}
}

void superslow4(smat_t *a)
{
	register int i, j,ind;
	register double x1,x2,y1,y2;
	double *mat = a->mat;
        ind = a->n;
	for(i = 0; i < ind; i+=4)
	{

		// i is the row of a we're computing right now
		for(j = 0; j < ind; j++)       
		{           
			// First, compute f(A) for the element of a in question
			x1 = mat[i*ind+j];
			x2 = mat[(i+1)*ind+j];

		        y1 = cos(i) * x1 + sin(i)* x2;
		        y2 = (-(sin(i))) * x1 + cos(i)* x2;


			// Add this to the value of a we're computing and store it                
			mat[i*ind+j] =  x1 + y1;
			mat[(i+1)*ind+j] = x2 + y2;          
 
                        x1 = mat[(i+2)*ind+j];
			x2 = mat[(i+3)*ind+j];
		
        	
		        y1 = (cos(-(i+2))) * x1 + (sin(-(i+2)))* x2;
		        y2 = (-(sin(-(i+2)))) * x1 + (cos(-(i+2)))* x2;

			mat[(i+2)*ind+j] = x1 + y1;
			mat[(i+3)*ind+j] = x2 + y2;
		}
	}
}

void superslow5(smat_t *a)
{
	register int i, j,ind,ind1,ind2,ind3,ind4;
	register double x1,x2,y1,y2;
	double *mat = a->mat;
        ind = a->n;
	register double m0,m1,m2,m3;
        double *jmat;
	// j is the column of a we're computing right now
	for(i = 0; i < ind; i+=4)
	{ind1 = i*ind;
	 ind2 = (i+1)*ind;
	 ind3 = (i+2)*ind;
	 ind4 = (i+3)*ind;

		// i is the row of a we're computing right now
		for(j = 0; j < ind; j++)       
		{     jmat = mat + j;
			// First, compute f(A) for the element of a in question
			x1 = jmat[ind1];
			x2 = jmat[ind2];
                	   m0 = cos(i);
	                   m1 = sin(i);
	                   m2 = -sin(i);
 	                   m3 = cos(i);

		        y1 = m0 * x1 + m1* x2;
		        y2 = m2 * x1 + m3* x2;


			// Add this to the value of a we're computing and store it                
			jmat[ind1] =  x1 + y1;
			jmat[ind2] = x2 + y2;          
 
                        x1 = jmat[ind3];
			x2 = jmat[ind4];
		
			   m0 = cos(-(i+2));
        	           m1 = sin(-(i+2));
                           m2 = -sin(-(i+2));
	                   m3 = cos(-(i+2));
        	
		        y1 = m0 * x1 + m1* x2;
		        y2 = m2 * x1 + m3* x2;

			jmat[ind3] = x1 + y1;
			jmat[ind4] = x2 + y2;
		}
	}
}


void superslow6(smat_t *a)
{
	register int i, j,ind,ind1,ind2,ind3,ind4;
	register double x1,x2,x3,x4,y1,y2,y3,y4;
	double *mat = a->mat;
        ind = a->n;
	double *jmat1,*jmat2;
	
	// j is the column of a we're computing right now
	for(i = 0; i < ind; i+=4)
	{ind1 = i*ind;
   	 ind2 = (i+1)*ind;
	 ind3 = (i+2)*ind;
	 ind4 = (i+3)*ind;
		// i is the row of a we're computing right now
		for(j = 0; j < ind; j+=2)        
		{            
		        jmat1 = mat +j;
			jmat2 = mat+j+1;
			// First, compute f(A) for the element of a in question
			x1 = jmat1[ind1];
			x2 = jmat1[ind2];
			x3 = jmat1[ind3];
			x4 = jmat1[ind4];
		        

			y2 = (-(sin(i))) * x1 + cos(i)* x2;
		        y1 = cos(i) * x1 + sin(i)* x2;


			// Add this to the value of a we're computing and store it                
			jmat1[ind1] =  x1 + y1;
			jmat1[ind2] =  x2 + y2;           
		        
	                   
		        y3 = (cos(-(i+2))) * x3 + (sin(-(i+2)))* x4;
		        y4 = (-(sin(-(i+2)))) * x3 + (cos(-(i+2)))* x4;


			// Add this to the value of a we're computing and store it                
			jmat1[ind3] = x3 + y3;
			jmat1[ind4] = x4 + y4;           
        		
			x1 = jmat2[ind1];
			x2 = jmat2[ind2];
			x3 = jmat2[ind3];
			x4 = jmat2[ind4];
		        

			y2 = (-(sin(i))) * x1 + cos(i)* x2;
		        y1 = cos(i) * x1 + sin(i)* x2;


			// Add this to the value of a we're computing and store it                
			jmat2[ind1] =  x1 + y1;
			jmat2[ind2] =  x2 + y2;           
		        
	                   
		        y3 = (cos(-(i+2))) * x3 + (sin(-(i+2)))* x4;
		        y4 = (-(sin(-(i+2)))) * x3 + (cos(-(i+2)))* x4;


			// Add this to the value of a we're computing and store it                
			jmat2[ind3] = x3 + y3;
			jmat2[ind4] = x4 + y4;           
			

		}
	}
}

void superslow8(smat_t *a)
{
	register int i, j,ind,ind1,ind2,ind3,ind4;
	register double x1,x2,y1,y2;
	double *mat = a->mat;
        ind = a->n;
	register double m0,m1,m4,m5;
        double *jmat1,*jmat2;
	// j is the column of a we're computing right now
	for(i = 0; i < ind; i+=4)
	{ind1 = i*ind;
	 ind2 = (i+1)*ind;
	 ind3 = (i+2)*ind;
	 ind4 = (i+3)*ind;
                	   m0 = cos(i);
	                   m1 = sin(i);
	                 //  m2 = -sin(i);
 	                 //  m3 = cos(i);
         
			   m4 = cos(-(i+2));
        	           m5 = sin(-(i+2));
                         //  m6 = -sin(-(i+2));
	                 //  m7 = cos(-(i+2));

		// i is the row of a we're computing right now
		for(j = 0; j < ind; j+=1)       
		{     jmat1 = mat + j;
//		      jmat2 = mat+j+1;	
			// First, compute f(A) for the element of a in question
			x1 = jmat1[ind1];
			x2 = jmat1[ind2];

		        y1 = m0 * x1 + m1* x2;
		        y2 = (-(m1)) * x1 + m0* x2;


			// Add this to the value of a we're computing and store it                
			jmat1[ind1] =  x1 + y1;
			jmat1[ind2] = x2 + y2;          
 
                        x1 = jmat1[ind3];
			x2 = jmat1[ind4];
		
        	
		        y1 = m4 * x1 + m5* x2;
		        y2 = (-(m5)) * x1 + m4* x2;

			jmat1[ind3] = x1 + y1;
			jmat1[ind4] = x2 + y2;
			
		}
	}
}
void superslow9(smat_t *a)
{
	register int i, j,ind,ind1,ind2,ind3,ind4;
	register double x1,x2,y1,y2;
	double x3,x4,y3,y4;
	double *mat = a->mat;
        ind = a->n;
	register double m0,m1,m2,m3,m4,m5,m6,m7;
        double *jmat1,*jmat2;
	// j is the column of a we're computing right now
	for(i = 0; i < ind; i+=4)
	{ind1 = i*ind;
	 ind2 = (i+1)*ind;
	 ind3 = (i+2)*ind;
	 ind4 = (i+3)*ind;
                	   m0 = cos(i);
	                   m1 = sin(i);
	                   m2 = -sin(i);
 	                   m3 = cos(i);
         
			   m4 = cos(-(i+2));
        	           m5 = sin(-(i+2));
                           m6 = -sin(-(i+2));
	                   m7 = cos(-(i+2));

		// i is the row of a we're computing right now
		for(j = 0; j < ind; j+=2)       
		{     jmat1 = mat + j;
		      jmat2 = mat+j+1;	
			// First, compute f(A) for the element of a in question
			x1 = jmat1[ind1];
			x2 = jmat1[ind2];
			
			x3 = jmat2[ind1];
			x4 = jmat2[ind2];

		        y1 = m0 * x1 + m1* x2;
		        y2 = m2 * x1 + m3* x2;

		        y3 = m0 * x3 + m1* x4;
		        y4 = m2 * x3 + m3* x4;

			// Add this to the value of a we're computing and store it                
			jmat1[ind1] =  x1 + y1;
			jmat1[ind2] = x2 + y2;          
 
			jmat2[ind1] =  x3 + y3;
			jmat2[ind2] = x4 + y4;          
                        

			x1 = jmat1[ind3];
			x2 = jmat1[ind4];
		
                        x3 = jmat2[ind3];
			x4 = jmat2[ind4];
		        
			y1 = m4 * x1 + m5* x2;
		        y2 = m6 * x1 + m7* x2;
        	
		        y3 = m4 * x3 + m5* x4;
		        y4 = m6 * x3 + m7* x4;

			jmat1[ind3] = x1 + y1;
			jmat1[ind4] = x2 + y2;
			
			jmat2[ind3] = x3 + y3;
			jmat2[ind4] = x4 + y4;
		}
	}
}

void superslow10(smat_t *a)
{
        int i, j,ind;
        double x1,x2,y1,y2;
        double *mat = a->mat;
        ind = a->n;
	double m0,m1,m2,m3,m4,m5,m6,m7;
        for(i = 0; i < ind; i+=4)
        {		   m0= cos(i);
                           m1 = sin(i);
                           m2 = -sin(i);
                           m3 = cos(i);

                           m4 = cos(-(i+2));
                           m5 = sin(-(i+2));
                           m6 = -sin(-(i+2));
                           m7 = cos(-(i+2));


                /* i is the row of a we're computing right now*/
                for(j = 0; j < ind; j++)
                {
                        /* First, compute f(A) for the element of a in question*/
                        x1 = mat[i*ind+j];
                        x2 = mat[(i+1)*ind+j];

                        y1 = m0 * x1 + m1* x2;
                        y2 = m2 * x1 + m3* x2;


                        /* Add this to the value of a we're computing and store it                */
                        mat[i*ind+j] =  x1 + y1;
                        mat[(i+1)*ind+j] = x2 + y2;
                        x1 = mat[(i+2)*ind+j];
                        x2 = mat[(i+3)*ind+j];


                        y1 = m4 * x1 + m5* x2;
                        y2 = m6 * x1 + m7* x2;

                        mat[(i+2)*ind+j] = x1 + y1;
                        mat[(i+3)*ind+j] = x2 + y2;
                }
        }
}
void superslow12(smat_t *a)
{
        int i, j,ind;
        double x1,x2,y1,y2;
        double *mat = a->mat;
        ind = a->n;
        double m0,m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11,m12,m13,m14,m15;
	double t0,t1,t2,t3,t4,t5,t6,t7;
        for(i = 0; i < ind; i+=12)
        {                  m0= cos(i);
                           m1 = sin(i);
                           m2 = -sin(i);
                           m3 = cos(i);

                           m4 = cos(-(i+2));
                           m5 = sin(-(i+2));
                           m6 = -sin(-(i+2));
                           m7 = cos(-(i+2));


			   m8= cos(i+4);
                           m9 = sin(i+4);
                           m10 = -sin(i+4);
                           m11 = cos(i+4);

                           m12 = cos(-(i+6));
                           m13 = sin(-(i+6));
                           m14 = -sin(-(i+6));
                           m15 = cos(-(i+6));

			   t0= cos(i+8);
                           t1 = sin(i+8);
                           t2 = -sin(i+8);
                           t3 = cos(i+8);

                           t4 = cos(-(i+10));
                           t5 = sin(-(i+10));
                           t6 = -sin(-(i+10));
                           t7 = cos(-(i+10));

                /* i is the row of a we're computing right now*/
                for(j = 0; j < ind; j++)
                {
                        /* First, compute f(A) for the element of a in question*/
                        x1 = mat[i*ind+j];
                        x2 = mat[(i+1)*ind+j];

                        y1 = m0 * x1 + m1* x2;
                        y2 = m2 * x1 + m3* x2;


                        /* Add this to the value of a we're computing and store it                */
                        mat[i*ind+j] =  x1 + y1;
                        mat[(i+1)*ind+j] = x2 + y2;
                        x1 = mat[(i+2)*ind+j];
                        x2 = mat[(i+3)*ind+j];

                        y1 = m4 * x1 + m5* x2;
                        y2 = m6 * x1 + m7* x2;

                        mat[(i+2)*ind+j] = x1 + y1;
                        mat[(i+3)*ind+j] = x2 + y2;

			/* First, compute f(A) for the element of a in question*/
                        x1 = mat[(i+4)*ind+j];
                        x2 = mat[(i+5)*ind+j];

                        y1 = m8 * x1 + m9* x2;
                        y2 = m10 * x1 + m11* x2;


                        /* Add this to the value of a we're computing and store it                */
                        mat[(i+4)*ind+j] =  x1 + y1;
                        mat[(i+5)*ind+j] = x2 + y2;

                        x1 = mat[(i+6)*ind+j];
                        x2 = mat[(i+7)*ind+j];

                        y1 = m12 * x1 + m13* x2;
                        y2 = m14 * x1 + m15* x2;

                        mat[(i+6)*ind+j] = x1 + y1;
                        mat[(i+7)*ind+j] = x2 + y2;

			/* First, compute f(A) for the element of a in question*/
                        x1 = mat[(i+8)*ind+j];
                        x2 = mat[(i+9)*ind+j];

                        y1 = t0 * x1 + t1* x2;
                        y2 = t2 * x1 + t3* x2;


                        /* Add this to the value of a we're computing and store it                */
                        mat[(i+8)*ind+j] =  x1 + y1;
                        mat[(i+9)*ind+j] = x2 + y2;

                        x1 = mat[(i+10)*ind+j];
                        x2 = mat[(i+11)*ind+j];

                        y1 = t4 * x1 + t5* x2;
                        y2 = t6 * x1 + t7* x2;

                        mat[(i+10)*ind+j] = x1 + y1;
                        mat[(i+11)*ind+j] = x2 + y2;
                }
        }
}




/* 
* Called by the driver to register your functions
* Use add_function(func, description) to add your own functions
*/
void register_functions()
{
	// Registers comp_superslow with the driver
	add_function(&superslow, "superslow: original function");
	add_function(&superslow1, "superslow1: set and get functions were removed");
	add_function(&superslow2, "superslow2: f functions were removed");
	add_function(&superslow3, "superslow3: the cos and sin values were assigned directly");
	add_function(&superslow4, "superslow4: variables reuse");
	add_function(&superslow5, "superslow5: jmat pointer");
	add_function(&superslow6, "superslow6: jmat pointer with 2 way j with cos direct");
	add_function(&superslow8, "superslow8: jmat pointer with cos outside");
	add_function(&superslow9, "superslow9: jmat pointer with 2 way j cos outside");
	add_function(&superslow10, "superslow10: f function with cos out");
	add_function(&superslow12, "superslow12: f function with 12 way i cos out");
//	add_function(&fast, "fast: optimized version 1");
	//Add your functions here
	//add_function(&superslow2, "superslow: Optimization X");


}
