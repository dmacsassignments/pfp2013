const char* dgemm_desc = "My awesome dgemm.";
#include<smmintrin.h> 
#include<nmmintrin.h>
#include <immintrin.h>
#ifndef BLOCK_SIZE
#define BLOCK_SIZE ((int) 64)
#endif

#ifndef REG_BLOCK_SIZE
#define REG_BLOCK_SIZE ((int) 4)
#endif
extern double* D;
extern double* E;
extern double* F;
extern double* V;
void basic_dgemm(const int lda, const int M, const int N, const int K, const double * __restrict__ A, const double * __restrict__ B, double * __restrict__ C)
{	
    register int i, j, k;
    for (j = 0; j < N; ++j) 
    {
    for (k = 0; k < K; ++k) 
    { 
      register double bjk = B[j*lda+k];
      for (i = 0; i < M; ++i){ 
        C[j*lda+i] += A[k*lda+i] * bjk; //bjk; 
      }
    }
  }
  //__m128 B = _mm_load_ps(B);
}



void avx_dgemm(const int M, 
                  const double *A, const double *B, double *C)
{
   register int ii,jj,kk;
   register double *aPointer =NULL;
   register double *bPointer =NULL;
   register double *cPointer =NULL;
                for (jj= 0; jj <BLOCK_SIZE ; jj+=4) {
                    for (kk= 0; kk <BLOCK_SIZE; kk+=4) {
                       bPointer = B+kk+jj*M;
                        for (ii= 0; ii <BLOCK_SIZE; ii+=4){
                aPointer = A+ii+kk*M;
                cPointer = C+ii+jj*M; 

		 __m256d a0 = _mm256_loadu_pd(aPointer);
		 __m256d a1 = _mm256_loadu_pd(aPointer + M);
                 __m256d a2 = _mm256_loadu_pd(aPointer + 2*M);
		 __m256d a3 = _mm256_loadu_pd(aPointer + 3*M);

		 __m256d c0 = _mm256_add_pd(
			_mm256_add_pd(
				_mm256_mul_pd(a0,  _mm256_set1_pd(*(bPointer))),
				_mm256_mul_pd(a1,  _mm256_set1_pd(*(bPointer+1)))
			),
			_mm256_add_pd(
				_mm256_mul_pd(a2,  _mm256_set1_pd(*(bPointer+2))),
				_mm256_mul_pd(a3,  _mm256_set1_pd(*(bPointer+3)))
			)
		);


		
		 __m256d c1 = _mm256_add_pd(
			_mm256_add_pd(
				_mm256_mul_pd(a0,  _mm256_set1_pd(*(bPointer+M))),
				_mm256_mul_pd(a1,  _mm256_set1_pd(*(bPointer+M+1)))
			),
			_mm256_add_pd(
				_mm256_mul_pd(a2,  _mm256_set1_pd(*(bPointer+M+2))),
				_mm256_mul_pd(a3,  _mm256_set1_pd(*(bPointer+M+3)))
			)
		);


	 	 __m256d c2 = _mm256_add_pd(
			_mm256_add_pd(
				_mm256_mul_pd(a0,  _mm256_set1_pd(*(bPointer+2*M))),
				_mm256_mul_pd(a1,  _mm256_set1_pd(*(bPointer+2*M+1)))
			),
			_mm256_add_pd(
				_mm256_mul_pd(a2,  _mm256_set1_pd(*(bPointer+2*M+2))),
				_mm256_mul_pd(a3,  _mm256_set1_pd(*(bPointer+2*M+3)))
			)
		);

		 __m256d c3 = _mm256_add_pd(
			_mm256_add_pd(
				_mm256_mul_pd(a0,  _mm256_set1_pd(*(bPointer+3*M))),
				_mm256_mul_pd(a1,  _mm256_set1_pd(*(bPointer+3*M+1)))
			),
			_mm256_add_pd(
				_mm256_mul_pd(a2,  _mm256_set1_pd(*(bPointer+3*M+2))),
				_mm256_mul_pd(a3,  _mm256_set1_pd(*(bPointer+3*M+3)))
			)
		);
		



                 __m256d c4 = _mm256_loadu_pd(cPointer);
		 __m256d c5 = _mm256_loadu_pd(cPointer + M);
		 __m256d c6 = _mm256_loadu_pd(cPointer + 2*M);
		 __m256d c7 = _mm256_loadu_pd(cPointer + 3*M);

                  c4 = _mm256_add_pd(c0,c4);
		  c5 = _mm256_add_pd(c1,c5);
		  c6 = _mm256_add_pd(c2,c6);
		  c7 = _mm256_add_pd(c3,c7);

		_mm256_storeu_pd(cPointer, c4);
		_mm256_storeu_pd(cPointer + M, c5);
		_mm256_storeu_pd(cPointer + 2*M, c6);
		_mm256_storeu_pd(cPointer + 3*M, c7);

	  


			               
                                           }
                                       }
                                   }

 } 
                          


void ibasic_dgemm(const int lda, const int M, const int N, const int K, const double *__restrict__ A, const double *__restrict__ B, double *__restrict__ C)
{	
  if(M == BLOCK_SIZE  && N==K && M==K)
      avx_dgemm(lda,A,B,C);  
  else{ 
  register int i, j, k, J, J1, K1;
  register double b1, b2, b3, b4, b5, b6, b7, b8;
  register double c1, c2, c3, c4, c5, c6, c7, c8;
  for (j = 0; j < N; ++j) {
        J = j*lda;
  for (k = 0; k < (K - 7); k += 8) {
		 //__m256d a0 = _mm256_loadu_pd(B+J+k);
		 //__m256d a0 = _mm256_loadu_pd(B+J+k);
		 __m128d a0 = _mm_loadu_pd(B+J+k);
		 __m128d a1 = _mm_loadu_pd(B+J+k+2);
		 __m128d a2 = _mm_loadu_pd(B+J+k+4);
		 __m128d a3 = _mm_loadu_pd(B+J+k+6);
     //J1 = J + k;
  /*b1 = B[J1];
  b2 = B[J1 + 1];
  b3 = B[J1 + 2];
  b4 = B[J1 + 3];
  b5 = B[J1 + 4];
  b6 = B[J1 + 5];
  b7 = B[J1 + 6];
  b8 = B[J1 + 7];*/
  
  for (i = 0; i < M; ++i) {
       K1 = k*lda;
       V[0] = A[K1+i]; 
       V[1] = A[K1+lda+i]; 
       V[2] = A[K1+2*lda+i]; 
       V[3] = A[K1+3*lda+i]; 
       V[4] = A[K1+4*lda+i]; 
       V[5] = A[K1+5*lda+i]; 
       V[6] = A[K1+6*lda+i]; 
       V[7] = A[K1+7*lda+i]; 
		/* __m256d v0 = _mm256_loadu_pd(V);
		 __m256d v1 = _mm256_loadu_pd(V+4);
                 __m256d y0 =  _mm256_dp_pd(a0,v0,241);
                 __m256d y1 = _mm256_dp_pd(a1,v1,241);
                  y0 = _mm256_add_pd( y0,y1);*/
		 __m128d v0 = _mm_loadu_pd(V);
		 __m128d v1 = _mm_loadu_pd(V+2);
		 __m128d v2 = _mm_loadu_pd(V+4);
		 __m128d v3 = _mm_loadu_pd(V+6);
                 __m128d y0 = _mm_dp_pd(a0,v0,241);
                 __m128d y1 = _mm_dp_pd(a1,v1,241);
                 __m128d y2 = _mm_add_pd( y0,y1);
                  y0 = _mm_dp_pd(a2,v2,241);
                  y1 = _mm_dp_pd(a3,v3,241);
                  y1 = _mm_add_pd( y0,y1);
                  y0 = _mm_add_pd( y1,y2);
		               
		 __m128d c0 = _mm_loadu_pd(C+J+i);
                  y0 = _mm_add_pd( y0,c0);
                   _mm_storeu_pd(C+J+i, y0);
     
       /*c1 = A[K1 + i] * b1 ;
       c2= A[K1+lda + i] * b2 ;
       c3= A[K1+2*lda + i] * b3 ;
       c4=A[K1+3*lda + i] * b4 ;
       c5=A[K1+4*lda + i] * b5 ;
       c6=A[K1+5*lda + i] * b6 ;
       c7=A[K1+6*lda + i] * b7 ;
       c8=A[K1+7*lda + i] * b8;*/
      //C[J+i] += c1+c2+c3+c4+c5+c6+c7+c8;  
   }
   }
   if(K % 8) {
   do {
   b1 = B[j*lda + k];
   for (i = 0; i < M; ++i) {
   C[j*lda + i] += A[k*lda + i] * b1;
   }
   }
   while(++k < K);
   }
   }
 
   }//else
}

void do_reg_block(const int lda, const double *A, const double *B, double *C, int i, int j, int k,int M,int N,int K)
{
      int temp1,temp2,temp3;

      if(i>M || j>N || k>K)
              M=0,N=0,K=0,i=0,j=0,k=0; 
      M = (M < (temp1=(i+REG_BLOCK_SIZE > M? M-i : REG_BLOCK_SIZE))?M:temp1);
      N = (N < (temp2=(j+REG_BLOCK_SIZE > N? N-j : REG_BLOCK_SIZE))?N:temp2);
      K = (K < (temp3=(k+REG_BLOCK_SIZE > K? K-k : REG_BLOCK_SIZE))?K:temp3);
      basic_dgemm(lda, M, N, K,A + i + k*lda, B + k + j*lda, C + i + j*lda);
}
 

void basic_reg_dgemm(const int lda, const int M, const int N, const int K, const double *A, const double *B, double *C,const int max)
{
      
    const int n_reg_blocks_m =  max / REG_BLOCK_SIZE + (max%REG_BLOCK_SIZE? 1 : 0);
    int ri, rj, rk;
    for (rj = 0; rj < n_reg_blocks_m; ++rj) {
        const int j = rj * REG_BLOCK_SIZE;
        for (rk = 0; rk < n_reg_blocks_m; ++rk) {
            const int k = rk * REG_BLOCK_SIZE;
            for (ri = 0; ri < n_reg_blocks_m; ++ri) {
                const int i = ri * REG_BLOCK_SIZE;
                     do_reg_block(lda,A, B, C, i, j, k,M,N,K);  
                     
                }
            }
        }
}

 /*if(M==1024){
   int i1,k1; 
  for(i1=0;i1<M;i1++)
   for(k1=0;k1<K;k1++)
    D[i1*M+k1] = A[i1*lda+k1]; 
    
      ibasic_dgemm(lda, M, N, K,D + i + k*lda, B + k + j*lda, C + i + j*lda);}
  else*/
void do_block(const int lda, const double *A, const double *B, double *C, const int i, const int j, const int k)
{
      const int M = (i+BLOCK_SIZE > lda? lda-i : BLOCK_SIZE);
      const int N = (j+BLOCK_SIZE > lda? lda-j : BLOCK_SIZE);
  //    register int max = M; 
    //  if(N > M) max = N;
      const int K = (k+BLOCK_SIZE > lda? lda-k : BLOCK_SIZE);
      //if(K > max) max = K;
      ibasic_dgemm(lda, M, N, K,A + i + k*lda, B + k + j*lda, C + i + j*lda);
     
      //basic_reg_dgemm(lda, M, N, K,A + i + k*lda, B + k + j*lda, C + i + j*lda,max);
}
 
void itranspose( int n, int blocksize, double *dst, double *src ) {
    int i,j,k,l;
    /* to do: implement blocking (two more loops) */
    /*for( i = 0; i < n; i++ )
        for( j = 0; j < n; j++ )
            dst[j+i*n] = src[i+j*n];*/
    //register int temp;
    int blocksize1 = n - (n % blocksize);  
    for (i = 0; i < blocksize1; i += blocksize) {
         for (j = 0; j < blocksize1; j += blocksize) {
             // transpose the block beginning at [i,j]
                   for (k = i; k < i + blocksize; ++k) {
                              for ( l = j; l < j + blocksize; ++l) {
                                             dst[k + l*n] = src[l + k*n];
                              }
                    }
          } 
     }
     for (k = 0; k < n; ++k) {
        for ( l = j; l < n; ++l) {
                    dst[k + l*n] = dst[l + k*n];
        }
     }
     for(k = i; k < n; ++k) {
        for( l = 0;l < blocksize1; ++l) {
                    dst[k + l*n] = dst[l + k*n];
        }
     }
     
}


void square_dgemm(const int M, const double *A, const double *B, double *C)
{
   //transpose(M,64,D,A);
   register int n_blocks = M / BLOCK_SIZE + (M%BLOCK_SIZE? 1 : 0);
    register int bi, bj, bk;
    for (bj = 0; bj < n_blocks; ++bj) {
        register const int j = bj * BLOCK_SIZE;
        for (bk = 0; bk < n_blocks; ++bk) {
            register const int k = bk * BLOCK_SIZE;
            for (bi = 0; bi < n_blocks; ++bi) {
                register const int i = bi * BLOCK_SIZE;
                     do_block(M, A, B, C, i, j, k);
            }
        }
    }
}

