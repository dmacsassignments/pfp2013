const char* dgemm_desc = "Simple blocked dgemm.";

#include<smmintrin.h> 
#include<nmmintrin.h>
#include <immintrin.h>
#ifndef BLOCK_SIZE
#define BLOCK_SIZE ((int) 64)
#define RB ((int)4)
#endif

/*
  A is M-by-K
  B is K-by-N
  C is M-by-N

  lda is the leading dimension of the matrix (the M of square_dgemm).
*/


void avx_dgemm(const int M, 
                  const double *A, const double *B, double *C)
{
   register int ii,jj,kk;
   register double *aPointer =NULL;
   register double *bPointer =NULL;
   register double *cPointer =NULL;
                for (jj= 0; jj <BLOCK_SIZE ; jj+=RB) {
                    for (kk= 0; kk <BLOCK_SIZE; kk+=RB) {
                       bPointer = B+kk+jj*M;
                        for (ii= 0; ii <BLOCK_SIZE; ii+=RB){
                aPointer = A+ii+kk*M;
                cPointer = C+ii+jj*M; 

		 __m256d a0 = _mm256_loadu_pd(aPointer);
		 __m256d a1 = _mm256_loadu_pd(aPointer + M);
                 __m256d a2 = _mm256_loadu_pd(aPointer + 2*M);
		 __m256d a3 = _mm256_loadu_pd(aPointer + 3*M);

		 __m256d c0 = _mm256_add_pd(
			_mm256_add_pd(
				_mm256_mul_pd(a0,  _mm256_set1_pd(*(bPointer))),
				_mm256_mul_pd(a1,  _mm256_set1_pd(*(bPointer+1)))
			),
			_mm256_add_pd(
				_mm256_mul_pd(a2,  _mm256_set1_pd(*(bPointer+2))),
				_mm256_mul_pd(a3,  _mm256_set1_pd(*(bPointer+3)))
			)
		);


		
		 __m256d c1 = _mm256_add_pd(
			_mm256_add_pd(
				_mm256_mul_pd(a0,  _mm256_set1_pd(*(bPointer+M))),
				_mm256_mul_pd(a1,  _mm256_set1_pd(*(bPointer+M+1)))
			),
			_mm256_add_pd(
				_mm256_mul_pd(a2,  _mm256_set1_pd(*(bPointer+M+2))),
				_mm256_mul_pd(a3,  _mm256_set1_pd(*(bPointer+M+3)))
			)
		);

	 	 __m256d c2 = _mm256_add_pd(
			_mm256_add_pd(
				_mm256_mul_pd(a0,  _mm256_set1_pd(*(bPointer+2*M))),
				_mm256_mul_pd(a1,  _mm256_set1_pd(*(bPointer+2*M+1)))
			),
			_mm256_add_pd(
				_mm256_mul_pd(a2,  _mm256_set1_pd(*(bPointer+2*M+2))),
				_mm256_mul_pd(a3,  _mm256_set1_pd(*(bPointer+2*M+3)))
			)
		);

		 __m256d c3 = _mm256_add_pd(
			_mm256_add_pd(
				_mm256_mul_pd(a0,  _mm256_set1_pd(*(bPointer+3*M))),
				_mm256_mul_pd(a1,  _mm256_set1_pd(*(bPointer+3*M+1)))
			),
			_mm256_add_pd(
				_mm256_mul_pd(a2,  _mm256_set1_pd(*(bPointer+3*M+2))),
				_mm256_mul_pd(a3,  _mm256_set1_pd(*(bPointer+3*M+3)))
			)
		);
		



                 __m256d c4 = _mm256_loadu_pd(cPointer);
		 __m256d c5 = _mm256_loadu_pd(cPointer + M);
		 __m256d c6 = _mm256_loadu_pd(cPointer + 2*M);
		 __m256d c7 = _mm256_loadu_pd(cPointer + 3*M);

                  c4 = _mm256_add_pd(c0,c4);
		  c5 = _mm256_add_pd(c1,c5);
		  c6 = _mm256_add_pd(c2,c6);
		  c7 = _mm256_add_pd(c3,c7);

		_mm256_storeu_pd(cPointer, c4);
		_mm256_storeu_pd(cPointer + M, c5);
		_mm256_storeu_pd(cPointer + 2*M, c6);
		_mm256_storeu_pd(cPointer + 3*M, c7);

	  


			               
                                           }
                                       }
                                   }
                               
                          

}






             
void basic_dgemm(const int lda, const int M, const int N, const int K,
                 const double *A, const double *B, double *C)
{  

   if(M==N==K)
	avx_dgemm(lda,A,B,C);
   else
   {
   register int i, j, k;
   register double *cptr,*aptr,*bptr;
    for (j = 0; j < N; ++j) {
        bptr = B+j*lda;
	cptr = C+j*lda;
        for (k = 0; k < K; ++k) {
           register double bkj = *(bptr+k);
           aptr = A+k*lda;
            for (i = 0; i < M; ++i) {
               *(cptr+i)+=(*(aptr+i))*bkj;
            }
           
        }
      }  
   }
}
void do_block(const int lda,
              const double *A, const double *B, double *C,
              const int i, const int j, const int k)
{
    const int M = (i+BLOCK_SIZE > lda? lda-i : BLOCK_SIZE);
    const int N = (j+BLOCK_SIZE > lda? lda-j : BLOCK_SIZE);
    const int K = (k+BLOCK_SIZE > lda? lda-k : BLOCK_SIZE);
    basic_dgemm(lda, M, N, K,
                A + i + k*lda, B + k + j*lda, C + i + j*lda);
}

void square_dgemm(const int M, const double *A, const double *B, double *C)
{
    register const int n_blocks = M / BLOCK_SIZE + (M%BLOCK_SIZE? 1 : 0);
    int bi, bj, bk;
    for (bi = 0; bi < n_blocks; ++bi) {
        const int i = bi * BLOCK_SIZE;
        for (bj = 0; bj < n_blocks; ++bj) {
            const int j = bj * BLOCK_SIZE;
            for (bk = 0; bk < n_blocks; ++bk) {
                const int k = bk * BLOCK_SIZE;
                do_block(M, A, B, C, i, j, k);
            }
        }
    }
}

