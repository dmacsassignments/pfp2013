/*
 * MVM 5x5
 */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

#include <tmmintrin.h>

#include "utils.h"
#include "rdtsc.h"
#include <smmintrin.h>
#include <nmmintrin.h>
#include<iacaMarks.h>
// Procedure mvm5: Serial code (do not need to modify)

void mvm5(float const * A, float const * x, float * y) {
  int i;
  float t;
  int j;
  for(i = 0; i < 5; i++) {
      t = 0.f;
      for(j = 0; j < 5; j++)
        t += A[i*5+j]*x[j];
      y[i] = t;
  }

}



// Procedure vec_mvm5: vector code
// Implement WITHOUT unaligned instructions

void vec_mvm5(float const * A, float const * x, float * y) {

/*typedef union
{
       struct
       {
              __m128 m1, m2, m3, m4,m5,m6;
       }row;

        struct
       {
              float m11, m12, m13, m14,m15;
              float m21, m22, m23, m24, m25;
              float m31, m32, m33, m34, m35;
              float m41, m42, m43, m44, m45;
              float m51,m52,m53,m54;
       }element;
}matrix;*/

typedef union
{ 
   struct { 
       __m128 v1, v2 ;
   }vec;
  struct
  { float a1,a2,a3,a4,a5,a6,a7,a8; }element;
}vector;

vector v;    
//matrix a;

//IACA_START
// a.row.m1 =   _mm_load_ps(A);
 const __m128 m1 =   _mm_load_ps(A);
 const __m128 m2 = _mm_load_ps(A+4);
 const __m128 m3 = _mm_load_ps(A+8);
 const __m128 m4 = _mm_load_ps(A+12);
 const __m128 m5 = _mm_load_ps(A+16);
 const __m128 m6 = _mm_load_ps(A+20);

 v.vec.v1 = _mm_load_ps(x);

 __m128 b = _mm_dp_ps(m1, v.vec.v1, 241);

 __m128 one = _mm_set1_ps(1.0);
  v.vec.v2 = _mm_load_ss(x+4);
  __m128i intv1 = _mm_castps_si128(v.vec.v1);
  // a.row.m2 = _mm_load_ps(A+4);
   v.vec.v2 = _mm_set_ps(v.element.a5,v.element.a1,v.element.a2,v.element.a3);


  __m128i intv2 = _mm_castps_si128(v.vec.v2);
   __m128 temp = _mm_mul_ps(m2, v.vec.v2);


    //m3 = _mm_load_ps(A+8);
//
   __m128i inttemp = _mm_castps_si128(temp); 

  //  b = _mm_add_ps(b,temp);
  __m128 temp1 = _mm_castsi128_ps(_mm_alignr_epi8(intv1,intv2,12));
  

  __m128 temp3 = _mm_mul_ps(m3, temp1);
//2
  temp1 = _mm_castsi128_ps(_mm_alignr_epi8(intv1,intv2,8));
  __m128i inttemp3 = _mm_castps_si128(temp3); 
//  a.row.m4 = _mm_load_ps(A+12);

    __m128 result1 =  _mm_castsi128_ps(_mm_alignr_epi8(inttemp3,inttemp,4));
    __m128 result5 = _mm_insert_ps(temp3,temp,0x9E);
  temp = _mm_mul_ps(m4, temp1);
  inttemp = _mm_castps_si128(temp); 
  __m128 result2 = _mm_castsi128_ps(_mm_alignr_epi8(inttemp,inttemp3,8));
  result1 = _mm_hadd_ps(result1,result2);
  temp1 = _mm_castsi128_ps(_mm_alignr_epi8(intv1,intv2,4));
  result5 = _mm_insert_ps(temp,result5,0x90);
  temp3 = _mm_mul_ps(m5,temp1);  
 inttemp3 = _mm_castps_si128(temp3);
   b = _mm_add_ps(b,result5);
 __m128 result3 = _mm_castsi128_ps(_mm_alignr_epi8(inttemp3,inttemp,12));

  result5 = _mm_mul_ps(result2,result3);
// a.row.m6 = _mm_load_ps(A+20);

   __m128 result4 =   _mm_mul_ps(m6,v.vec.v1);

__m128 last = _mm_load_ss(A+24);
  result2 = _mm_hadd_ps(result3,result4);
 // __m128 result6 = _mm_set_ps(1.0,0.0,0.0,0.0);
  result3 = _mm_hadd_ps(result1,result2);
 result1 = _mm_mul_ps(last,_mm_set1_ps(v.element.a5));
    b =   _mm_add_ps(b,_mm_blend_ps(_mm_setzero_ps(),result3,14));
 _mm_store_ps(y,b);
  result2 = _mm_shuffle_ps(result2,result2,_MM_SHUFFLE(0,0,0,4));


 _mm_store_ss(y+4,_mm_add_ps(result2,result1));



//IACA_END


}




/*
 * Do not need to modify from here on
 */

#define RUNS     400
#define CYCLES_REQUIRED 1e7

void verify(float const * A, float const * x, float const * y)
{
  int i;
  double err;
  int j;
  float * temp = (float *) _mm_malloc(sizeof(float)*5, 16);
  setzero(temp, 5, 1);

  for(i = 0; i < 5; i++) {
      for(j = 0; j < 5; j++)
        temp[i] += A[i*5+j]*x[j];
      err = fabs(y[i] - temp[i]);
      if(err > 1E-5)
        {
          printf("Error at y[%d]\n", i);
        }
  }

  _mm_free(temp);


}
void test_vec_mvm5(float const * A, float const * x, float * y)
{
  tsc_counter start, end;
  double cycles = 0.;
  size_t num_runs = RUNS;
  int i;

  //Cache warm-up
  // RDTSCP reads ts register guaranteeing that the execution of all the code
  // we wanted to measure is completed. This way we avoid including the
  // execution of a CPUID in between. The last CPUID guarantees no other
  // instruction can be scheduled before it (and so also before RDTSCP)

  CPUID(); RDTSC(start); CPUID(); RDTSC(end);
  CPUID(); RDTSC(start); CPUID(); RDTSC(end);
  CPUID(); RDTSC(start); CPUID(); RDTSC(end);

  while(1) {
      CPUID(); RDTSC(start);
      for (i = 0; i < num_runs; ++i) {
          vec_mvm5(A, x, y);
      }
      CPUID(); RDTSC(end);

      cycles = (double)(COUNTER_DIFF(end, start));

      if(cycles >= CYCLES_REQUIRED) break;

      num_runs *= 2;

  }

  CPUID(); RDTSC(start);
  for (i = 0; i < num_runs; ++i) {
      vec_mvm5(A, x, y);
  }
  CPUID(); RDTSC(end);

  cycles = (double)(COUNTER_DIFF(end, start))/num_runs;

  printf("Test vec_mvm5  - Performance [flops/cycle]: %f\n", 45/cycles);

#ifdef VERIFY
  verify(A, x, y);
#endif

}


int main()
{
  float * A = (float *) _mm_malloc(sizeof(float)*25, 16);
  float * x = (float *) _mm_malloc(sizeof(float)*5, 16);
  float * y = (float *) _mm_malloc(sizeof(float)*5, 16);

  setrandom(A, 5, 5);
  setrandom(x, 5, 1);

  test_vec_mvm5(A, x, y);

  return 0;
}
