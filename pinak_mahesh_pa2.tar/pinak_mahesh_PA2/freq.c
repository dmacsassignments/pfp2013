#include<stdio.h>
#include<stdlib.h>
#include<sys/time.h>
#include<time.h>
#define R 1000000
int main()
{
   volatile int num = 0;
   register int x = 9;
   register int y = 18;
   int i;
   struct timeval t1,t2;
   double diff;
   double freq;
   switch(num)
   {
     case 0 :
             i = R / 8;
             gettimeofday(&t1,NULL);
     compute:
     case 1:
            x = x+y;
     case 2:
            x = x+y;
     case 3:
            x = x+y;
     case 4:
            x = x+y;
     case 5:
            x = x+y;
     case 6:
            x = x+y;
     case 7:
            x = x+y;
     case 8:
            x = x+y;
            if(--i)
              goto compute;
           gettimeofday(&t2,NULL);
         if(!num)
           diff = ((t2.tv_usec)*1000 + 1000000000 * t2.tv_sec) - ((t1.tv_usec)*1000 + 1000000000 * t1.tv_sec);
             printf("Elapsed time is %f\n ",diff);
      
         freq = diff / R;
         printf("The frequency is %f\n",1/freq);
  
  }

}
           
