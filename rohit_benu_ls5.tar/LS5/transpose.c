#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

void transpose( int n, int blocksize, int *dst, int *src ) {
    int i,j,k,l;
    int r = n%blocksize;
    for(k = 0; k < n-r; k += blocksize)
	for(l=0; l< n-r; l += blocksize)
    for( i = k; i < k + blocksize ; i++ )
        for( j = l; j < l + blocksize; j++ )
            dst[j+ i*(n)] = src[i+ (n)*j];
    
    for(i=0 ; i < n-r ;i++ )
        for(j= n-r ; j < n; j++ )
		dst[j*n +i] = src[i*n+j];

  
    for(i= n-r ; i < n ; i++ )
        for( j=0; j < n; j++ )
            dst[j*n + i] = src[i*n + j];

}

int main( int argc, char **argv ) {
    int n1 = 2000,n2=2048,i,j;
    int blocksize = 0; /* to do: find a better block size */
	int loop;

    double curTime,lstTime=9999.0,temp;

    for(loop=2;loop<1002;loop +=2){
    /* allocate an n*n block of integers for the matrices */
    int *A = (int*)malloc( n1*n1*sizeof(int) );
    int *B = (int*)malloc( n1*n1*sizeof(int) );

    /* initialize A,B to random integers */
    srand48( time( NULL ) );
    for( i = 0; i < n1*n1; i++ ) A[i] = lrand48( );
    for( i = 0; i < n1*n1; i++ ) B[i] = lrand48( );

    /* measure performance */
    struct timeval start, end;

    gettimeofday( &start, NULL );
    transpose( n1, loop, B, A );
    gettimeofday( &end, NULL );

    double seconds = (end.tv_sec - start.tv_sec) + 1.0e-6 * (end.tv_usec - start.tv_usec);
    printf( "Blocksize of %d \t %g milliseconds\n",loop, seconds*1e3 );

    curTime = seconds*1e3;
    if(lstTime <= curTime)
	     temp = lstTime;
     else {
       temp = curTime;
       blocksize = loop;
     }
	lstTime = temp;

    /* check correctness */
    for( i = 0; i < n1; i++ )
        for( j = 0; j < n1; j++ )
            if( B[j+i*n1] != A[i+j*n1] ) {
	        printf("Error!!!! Transpose does not result in correct answer!!\n");
	        exit( -1 );
            }
    free( A );
    free( B );
  }
	printf("Optimal Blocksize : %d time %g\n",blocksize,lstTime);
	lstTime = 9999.0;
    for(loop=2;loop<1002;loop +=2){
    /* allocate an n*n block of integers for the matrices */
    int *C = (int*)malloc( n2*n2*sizeof(int) );
    int *D = (int*)malloc( n2*n2*sizeof(int) );

    /* initialize A,B to random integers */
    srand48( time( NULL ) );
    for( i = 0; i < n2*n2; i++ ) C[i] = lrand48( );
    for( i = 0; i < n2*n2; i++ ) D[i] = lrand48( );

    /* measure performance */
    struct timeval start, end;

    gettimeofday( &start, NULL );
    transpose( n2, loop, C, D );
    gettimeofday( &end, NULL );

    double seconds = (end.tv_sec - start.tv_sec) + 1.0e-6 * (end.tv_usec - start.tv_usec);
    printf( "Blocksize of %d \t %g milliseconds\n",loop, seconds*1e3 );

    curTime = seconds*1e3;
    if(lstTime <= curTime)
	     temp = lstTime;
     else {
       temp = curTime;
       blocksize = loop;
     }
	lstTime = temp;
    /* check correctness */
    for( i = 0; i < n2; i++ )
        for( j = 0; j < n2; j++ )
            if( C[j+i*n2] != D[i+j*n2] ) {
	        printf("Error!!!! Transpose does not result in correct answer!!\n");
	        exit( -1 );
            }
    free( C);
    free( D );
}
	printf("Optimal Blocksize : %d time %g\n",blocksize,lstTime);
    return 0;
}

