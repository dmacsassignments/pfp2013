
#include<stdlib.h>
#include <stdio.h>
#include <math.h>
#include "rdtsc.h"

typedef double data_t; 

#define N 10000
#define NUM_RUNS 50

data_t Unroll(data_t *buffer)
{
   long int x;
   data_t a;
   a=0;
   for(x=0;x<N;x++)
    a+=buffer[x];
 return a;
}

data_t Unroll1(data_t *buffer)
{

   long int x;
   data_t a,a0;

 a =a0=0;
 long int limit = N - N%1;
 for (x=0; x<limit; x+=1) {
 a0 += buffer[x];}
 
 
   
 for(; x < N; x++) {
    a0 += buffer[x];
  }
a=a0;
return a;
}

data_t Unroll2(data_t *buffer)
{

   long int x;
   data_t a,a0,a1;

 a =a0= a1=0;
 long int limit = N - N%2;
 for (x=0; x<limit; x+=2) {
 a0 += buffer[x];
 a1 += buffer[x+1];
 }
   
 for(; x < N; x++) {
    a0 += buffer[x];
  }
a=a0+a1;
return a;
}

data_t Unroll3(data_t *buffer)
{

   long int x;
   data_t a,a0,a1,a2;

 a =a0= a1= a2=0;
 long int limit = N - N%3;
 for (x=0; x<limit; x+=3) {
 a0 += buffer[x];
 a1 += buffer[x+1];
 a2 += buffer[x+2];
 } 
 for(; x < N; x++) {
    a0 += buffer[x];
  }
a=a0+a1+a2;
return a;
}

data_t Unroll4(data_t *buffer)
{

   long int x;
   data_t a,a0,a1,a2,a3;

 a =a0= a1= a2= a3=0;
 long int limit = N - N%4;
 for (x=0; x<limit; x+=4) {
 a0 += buffer[x];
 a1 += buffer[x+1];
 a2 += buffer[x+2];
 a3 += buffer[x+3];
 }
 
 for(; x < N; x++) {
    a0 += buffer[x];
  }
a=a0+a1+a2+a3;
return a;
}

data_t Unroll5(data_t *buffer)
{

   long int x;
   data_t a,a0,a1,a2,a3,a4;

 a =a0= a1= a2= a3=a4=0;
 long int limit = N - N%5;
 for (x=0; x<limit; x+=5) {
 a0 += buffer[x];
 a1 += buffer[x+1];
 a2 += buffer[x+2];
 a3 += buffer[x+3];
 a4 += buffer[x+4];
 }
 for(; x < N; x++) {
    a0 += buffer[x];
  }
a=a0+a1+a2+a3+a4;
return a;
}
data_t Unroll6(data_t *buffer)
{
   
   long int x;
   data_t a,a0,a1,a2,a3,a4,a5;

 a =a0= a1= a2= a3=a4=a5= 0;
 long int limit = N - N%6;
 for (x=0; x<limit; x+=6) {
 a0 += buffer[x];
 a1 += buffer[x+1];
 a2 += buffer[x+2];
 a3 += buffer[x+3];
 a4 += buffer[x+4];
 a5 +=buffer[x+5];
 }
for(; x < N; x++) {
    a0 += buffer[x];
  }
 a=a0+a1+a2+a3+a4+a5;
 return a;
}

data_t Unroll7(data_t *buffer)
{

   long int x;
   data_t a,a0,a1,a2,a3,a4,a5,a6;

 a =a0= a1= a2= a3=a4=a5=a6=0;
 long int limit = N - N%7;
 for (x=0; x<limit; x+=7) {
 a0 += buffer[x];
 a1 += buffer[x+1];
 a2 += buffer[x+2];
 a3 += buffer[x+3];
 a4 += buffer[x+4];
 a5 +=buffer[x+5];
 a6 +=buffer[x+6];
 }
for(; x < N; x++) {
    a0 += buffer[x];
  }
a=a0+a1+a2+a3+a4+a5+a6;
return a;
}

data_t Unroll8(data_t *buffer)
{

   long int x;
   data_t a,a0,a1,a2,a3,a4,a5,a6,a7;

 a =a0= a1= a2= a3=a4=a5=a6=a7=0;
 long int limit = N - N%8;
 for (x=0; x<limit; x+=8) {
 a0 += buffer[x];
 a1 += buffer[x+1];
 a2 += buffer[x+2];
 a3 += buffer[x+3];
 a4 += buffer[x+4];
 a5 +=buffer[x+5];
 a6 +=buffer[x+6];
 a7 +=buffer[x+7];
 }
for(; x < N; x++) {
    a0 += buffer[x];
  }
a=a0+a1+a2+a3+a4+a5+a6+a7;
return a;
}


data_t Unroll9(data_t *buffer)
{

   long int x;
   data_t a,a0,a1,a2,a3,a4,a5,a6,a7,a8,a9;

 a =a0= a1= a2= a3=a4=a5=a6=a7=a8=0;
 long int limit = N - N%9;
 for (x=0; x<limit; x+=10) {
 a0 += buffer[x];
 a1 += buffer[x+1];
 a2 += buffer[x+2];
 a3 += buffer[x+3];
 a4 += buffer[x+4];
 a5 +=buffer[x+5];
 a6 +=buffer[x+6];
 a7 +=buffer[x+7];
 a8 +=buffer[x+8];
 a9+=buffer[x+9];
 }
for(; x < N; x++) {
    a0 += buffer[x];
  }
a=a0+a1+a2+a3+a4+a5+a6+a7+a8+a9;
return a;
}
/*inline void Unroll2(data_t *y)
{
	float t1;
	for (int i = 0; i < N; i=i+4)
	{
		y[i] = 0;
		y[i+1] = 0;
		y[i+2] = 0;
		y[i+3] = 0;
	}
}*/





int main()
{	
	 data_t *buffer,*y_vec,value;
        	tsc_counter a, b;
	double cycles, baseline;
        int i;

	//N is a define
	
	buffer = ( data_t*)malloc(sizeof(float)*N);
      //	x = (float*)_mm_malloc(sizeof(float)*N,16);
//	y = (float*)_mm_malloc(sizeof(float)*N,16);
	y_vec = (data_t*)malloc(sizeof(float)*N);

//	if (M == NULL || x == NULL || y == NULL || y_vec == NULL)
//		return 1;

	//init vars
	for ( i = 0; i<N; i++){
			buffer[i] = rand()%1000;	
	}
			

	

	
	//-----------------------------------------Timing 1
	//warm up	

	//-----------------No Vec Warmup-------------------
	//lookup task b from the HW here
	//
	//State the Asm. Instructions used by the compiler as a comment here:
	//
	// <--- List of Instructions --->
	//-----------------------------------------Timing 1
	//warm up
		//Unroll3(M,x,y);


	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

/*	RDTSC(a);
	for(int i=0; i<NUM_RUNS; ++i)
	{ 
		Unroll3(M,x,y);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through partially unrolled code - %1.0f\n",cycles,baseline/cycles,y[0]);*/


	//-----------------------------------------Timing 2
	//warm up
       value =	Unroll(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for( i=0; i<NUM_RUNS; ++i)
	{ 
	    value = Unroll(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
        printf("%ld\n",value);
	printf("%lf cycles -> Speedup: %2.2f x through vectorized code - %1.0f\n",cycles,baseline/cycles,y_vec[0]);
	
	

       //	_mm_free(M);
 //	_mm_free(y);
//	_mm_free(x);


	return 0;
}

