#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define n 2000
#define m 3000

int main()
{
  double **a, **b;
  register double c, norm;
  register int i, j, l;
  
  a = (double**)malloc(n*sizeof(double*));
  b = (double**)malloc(n*sizeof(double*));

  for(i=0; i<n; i++)
    {
      a[i] = (double*)malloc(m*sizeof(double));
       b[i] = (double*)calloc(m, sizeof(double));
      for(j=0; j<n; j++) a[i][j] = drand48();
    }
    
//  for(i=0; i<n; i++) b[i] = (double*)calloc(m, sizeof(double));
 
  c = 13.0;

  for(l=1; l<=30; l++)
    { 
       for(i=0;i<n;i+=5)
       {
           for(j=0;j<m;j+=2)
             
	{
		  b[i][j] = c*b[i][j]+a[i][j];
                  b[i+1][j]=c*b[i+1][j]+a[i+1][j];
                  b[i+2][j]=c*b[i+2][j]+a[i+2][j];
                  b[i+3][j]=c*b[i+3][j]+a[i+3][j];
                  b[i+4][j]=c*b[i+4][j]+a[i+4][j];
       //             b[i+5][j]=c*b[i+5][j]+a[i+5][j];
		}
             
             for(j=1;j<m;j+=2)
                  {
            
      		  b[i][j] = c*b[i][j]-a[i][j];
                  b[i+1][j]=c*b[i+1][j]-a[i+1][j];
                  b[i+2][j]=c*b[i+2][j]-a[i+2][j];
                  b[i+3][j]=c*b[i+3][j]-a[i+3][j];
                  b[i+4][j]=c*b[i+4][j]-a[i+4][j];
         //         b[i+5][j]=c*b[i+5][j]-a[i+5][j];

		}

	     
	    

	 
	}
    }

  norm = 0.0;

  for(i=0; i<n; i++)
    for(j=0; j<m; j++)
      norm = norm + fabs(b[i][j]*b[i][j]);
     
  printf("norm: %10.4e    Value: %10.4e\n",norm, b[10][10]);
}
