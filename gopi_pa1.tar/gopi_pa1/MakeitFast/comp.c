/*
 * comp.c - contains the function superslow that you need to optimize
 *
 *
 */

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


/* f(x, i, j) multiplies or divides by a sine expression depending
   on i + j being odd or even
*/
double f(double x, int i, int j)
{
    if((i + j) &  0x1)
        return x / (1 + sin(M_PI/(i+1)));
    else
        return x * sin(M_PI/(i+1));
}

/* This is the function you need to optimize. It takes one
square matrix as input
*/
void superslow(smat_t *a)
{
    int i, j;
    double x,x2;
    

    // i is the column of a we're computing right now
    for(i = 0; i < a->n; i++)
    {
        // j is the row of a we're computing right now
        for(j = 0; j < a->n; j++)
        {            
                // First, compute f(A) for the element of a in question
        
			x = get_elt(a,i,j);
                x = f(x, i, j);
                
                // Add this to the value of a we're computing and store it
                x2 = get_elt(a,i,j);
			x = x * x2;
                set_elt(a, i, j, x);
            
        }
    }
}

/* first optimization by me */
void superslow1(smat_t *a)
{
    int i, j;
    double x,x2;
     int n=a->n;

  
    for(i = 0; i < a->n; i++)
    {
  
        for(j = 0; j < a->n; j++)
        {
                 x=a->mat[i*n+j];
                 x2 = x;
                 x=f(x,i,j);
                 x = x * x2;
                 a->mat[i*n+j] = x;

        }
    }
}

void superslow2(smat_t *a)
{
    int i, j,k;
    double x,x2,l;
     int n=a->n;

  
    for(i = 0; i < a->n; i++)
    {
  
      k=i*n;
      l=sin(M_PI/(i+1));
      for(j=0;j<a->n;j++)
      {

           x=a->mat[k+j];
           x2=x;
           if((i + j) & 0x1)
               x= x / (1 + l);
           else
               x= x *l;

               x=x*x2;

            a->mat[k+j] = x;




        }
    }
}
void superslow3(smat_t *a)
{
   int i,j,k;
   double x,x2,y,y2,z,z2,l,u,u2,v,v2;
  // double *mat=a->mat;
   int n=a->n;

  for(i=0;i<a->n;i++)
  {
      k=i*n;
      l=sin(M_PI/(i+1));
      for(j=0;j<a->n;j+=5)
      {
           
           x=a->mat[k+j];
           y=a->mat[k+j+1];
           z=a->mat[k+j+2];
           u=a->mat[k+j+3];
           v=a->mat[k+j+4];

           x2=x;
           y2=y;
           z2=z;
           u2=u;
           v2=v;
           if((i + j) & 0x1)
               x= x / (1 + l);
               
           else
               x= x *l; 
           if((i + j+1) & 0x1)
               y= y / (1 + l);
           else
               y= y * l;
           if((i + j+2) & 0x1)
               z= z / (1 + l);
          else
              z= z * l;
          if((i+j+3)& 0x1)
              u=u/(1+l);
          else
              u=u*l;
          if((i+j+4)& 0x1)
              v=v/(1+l);
         else
              v=v*l;



          // x=f(x,i,j);   
      //      y=f(y,i,j+1);
    //      z=f(z,i,j+2);
          
          // x2=mat[i*n+j];
               x=x*x2;            
               y=y*y2;
               z=z*z2;
               u=u*u2;
               v=v*v2;
            a->mat[k+j] = x;
           
            a->mat[k+j+1]=y;
           
            a->mat[k+j+2]=z;
            a->mat[k+j+3]=u;
            a->mat[k+j+4]=v;
           
     }
  }
}

void superslow4(smat_t *a)
{
   int i,j;
   register int k,n;
   register double l,m;
   double x,x2,y,y2,z,z2,u,u2,v,v2,x1,x3,y1,y3,z1,z3,u1,u3,v1,v3;
   int len=a->n;

  for(i=0;i<a->n;i+=2)
  {
      k=i*len;
      n=(i+1)*len;
      l=sin(M_PI/(i+1));
      m=sin(M_PI/(i+2));
      for(j=0;j<a->n;j+=5)
      {

           x=a->mat[k+j];
           x1=a->mat[n+j];           
           y=a->mat[k+j+1];
           y1=a->mat[n+j+1];
           z=a->mat[k+j+2];
           z1=a->mat[n+j+2];
           u=a->mat[k+j+3];
           u1=a->mat[n+j+3];
           v=a->mat[k+j+4];
           v1=a->mat[n+j+4];

           x2=x;
           x3=x1;
           y2=y;
           y3=y1;
           z2=z;
           z3=z1;
           u2=u;
           u3=u1;
           v2=v;
           v3=v1;
           if((i + j) & 1)
               x= x / (1 + l);

           else
               x= x *l;
           if((i+1+j)& 1)
              x1=x1/(1+m);
           else
              x1=x1*m;
           
     
           if((i + j+1) & 1)
               y= y / (1 + l);
           else
               y= y * l;
            if((i+1+j+1)& 1)
              y1=y1/(1+m);
           else
              y1=y1*m;
           if((i + j+2) & 1)
               z= z / (1 + l);
          else
              z= z * l;
             if((i+1+j+2)& 1)
              z1=z1/(1+m);
           else
              z1=z1*m;

          if((i+j+3)& 1)
              u=u/(1+l);
          else
              u=u*l;
          if((i+1+j+3)& 1)
              u1=u1/(1+m);
           else
              u1=u1*m;
          if((i+j+4)& 1)
              v=v/(1+l);
         else
              v=v*l;

        if((i+1+j+4)& 1)
              v1=v1/(1+m);
           else
              v1=v1*m;


               //x=x*x2;
              // x1=x1*x3;
               /*    y=y*y2;
               y1=y1*y3;
               z=z*z2;
               z1=z1*z3;
               u=u*u2;
               u1=u1*u3;
               v=v*v2;
               v1=v1*v3;*/
            a->mat[k+j] = x*x2;
            a->mat[n+j]=x1*x3;
            a->mat[k+j+1]=y*y2;
            a->mat[n+j+1]=y1*y3;
            a->mat[k+j+2]=z*z2;
            a->mat[n+j+2]=z1*z3;
            a->mat[k+j+3]=u*u2;
            a->mat[n+j+3]=u1*u3;
            a->mat[k+j+4]=v*v2;
            a->mat[n+j+4]=v1*v3;
     }
  }
}




void superslow5(smat_t *a)
{
   int i,j;
   register int k,n;
   register double l,m;
   double x,y,z,u,x1,y1,z1,u1;
   int len=a->n;

  for(i=0;i<a->n;i+=2)
  {
      k=i*len;
      n=(i+1)*len;
      l=sin(M_PI/(i+1));
      m=sin(M_PI/(i+2));
      for(j=0;j<a->n;j+=4)
      {

           x=a->mat[k+j];
           x1=a->mat[n+j];
           y=a->mat[k+j+1];
           y1=a->mat[n+j+1];
           z=a->mat[k+j+2];
           z1=a->mat[n+j+2];
           u=a->mat[k+j+3];
           u1=a->mat[n+j+3];
          
            a->mat[k+j] = x*l*x;
            a->mat[n+j]=x1/(1+m)*x1;
            a->mat[k+j+1]=y/(1+l)*y;
            a->mat[n+j+1]=y1*m*y1;
            a->mat[k+j+2]=z*l*z;
            a->mat[n+j+2]=z1/(1+m)*z1;
            a->mat[k+j+3]=u/(1+l)*u;
            a->mat[n+j+3]=u1*m*u1;
            //a->mat[k+j+4]=v*v2;
           // a->mat[n+j+4]=v1*v3;
     }
  }
}





void superslow6(smat_t *a)
{
   int i,j;
   register int k,n,o,p;
   register double l,m,q,r;
 register   double x,y,z,u,x1,y1,z1,u1,x2,y2,z2,u2,x3,y3,z3,u3;
   int len=a->n;

  for(i=0;i<a->n;i+=4)
  {
      k=i*len;
      n=(i+1)*len;
      o=(i+2)*len;
      p=(i+3)*len;
      l=sin(M_PI/(i+1));
      m=sin(M_PI/(i+2));
      q=sin(M_PI/(i+3));
      r=sin(M_PI/(i+4));
      for(j=0;j<a->n;j+=4)
      {

           x=a->mat[k+j];
           x1=a->mat[n+j];
           x2=a->mat[o+j];
           x3=a->mat[p+j];
           y=a->mat[k+j+1];
           y1=a->mat[n+j+1];
           y2=a->mat[o+j+1];
           y3=a->mat[p+j+1];
           z=a->mat[k+j+2];
           z1=a->mat[n+j+2];
           z2=a->mat[o+j+2];
           z3=a->mat[p+j+2];
           u=a->mat[k+j+3];
           u1=a->mat[n+j+3];
           u2=a->mat[o+j+3];
           u3=a->mat[p+j+3];

            a->mat[k+j] = x*l*x;
            a->mat[n+j]=x1/(1+m)*x1;
            a->mat[o+j]=x2*q*x2;
            a->mat[p+j]=x3/(1+r)*x3;
            a->mat[k+j+1]=y/(1+l)*y;
            a->mat[n+j+1]=y1*m*y1;
            a->mat[o+j+1]=y2/(1+q)*y2;
            a->mat[p+j+1]=y3*r*y3;
            a->mat[k+j+2]=z*l*z;
            a->mat[n+j+2]=z1/(1+m)*z1;
            a->mat[o+j+2]=z2*q*z2;
            a->mat[p+j+2]=z3/(1+r)*z3;
            a->mat[k+j+3]=u/(1+l)*u;
            a->mat[n+j+3]=u1*m*u1;
            a->mat[o+j+3]=u2/(1+q)*u2;
            a->mat[p+j+3]=u3*r*u3;
            
     }
  }
}


/* 
 * Called by the driver to register your functions
 * Use add_function(func, description) to add your own functions
 */
void register_functions()
{
    // Registers comp_superslow with the driver
    add_function(&superslow, "superslow: original function");
    add_function(&superslow1,"superslow:version1");	
    add_function(&superslow2,"superslow:version2");
    add_function(&superslow3,"superslow:version3");
    add_function(&superslow4,"superslow:version4");
    add_function(&superslow5,"superslow:version5");
    add_function(&superslow6,"superslow:version6");
   // add_function(&superslow7,"superslow:version7");
	//Add your functions here
	//add_function(&superslow2, "superslow: Optimization X");
	
	
}
