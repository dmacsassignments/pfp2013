const char* dgemm_desc = "My awesome dgemm.";
#define BLOCK_SIZE 32
void square_dgemm(const int M, const double *__restrict__ A, const double *__restrict__ B, double *__restrict__ C)
{
    int i, j, k,i1,j1,k1, kk, jj;
	
/*	const int n_blocks = M / BLOCK_SIZE + (M%BLOCK_SIZE? 1 : 0);
	for(kk = 0 ; kk < M; kk +=BLOCK_SIZE ){
		for( jj = 0; jj < M; jj += BLOCK_SIZE){
			for (k = 0; k < M; ++k){
				for(i = 0;i < min( BLOCK_SIZE,1+M-kk);++i){
					//double r=B[k*M+i];
					double tmp = 0.0;
					for(j=0; j<min(BLOCK_SIZE,1+M-jj);++j)
						tmp += A[j*M +i]*B[(jj+j-1)*M + k];
						//C[j*M +i] += A[j*M + k]*r;
					C[(i+kk-1)*M + k] = tmp;
				}
			}
		}
	}*/

const int n_blocks = M / BLOCK_SIZE + (M%BLOCK_SIZE? 1 : 0);
     int bi, bj, bk;
     for (bj = 0; bj < n_blocks; ++bj) {
         const int j = bj * BLOCK_SIZE;
         for (bk = 0; bk < n_blocks; ++bk) {
             const int k = bk * BLOCK_SIZE;
             for (bi = 0; bi < n_blocks; ++bi) {
                 const int i = bi * BLOCK_SIZE;
		
		 int M1 = (i+BLOCK_SIZE > M? M -i : BLOCK_SIZE);
		 int N1 = (j+BLOCK_SIZE > M? M -j : BLOCK_SIZE);
 		 int K1 = (k+BLOCK_SIZE > M? M -k : BLOCK_SIZE);

		 const double* A1 = A + i + k * M;
		 const double* B1 = B + k + j * M;
		 double* C1 = C + i + j * M;
                

    		 for (j1 = 0; j1 < N1; ++j1 ) {
        		for (k1 = 0; k1 < K1; ++k1) {
	   			register double r1 = B1[j1*M+k1];
	   			//register double r2 = B1[(j1+1)*M+k1];
	   			//register double r3 = B1[(j1+2)*M+k1];
	   			//register double r4 = B1[(j1+3)*M+k1];
            			for (i1=0; i1 < M1; i1 ++){
             	  			C1[j1*M+i1] += A1[k1*M+i1] * r1;
             	  			//C1[j1*M+i1+1] += A1[k1*M+i1+1] * r1;
             	  			//C1[j1*M+i1+2] += A1[k1*M+i1+2] * r1;
             	  			//C1[j1*M+i1+3] += A1[k1*M+i1+3] * r1;
					

                			//C1[(j1+1)*M+i1] += A1[k1*M+i1] * r2;
                			//C1[(j1+1)*M+i1+1] += A1[k1*M+i1+1] * r2;
                			//C1[(j1+1)*M+i1+2] += A1[k1*M+i1+2] * r2;
                			//C1[(j1+1)*M+i1+3] += A1[k1*M+i1+3] * r2;


                			//C1[(j1+2)*M+i1] += A1[k1*M+i1] * r3;
                			//C1[(j1+2)*M+i1+1] += A1[k1*M+i1+1] * r3;
                			//C1[(j1+2)*M+i1+2] += A1[k1*M+i1+2] * r3;
                			//C1[(j1+2)*M+i1+3] += A1[k1*M+i1+3] * r3;


                			//C1[(j1+3)*M+i1] += A1[k1*M+i1] * r4;
                			//C1[(j1+3)*M+i1+1] += A1[k1*M+i1+1] * r4;
                			//C1[(j1+3)*M+i1+2] += A1[k1*M+i1+2] * r4;
                			//C1[(j1+3)*M+i1+3] += A1[k1*M+i1+3] * r4;
				}
       			}
    		 }





// do_block(M, A, B, C, i, j, k);
             }
         }
     }

/*


    for (j = 0; j < M; ++j) {
        for (k = 0; k < M; ++k) {
	   register double r = B[j*M+k];
            for (i=0; i < M; ++i)
                C[j*M+i] += A[k*M+i] * r;
       }
    }

 for(j=0;j<M;j+=BLOCK){
    for(k=0;k<M;k +=BLOCK){
      for(i=0;i<M;i+=BLOCK){
    for(ii=i;ii<i+BLOCK;ii++){
      for(jj=j;jj<j+BLOCK;jj++){
        for(kk=k;kk<k+BLOCK;kk++){
                C[ii+M*jj] += A[ii+M*kk] * B[jj*M+kk];
}	  
}
}
}
}
}
*/
}

inline int min(int a, int b){
	if(a<b)
		return a;
	else 
		return b;
}

