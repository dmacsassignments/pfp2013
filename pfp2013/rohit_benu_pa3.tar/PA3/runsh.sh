srun -p development -t 0:30:00 -n 16 --pty /bin/bash -l 
