module swap intel gcc/4.7.1
module load mkl
