const char* dgemm_desc = "My Matrix Multiplication.";
#ifndef BLOCK_SIZE
#define BLOCK_SIZE ((int)32)
#endif


void square_dgemm(const int M, const double *A, const double *B, double *C)
{
    const int n_blocks = M / BLOCK_SIZE + (M%BLOCK_SIZE? 1 : 0);
    int bi, bj, bk;
    for (bj = 0; bj < n_blocks; ++bj) {
        const int j = bj * BLOCK_SIZE;
        for (bk = 0; bk < n_blocks; ++bk) {
            const int k = bk * BLOCK_SIZE;
            for (bi = 0; bi < n_blocks; ++bi) {
                const int i = bi * BLOCK_SIZE;
   		const int P = (i+BLOCK_SIZE > M? M-i : BLOCK_SIZE);
		const int N = (j+BLOCK_SIZE > M? M-j : BLOCK_SIZE);
		const int T = (k+BLOCK_SIZE > M? M-k : BLOCK_SIZE);
  int i1, j1, k1;
double *__restrict__ A1 = A + i + k*M;
double *__restrict__ B1 = B + k + j*M;
double *__restrict__ C1 = C + i + j*M;

 for (j1 = 0; j1 < N; ++j1) {
 for (k1 = 0; k1 < (T - 7); k1 += 8) {
 register double *__restrict__ b1 = B1 + j1*M + k1;
 register double *__restrict__ b2 = B1 + j1*M + k1 +1;
 register double *__restrict__ b3 = B1 + j1*M + k1 + 2;
 register double *__restrict__ b4 = B1 + j1*M + k1 + 3;
 register double *__restrict__ b5 = B1 + j1*M + k1 + 4;
 register double *__restrict__ b6 = B1 + j1*M + k1 + 5;
 register double *__restrict__ b7 = B1 + j1*M + k1 + 6;
 register double *__restrict__ b8 = B1 + j1*M + k1 + 7;
 for (i1 = 0; i1 < P; ++i1) {
 //register double *__restrict__ b11  = b1;
 C1[j1*M + i1] += A1[k1*M + i1] * (*b1);
 C1[j1*M + i1] += A1[(k1+1)*M + i1] * (*(b2));
 C1[j1*M + i1] += A1[(k1+2)*M + i1] * (*(b3));
 C1[j1*M + i1] += A1[(k1+3)*M + i1] * (*(b4));
 C1[j1*M + i1] += A1[(k1+4)*M + i1] * (*(b5));
 C1[j1*M + i1] += A1[(k1+5)*M + i1] * (*(b6));
 C1[j1*M + i1] += A1[(k1+6)*M + i1] * (*(b7));
 C1[j1*M + i1] += A1[(k1+7)*M + i1] * (*(b8));
 }
 }
 for(;k1 < T; ++k1){
 register double b1 = B1[j1*M + k1];
 for (i1 = 0; i1 < P; ++i1) {
 C1[j1*M + i1] += A1[k1*M + i1] * b1;
} }
 
 }
 



/*

for ( j1 = 0; j1 < N; ++j1) {
 for ( k1 = 0; k1 < T; ++k1) {
double temp  = B1[j1*M + k1];
 for ( i1 = 0; i1 < P; ++i1) {
 C1[j1*M + i1] += A1[k1*M+ i1] * temp;
 }
 }
 }*/
          }
        }
    }
  }//else{


//}
