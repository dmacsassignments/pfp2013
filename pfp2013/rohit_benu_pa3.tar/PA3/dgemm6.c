const char* dgemm_desc = "My Matrix Multiplication.";
#include <math.h>
#include <immintrin.h>

#ifndef BLOCK_SIZE
#define BLOCK_SIZE ((int)32)
#endif

inline void basic_dgemm(const int lda, const int M, const int N, const int K,const double *A, const double *B, double *C)
{
  int i, j, k;

 for ( j = 0; j < N; ++j) {
 for ( k = 0; k < K; ++k) {
double temp  = B[j*lda + k];
 for ( i = 0; i < M; ++i) {
 C[j*lda + i] += A[k*lda + i] * temp;
 }
 }
 }
}

void square_dgemm(const int M, const double *A, const double *B, double *C)
{
	    const int n_blocks = M / BLOCK_SIZE + (M%BLOCK_SIZE? 1 : 0);
	    int bi, bj, bk;
	    for (bj = 0; bj < n_blocks; ++bj) {
        	const int j = bj * BLOCK_SIZE;
	        for (bk = 0; bk < n_blocks; ++bk) {
        	    const int k = bk * BLOCK_SIZE;
	            for (bi = 0; bi < n_blocks; ++bi) {
        	        const int i = bi * BLOCK_SIZE;
   			const int P = (i+BLOCK_SIZE > M? M-i : BLOCK_SIZE);
			const int N = (j+BLOCK_SIZE > M? M-j : BLOCK_SIZE);
			const int K = (k+BLOCK_SIZE > M? M-k : BLOCK_SIZE);
			  int i1, j1, k1;
			double *A1 = A + i + k*M;
			double *B1 = B + k + j*M;
			double *C1 = C + i + j*M;

/*

 for ( i1 = 0; i1 < P; ++i1) {

  for ( j1 = 0; j1 < N; ++j1) {
  double sum = C1[j1*M + i1];

 for ( k1 = 0; k1 < K; ++k1) {
sum += A1[k1*M+ i1] *B1[j1*M + k1];
}
C1[j1*M + i1] = sum;
*/
 for ( j1 = 0; j1 < N; ++j1) {
 for ( k1 = 0; k1 < K; ++k1) {
double temp  = B1[j1*M + k1];
__m256d temp0,temp1,temp2,temp3;
temp0 = _mm256_set1_pd(temp);
 for ( i1 = 0; i1 < P - 3; i1+=4) {
// C1[j1*M + i1] += A1[k1*M+ i1] * temp;
 temp2 = _mm256_loadu_pd(A1 + k1*M + i1);
 temp3 = _mm256_mul_pd(temp2,temp0);
 temp1 = _mm256_loadu_pd(C1 + j1*M + i1);
 temp3 = _mm256_add_pd(temp3,temp1);
 _mm256_storeu_pd(C1 + j1*M + i1,temp3);

}

for(;i1 < P; ++i1)
{  C1[j1*M  + i1] += A1[k1*M + i1]*temp;
}

}
 }//   }
}}}}
//else{
/*
    for (i = 0; i < M; ++i) {
        for (j = 0; j < N; ++j) {
            double cij = C[j*lda+i];
            for (k = 0; k < K; ++k) {
                cij += A[k*lda+i] * B[j*lda+k];
            }
            C[j*lda+i] = cij;
        }
    }
    for (i = 0; i < M; ++i) {
        for (j = 0; j < N; ++j) {
            double cij = C[j*lda+i];
            for (k = 0; k < K; ++k) {
                cij += A[k*lda+i] * B[j*lda+k];
            }
            C[j*lda+i] = cij;
        }
    }

*/

 //}
//}
