#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>


void transpose( int n, int bsize, int *dst, int *src ) {
    int i,j,i1,j1,term=n-(n%bsize);
    /* to do: implement blocking (two more loops) */
    for( i = 0; i < term ; i+=bsize ){
        for( j = 0; j < term; j+=bsize ){
   	 for(i1 = i;i1 < i+bsize;i1++)
 	  for( j1 = j;j1 < j+bsize;j1++)   
           dst[j1+i1*n] = src[i1+j1*n];
        }
    } 
    for(;i<n;i++)
      for( j1=0;j1<n;j1++){
           dst[j1+i*n] = src[i+j1*n];
           dst[i+j1*n] = src[j1+i*n];
      } 

}

int main( int argc, char **argv ) {
    int n = 2048,i,j,k;
    if(argc != 2){
        printf("Error: Format:<./transpose><blocksize>\n");
        exit(0);
    } 
    int bsize = atoi(argv[1]); /* to do: find a better block size */

    /* allocate an n*n block of integers for the matrices */
    int *A = (int*)malloc( n*n*sizeof(int) );
    int *B = (int*)malloc( n*n*sizeof(int) );

    /* initialize A,B to random integers */
    srand48( time( NULL ) );
    for( i = 0; i < n*n; i++ ) A[i] = lrand48( );
    for( i = 0; i < n*n; i++ ) B[i] = lrand48( );
    
    for(k=bsize-10;k<=bsize+10 && k>0 ;k++){
      int blocksize = k;
    /* measure performance */
    struct timeval start, end;

    gettimeofday( &start, NULL );
    transpose( n, blocksize, B, A );
    gettimeofday( &end, NULL );

    double seconds = (end.tv_sec - start.tv_sec) + 1.0e-6 * (end.tv_usec - start.tv_usec);
    printf( "%g milliseconds with block size:%d\n", seconds*1e3,blocksize );

    /* check correctness */
    for( i = 0; i < n; i++ )
        for( j = 0; j < n; j++ )
            if( B[j+i*n] != A[i+j*n] ) {
	        printf("Error!!!! Transpose does not result in correct answer!!\n");
	        exit( -1 );
            }
  }
    /* release resources */
    free( A );
    free( B );
    return 0;
}

