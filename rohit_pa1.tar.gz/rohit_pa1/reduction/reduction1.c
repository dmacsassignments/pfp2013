



#include	<stdio.h>
#include	<stdlib.h>
#include	<math.h>

int main()
{

float buffer[10000];
register int x;

	for ( x=0; x < 10000; x++)
		buffer[x] = rand();

 register float *temp ,*temp1;
	temp = buffer;

	for ( x=0; x < 10000; x+=5)
	{	temp1= temp;
		temp++;
		*temp1+= *temp;
		temp++;
		*temp1+= *temp;
		temp++;
		*temp1+= *temp;
		temp++;
		*temp1+= *temp;
		temp++;
	}
	printf("Results : %f\n",*temp1);

}
