#include<stdio.h>
#include<stdlib.h>

int main()
{

float a =0 ;
float buffer[10000];
int x;

	for ( x=0; x < 10000; x++)
		buffer[x] = rand();

	for ( x=0; x < 10000; x++)
		a+= buffer[x];

	printf("Results : %f\n",a);

}
