const char* dgemm_desc = "MY blocked dgemm.";
//#include <xmmintrin.h>
#include <immintrin.h>
//#include<avxintrin-emu.h>
/*#ifndef BLOCK_SIZE
#define BLOCK_SIZE ((int) 56)
#endif*/

/*
  A is M-by-K
  B is K-by-N
  C is M-by-N

  lda is the leading dimension of the matrix (the M of square_dgemm).
*/
int BLOCK_SIZE;
void basic_dgemm(const int lda, const int M, const int N, const int K,
                 const double *A, const double *B, double *C)
{
    int i, j, k;
    for (i = 0; i < M; ++i) {
        for (j = 0; j < N; ++j) {
            double cij = C[j*lda+i];
            for (k = 0; k < K; ++k) {
                cij += A[k*lda+i] * B[j*lda+k];
            }
            C[j*lda+i] = cij;
        }
    }
}
void basic_dgemm2(const int lda, const int M, const int N, const int K,
                 const double * restrict A, const double * restrict B, double * restrict C)
{
    register int i ,j ,k ,n;
//    double * restrict a = malloc( M * K *(sizeof(double)));
    double * restrict a = malloc( BLOCK_SIZE * BLOCK_SIZE *(sizeof(double)));
    
    for(n=0,i=0;i<K;i++)
	for(j=0;j<M;j++)
	   a[n++] = A[i*lda+j];
    int rem = M%4; int rem1 = K%4;  
    for(j=0;j<N;j+=2){
	for(k=0;k<K-rem1;k+=4){
                const __m256d b = _mm256_set1_pd(B[j*lda+k]);
                const __m256d b1 = _mm256_set1_pd(B[j*lda+k+1]);
                const __m256d b2 = _mm256_set1_pd(B[j*lda+k+2]);
                const __m256d b3 = _mm256_set1_pd(B[j*lda+k+3]);
                const __m256d bb = _mm256_set1_pd(B[(j+1)*lda+k]);
                const __m256d bb1 = _mm256_set1_pd(B[(j+1)*lda+k+1]);
                const __m256d bb2 = _mm256_set1_pd(B[(j+1)*lda+k+2]);
                const __m256d bb3 = _mm256_set1_pd(B[(j+1)*lda+k+3]);
          //      const __m256d b4 = _mm256_set1_pd(B[j*lda+k+4]);
        //        const __m256d b5 = _mm256_set1_pd(B[j*lda+k+5]);
            //    const __m256d b6 = _mm256_set1_pd(B[j*lda+k+6]);
          //      const __m256d b7 = _mm256_set1_pd(B[j*lda+k+7]);
	   for(i=0;i<M-rem;i+=4){
                const __m256d a1 = _mm256_loadu_pd(a+(k*M)+i);
                const __m256d a2 = _mm256_loadu_pd(a+((k+1)*M)+i);
                const __m256d a3 = _mm256_loadu_pd(a+((k+2)*M)+i);
                const __m256d a4 = _mm256_loadu_pd(a+((k+3)*M)+i);
            //    const __m256d a5 = _mm256_loadu_pd(a+((k+4)*M)+i);
              //  const __m256d a6 = _mm256_loadu_pd(a+((k+5)*M)+i);
                //const __m256d a7 = _mm256_loadu_pd(a+((k+6)*M)+i);
              //  const __m256d a8 = _mm256_loadu_pd(a+((k+7)*M)+i);
                
                const __m256d aa1 = _mm256_loadu_pd(a+(k*M)+i+4);
                const __m256d aa2 = _mm256_loadu_pd(a+((k+1)*M)+i+4);
                const __m256d aa3 = _mm256_loadu_pd(a+((k+2)*M)+i+4);
                const __m256d aa4 = _mm256_loadu_pd(a+((k+3)*M)+i+4);
                //const __m256d aa5 = _mm256_loadu_pd(a+((k+4)*M)+i+4);
              //  const __m256d aa6 = _mm256_loadu_pd(a+((k+5)*M)+i+4);
                //const __m256d aa7 = _mm256_loadu_pd(a+((k+6)*M)+i+4);
                //const __m256d aa8 = _mm256_loadu_pd(a+((k+7)*M)+i+4);
                  
        /*        const __m256d aaa1 = _mm256_loadu_pd(a+(k*M)+i+8);
                const __m256d aaa2 = _mm256_loadu_pd(a+((k+1)*M)+i+8);
                const __m256d aaa3 = _mm256_loadu_pd(a+((k+2)*M)+i+8);
                const __m256d aaa4 = _mm256_loadu_pd(a+((k+3)*M)+i+8);*/

                __m256d c1 = _mm256_loadu_pd(C+(j*lda)+i);
          //      __m256d c2 = _mm256_loadu_pd(C+(j*lda)+i+4);
                __m256d c3 = _mm256_loadu_pd(C+((j+1)*lda)+i);
            //    __m256d c4 = _mm256_loadu_pd(C+((j+1)*lda)+i+4);
//                __m256d c3 = _mm256_loadu_pd(C+(j*lda)+i+8);
               
                __m256d temp = _mm256_mul_pd(a1,b);
                __m256d temp1 = _mm256_mul_pd(a2,b1);
                __m256d temp2 = _mm256_mul_pd(a3,b2);
                __m256d temp3 = _mm256_mul_pd(a4,b3);

                __m256d temp4 = _mm256_mul_pd(a1,bb);
                __m256d temp5 = _mm256_mul_pd(a2,bb1);
                __m256d temp6 = _mm256_mul_pd(a3,bb2);
                __m256d temp7 = _mm256_mul_pd(a4,bb3);

                c1 = _mm256_add_pd(c1,temp);
                c1 =  _mm256_add_pd(c1,temp1);
                c1 = _mm256_add_pd(c1,temp2);
                c1 = _mm256_add_pd(c1,temp3);

                _mm256_storeu_pd(C+(j*lda)+i,c1);
                c3 = _mm256_add_pd(c3,temp4);
                c3 = _mm256_add_pd(c3,temp5);
               c3 = _mm256_add_pd(c3,temp6);
                c3 = _mm256_add_pd(c3,temp7);
          

                _mm256_storeu_pd(C+((j+1)*lda)+i,c3);        
              /*   temp = _mm256_mul_pd(aa1,b);
                temp1 = _mm256_mul_pd(aa2,b1);
                temp2 = _mm256_mul_pd(aa3,b2);
                temp3 = _mm256_mul_pd(aa4,b3);

                temp4 = _mm256_mul_pd(aa1,bb);
                temp5 = _mm256_mul_pd(aa2,bb1);
                temp6 = _mm256_mul_pd(aa3,bb2);
                temp7 = _mm256_mul_pd(aa4,bb3);
                
                //c2 = _mm256_add_pd(c2,_mm256_mul_pd(a2,b));
                c2 = _mm256_add_pd(c2,temp);
                c2 =  _mm256_add_pd(c2,temp1);
                c2 = _mm256_add_pd(c2,temp2);
                c2 = _mm256_add_pd(c2,temp3);
                _mm256_storeu_pd(C+(j*lda)+i+4,c2);

                c4 = _mm256_add_pd(c4,temp4);
                c4 = _mm256_add_pd(c4,temp5);
                c4 = _mm256_add_pd(c4,temp6);
                c4 = _mm256_add_pd(c4,temp7);

                _mm256_storeu_pd(C+((j+1)*lda)+i+4,c4);        */
                
  /*               temp = _mm256_mul_pd(aaa1,b);
                temp1 = _mm256_mul_pd(aaa2,b1);
                temp2 = _mm256_mul_pd(aaa3,b2);
                temp3 = _mm256_mul_pd(aaa4,b3);


                c3 = _mm256_add_pd(c3,temp);
                c3 =  _mm256_add_pd(c3,temp1);
                c3 = _mm256_add_pd(c3,temp2);
                c3 = _mm256_add_pd(c3,temp3);

                   _mm256_storeu_pd(C+(j*lda)+i+8,c3);
*/
	//	C[j*lda+i] += a[k*M+i] * B[j*lda+k];
           }
        if(rem)
        {
           double b1 = B[j*lda+k];
           double b2 = B[j*lda+k+1];
           double b3 = B[j*lda+k+2];
           double b4 = B[j*lda+k+3];
           double b5 = B[(j+1)*lda+k];
           double b6 = B[(j+1)*lda+k+1];
           double b7 = B[(j+1)*lda+k+2];
           double b8 = B[(j+1)*lda+k+3];
          do{
         //  double b2 = B[j*lda+k];
          // for(i=M-rem;i<M;i++)      
              C[j*lda+i] += a[k*M+i] * b1;
              C[j*lda+i] += a[(k+1)*M+i] * b2;
              C[j*lda+i] += a[(k+2)*M+i] * b3;
              C[j*lda+i] += a[(k+3)*M+i] * b4;
              C[(j+1)*lda+i] += a[(k)*M+i] * b5;
              C[(j+1)*lda+i] += a[(k+1)*M+i] * b6;
              C[(j+1)*lda+i] += a[(k+2)*M+i] * b7;
              C[(j+1)*lda+i] += a[(k+3)*M+i] * b8;
         }while(++i < M);
        }
     } 
       
         if(rem1)
         {
             do{
              double  b2 = B[j*lda+k];
             double  f2 = B[(j+1)*lda+k];
             for (i = 0; i < M; ++i) {
                 C[j*lda+i] += a[k*M+i] * b2;
                C[(j+1)*lda+i] += a[k*M+i] * f2;
               }
             } while(++k < K);
          }
     
  }
  free(a);  
}
void do_block(const int lda,
              const double *  A, const double *  B, double *  C,
              const int i, const int j, const int k)
{
    const int M = (i+BLOCK_SIZE > lda? lda-i : BLOCK_SIZE);
    const int N = (j+BLOCK_SIZE > lda? lda-j : BLOCK_SIZE);
    const int K = (k+BLOCK_SIZE > lda? lda-k : BLOCK_SIZE);
    basic_dgemm2(lda, M, N, K,
                A + i + k*lda, B + k + j*lda, C + i + j*lda);
}

void square_dgemm(const int M, const double * A, const double *  B, double *  C)
{   
  /*if(M<128)
       BLOCK_SIZE = 32;
    else
      BLOCK_SIZE = 56;*/
  switch(M)
  { case 31: BLOCK_SIZE = 128; break;
    default: BLOCK_SIZE = 56; break;
  }
    const int n_blocks = M / BLOCK_SIZE + (M%BLOCK_SIZE? 1 : 0);
    int bi, bj, bk;
    for (bi = 0; bi < n_blocks; ++bi) {
        const int i = bi * BLOCK_SIZE;
        for (bj = 0; bj < n_blocks; ++bj) {
            const int j = bj * BLOCK_SIZE;
            for (bk = 0; bk < n_blocks; ++bk) {
                const int k = bk * BLOCK_SIZE;
                do_block(M, A, B, C, i, j, k);
            }
        }
    }
}

