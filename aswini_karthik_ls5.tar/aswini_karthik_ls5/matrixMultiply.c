#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <papi.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

/* To save you time, we are including all 6 variants of the loop ordering 
   as separate functions and then calling them using function pointers. 
   The reason for having separate functions that are nearly identical is
   to avoid counting any extraneous processing towards the computation
   time.  This includes I/O accesses (printf) and conditionals (if/switch).
   I/O accesses are slow and conditional/branching statements could
   unfairly bias results (lower cases in switches must run through more
   case statements on each iteration).
*/
void multMat1( int n, float *A, float *B, float *C ) {
    int i,j,k;
    /* This is ijk loop order. */
    for( i = 0; i < n; i++ )
	for( j = 0; j < n; j++ )
	    for( k = 0; k < n; k++ )
		C[i+j*n] += A[i+k*n]*B[k+j*n];
}

void multMat2( int n, float *A, float *B, float *C ) {
    int i,j,k;
    /* This is ikj loop order. */
    for( i = 0; i < n; i++ )
	for( k = 0; k < n; k++ )
	    for( j = 0; j < n; j++ )
		C[i+j*n] += A[i+k*n]*B[k+j*n];
}

void multMat3( int n, float *A, float *B, float *C ) {
    int i,j,k;
    /* This is jik loop order. */
    for( j = 0; j < n; j++ )
	for( i = 0; i < n; i++ )
	    for( k = 0; k < n; k++ )
		C[i+j*n] += A[i+k*n]*B[k+j*n];
}

void multMat4( int n, float *A, float *B, float *C ) {
    int i,j,k;
    /* This is jki loop order. */
    for( j = 0; j < n; j++ )
	for( k = 0; k < n; k++ )
	    for( i = 0; i < n; i++ )
		C[i+j*n] += A[i+k*n]*B[k+j*n];
}

void multMat5( int n, float *A, float *B, float *C ) {
    int i,j,k;
    /* This is kij loop order. */
    for( k = 0; k < n; k++ )
	for( i = 0; i < n; i++ )
	    for( j = 0; j < n; j++ )
		C[i+j*n] += A[i+k*n]*B[k+j*n];
}

void multMat6( int n, float *A, float *B, float *C ) {
    int i,j,k;
    /* This is kji loop order. */
    for( k = 0; k < n; k++ )
	for( j = 0; j < n; j++ )
	    for( i = 0; i < n; i++ )
		C[i+j*n] += A[i+k*n]*B[k+j*n];
}


/* defaults to Part 1.  pass it any argument for Part 2. */
/* uses timing features from sys/time.h that you haven't seen before */
int main( int argc, char **argv ) {
    int nmax = 1000,i,n;
int ec = PAPI_library_init(PAPI_VER_CURRENT);
   if (ec != PAPI_VER_CURRENT && ec > 0) {
      fprintf(stderr,"PAPI library version mismatch!\n");
      exit(1);
   }

   if (ec < 0){
	fprintf(stderr, "PAPI init error %d: %s\n",ec,PAPI_strerror(ec));
      exit(1);
   }

   ec = PAPI_is_initialized();

   if (ec != PAPI_LOW_LEVEL_INITED){
      fprintf(stderr,"Low Level not invited\n");
   }

    int EventSet = PAPI_NULL;
    int errcode = PAPI_create_eventset(&EventSet);
    if (errcode != PAPI_OK) {
        fprintf(stderr,"Couldn't create event set\n");
	fprintf(stderr, "PAPI error %d: %s\n",errcode,PAPI_strerror(errcode));
        exit(-1);
    }

    const int NUMEVENTS  = 3;
    int events[] = {PAPI_SR_INS,PAPI_LD_INS,PAPI_L2_DCM};
    errcode = PAPI_add_events(EventSet, events, NUMEVENTS);
    if (errcode != PAPI_OK) {
       fprintf(stderr,"Couldn't add events to event set\n");
       fprintf(stderr, "PAPI error %d: %s\n",errcode,PAPI_strerror(errcode));
       exit(-1);
    }

    int N =  atoi(*++argv);
    printf("N = %d\n",N);
    double *x = (double *) malloc(N*sizeof(double));
    assert(x);
    double *y = (double *) malloc(N*sizeof(double));
    assert(y);
    for (int i=0; i< N; i++){
	x[i] = i;
    }
    long long values[NUMEVENTS];errcode  = PAPI_start(EventSet);
    PAPI_stop(EventSet, values);  //warm-ups

    void (*orderings[])(int,float *,float *,float *) = {&multMat1,&multMat2,&multMat3,&multMat4,&multMat5,&multMat6};
    char *names[] = {"ijk","ikj","jik","jki","kij","kji"};

    float *A = (float *)malloc( nmax*nmax * sizeof(float));
    float *B = (float *)malloc( nmax*nmax * sizeof(float));
    float *C = (float *)malloc( nmax*nmax * sizeof(float));

    struct timeval start, end;

    if( argv[1] ) {
        printf("Running Part B...\n\n");

        /* fill matrices with random numbers */
        for( i = 0; i < nmax*nmax; i++ ) A[i] = drand48()*2-1;
        for( i = 0; i < nmax*nmax; i++ ) B[i] = drand48()*2-1;
        for( i = 0; i < nmax*nmax; i++ ) C[i] = drand48()*2-1;

        for( i = 0; i < 6; i++) {
	    /* multiply matrices and measure the time */
    errcode  = PAPI_start(EventSet);
    if (errcode != PAPI_OK) {
        fprintf(stderr,"Couldn't start the counters\n");
	fprintf(stderr, "PAPI error %d: %s\n",errcode,PAPI_strerror(errcode));
        exit(-1);
    }
	    gettimeofday( &start, NULL );
	    (*orderings[i])( nmax, A, B, C );
            //multMat1(nmax,A,B,C);
	    gettimeofday( &end, NULL );
PAPI_stop(EventSet, values);
  //  printf("%f\n",x[N/2]);
  printf(" for %s : store-ins: %lld, load ins: %lld L2-misses: %lld \n", names[i],values[0], values[1], values[2]);
	    /* convert time to Gflop/s */
//	    double seconds = (end.tv_sec - start.tv_sec) + 1.0e-6 * (end.tv_usec - start.tv_usec);
//	    double Gflops = 2e-9*nmax*nmax*nmax/seconds;    
//	    printf( "%s:\tn = %d, %.3f Gflop/s\n", names[i], nmax, Gflops );
        }
    } else {
        printf("Running Part A...\n\n");

        for( n = 10; n <= nmax; n = n<nmax && n+1+n/3>nmax ? nmax : n+1+n/3 ) {
	    /* fill matrices with random numbers */
	    for( i = 0; i < n*n; i++ ) A[i] = drand48()*2-1;
	    for( i = 0; i < n*n; i++ ) B[i] = drand48()*2-1;
	    for( i = 0; i < n*n; i++ ) C[i] = drand48()*2-1;

	    /* multiply matrices and measure the time */
    errcode  = PAPI_start(EventSet);
    if (errcode != PAPI_OK) {
        fprintf(stderr,"Couldn't start the counters\n");
	fprintf(stderr, "PAPI error %d: %s\n",errcode,PAPI_strerror(errcode));
        exit(-1);
    }
	    gettimeofday( &start, NULL );
	    multMat1( n, A, B, C );
	    gettimeofday( &end, NULL );

PAPI_stop(EventSet, values);
  //  printf("%f\n",x[N/2]);
  printf(" ijk : store-ins: %lld, load ins: %lld L2-misses: %lld \t", values[0], values[1], values[2]);
	    /* convert time to Gflop/s */
	    double seconds = (end.tv_sec - start.tv_sec) + 1.0e-6 * (end.tv_usec - start.tv_usec);
	    double Gflops = 2e-9*n*n*n/seconds;    
	    printf( "n = %d, %.3f Gflop/s\n", n, Gflops );
        }
    }

    free( A );
    free( B );
    free( C );

    printf("\n\n");

    return 0;
}
