#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

void transpose( int n, int blocksize, int *dst, int *src ) {
    int i,j,ii,jj;
    int bs = blocksize;
    /* to do: implement blocking (two more loops) */
    if(n%bs==0){
    for( i = 0; i < n; i+=bs )
	    for( j = 0; j < n; j+=bs )
		 for(ii = i; ii < i+bs; ii++)
			for(jj = j ; jj < j+bs; jj++)
    				dst[jj+ii*n] = src[ii+jj*n];
    }
    else{ int lmt = n-(n%bs); 
    for( i = 0; i < lmt; i+=bs )
	    for( j = 0; j < lmt; j+=bs )
		 for(ii = i; ii < i+bs; ii++)
			for(jj = j ; jj < j+bs; jj++)
       				dst[jj+ii*n] = src[ii+jj*n];
    for( i = 0; i < lmt; i++ )
	    for( j = lmt; j < n; j++ )
       				dst[j+i*n] = src[i+j*n]; 
    for(i = lmt;i < n; i++)
	    for(j =0; j < n;j++)
       				dst[j+i*n] = src[i+j*n];
    } 
}

int main( int argc, char **argv ) {
    int n=2000,n1=2048,i,j,loop;
    int blocksize ; /* to do: find a better block size */

    /* allocate an n*n block of integers for the matrices */
    int *A = (int*)malloc( n*n*sizeof(int) );
    int *B = (int*)malloc( n*n*sizeof(int) );

    double curr ;
    double prev = 999;
    double temp ;

    printf("\n***********************************************************************************************************************************\n");
    printf("\n\tBLOCKSIZE\tTIMING\t N = 2000\n\n");
    printf("***********************************************************************************************************************************\n");
    
    for(loop=2;loop<1002;loop+=2){


    /* initialize A,B to random integers */
    srand48( time( NULL ) );
    for( i = 0; i < n*n; i++ ) A[i] = lrand48( );
    for( i = 0; i < n*n; i++ ) B[i] = lrand48( );

    /* measure performance */
    struct timeval start, end;

    gettimeofday( &start, NULL );
    transpose( n, loop, B, A );
    gettimeofday( &end, NULL );

    double seconds = (end.tv_sec - start.tv_sec) + 1.0e-6 * (end.tv_usec - start.tv_usec);
    printf( "For blocksize of %d\t%g milliseconds\n",loop,seconds*1e3 );

    curr = seconds*1e3;
    if(prev <= curr)
       temp = prev;
    else {
       temp = curr;
       blocksize = loop;
    }
    prev = temp;
 
    /* check correctness */
    for( i = 0; i < n; i++ )
        for( j = 0; j < n; j++ )
            if( B[j+i*n] != A[i+j*n] ) {
	        printf("Error!!!! Transpose does not result in correct answer!!\n");
	        exit( -1 );
            }
    
    } //  ****************************************************  END OF FOR LOOP  ****************************************  
    printf("\nOptimal blocksize = %d\tCorresponding time = %g\n",blocksize,prev);

  
    printf("\n***********************************************************************************************************************************\n");
    printf("\n\tBLOCKSIZE\tTIMING\t N = 2048\n\n");
    printf("***********************************************************************************************************************************\n");
    /* allocate an n*n block of integers for the matrices */
    int *C = (int*)malloc( n1*n1*sizeof(int) );
    int *D = (int*)malloc( n1*n1*sizeof(int) );

    prev = 999;

    for(loop=2;loop<1002;loop+=2){


    /* initialize A,B to random integers */
    srand48( time( NULL ) );
    for( i = 0; i < n1*n1; i++ ) C[i] = lrand48( );
    for( i = 0; i < n1*n1; i++ ) D[i] = lrand48( );

    /* measure performance */
    struct timeval start, end;

    gettimeofday( &start, NULL );
    transpose( n1, loop, D, C );
    gettimeofday( &end, NULL );

    double seconds = (end.tv_sec - start.tv_sec) + 1.0e-6 * (end.tv_usec - start.tv_usec);
    printf( "For blocksize of %d\t%g milliseconds\n",loop,seconds*1e3 );

    curr = seconds*1e3;
    if(prev <= curr)
       temp = prev;
    else {
       temp = curr;
       blocksize = loop;
    }
    prev = temp;
 
    /* check correctness */
    for( i = 0; i < n1; i++ )
        for( j = 0; j < n1; j++ )
            if( D[j+i*n1] != C[i+j*n1] ) {
                printf("Error!!!! Transpose does not result in correct answer!!\n");
                exit( -1 );
            }
    
    } //  ****************************************************  END OF FOR LOOP  ****************************************
    printf("\nOptimal blocksize = %d\tCorresponding time = %g\n",blocksize,prev);
    /* release resources */
    free( A );
    free( B );
    free( C );
    free( D );
    return 0;
}

