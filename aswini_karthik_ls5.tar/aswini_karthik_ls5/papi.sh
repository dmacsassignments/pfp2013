gcc -I$TACC_PAPI_INC -c -std=c99 matrixMultiply.c -Wimplicit-function-declaration
 gcc -o papi matrixMultiply.o -L$TACC_PAPI_LIB -lpapi
./papi 
#./papil2 ./papil2 2
