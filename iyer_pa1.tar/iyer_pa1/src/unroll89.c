

#include <stdio.h>
#include <math.h>
#include<stdlib.h>
#include "rdtsc.h"

#define N 1024
#define NUM_RUNS 50





/*inline void Unroll4(data_t *y)
{
	float t1;
	for (int i = 0; i < N; i=i+4)
	{
		y[i] = 0;
		y[i+1] = 0;
		y[i+2] = 0;
		y[i+3] = 0;
	}
}

inline void Unroll3(data_t *y)
{
        float t1;
        for (int i = 0; i < N; i=i+3)
        {
                y[i] = 0;
                y[i+1] = 0;
                y[i+2] = 0;
    
        }
}
*/
int Unroll8(int *buffer)
{
 int a,a1,a2,a3,a4,a5,a6,a7/*,a8,a9*/,x;
a = a1= a2= a3=a4=a5=a6=a7/*,a8,a9*/= 0;
for (x=0; x<N-7; x+=8) {
a += buffer[x];
a1 += buffer[x+1];
a2 += buffer[x+2];
a3 += buffer[x+3];
a4 += buffer[x+4];
a5 += buffer[x+5];
a6 += buffer[x+6];
a7 += buffer[x+7];/*
a8 += buffer[x+8];
a9 += buffer[x+9];*/
}
for(;x<N;x++)
a+=buffer[x];
a=a+a1+a2+a3+a4+a5+a6+a7/*+a8+a9*/;
return a;

}
int Unroll9(int *buffer)
{
 int a,a1,a2,a3,a4,a5,a6,a7,a8,x;
a = a1= a2= a3=a4=a5=a6=a7=a8=0;
for (x=0; x<N-8; x+=9) {
a += buffer[x];
a1 += buffer[x+1];
a2 += buffer[x+2];
a3 += buffer[x+3];
a4 += buffer[x+4];
a5 += buffer[x+5];
a6 +=buffer[x+6];
a7 +=buffer[x+7];
a8 +=buffer[x+8]; 
}
for(;x<N;x++)
a+=buffer[x];
a=a+a1+a2+a3+a4+a5+a6+a7+a8;
return a;

}

/*int Unroll(int *buffer)
{
int a=0,x;
for (x=0; x<N; x++) {
a += buffer[x];

}

return a;

}


*/







// typedef data_t int;

int main()
{	
	 int * buffer;
	tsc_counter a, b;
	double cycles;
        int result;

	//N is a define
	buffer = (int*)malloc(sizeof(int)*N);
	//= (float*)_mm_malloc(sizeof(float)*N,16);
//	y = (float*)_mm_malloc(sizeof(float)*N,16);
//	y_vec = (float*)_mm_malloc(sizeof(float)*N,16);

//	if (M == NULL || x == NULL || y == NULL || y_vec == NULL)
//		return 1;

	//init vars
	for (int i = 0; i<N; i++){
			buffer[i] = rand();	
	}
			

	

	
	//-----------------------------------------Timing 1
	//warm up	

	//-----------------No Vec Warmup-------------------
	//lookup task b from the HW here
	//
	//State the Asm. Instructions used by the compiler as a comment here:
	//
	// <--- List of Instructions --->
	//-----------------------------------------Timing 1
	//warm up
		Unroll8(buffer);


	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(int i=0; i<NUM_RUNS; ++i)
	{ 
	   result=Unroll8(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles , result : %d \n",cycles,result);


	//-----------------------------------------Timing 2
	//warm up
		Unroll9(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(int i=0; i<NUM_RUNS; ++i)
	{ 
	result=Unroll9(buffer );
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles,result=%d \n",cycles,result);
	
	

       free(buffer);


	return 0;
}

