

#include <stdio.h>
#include <math.h>
#include<stdlib.h>
#include "rdtsc.h"

#define N 100000
#define NUM_RUNS 50


typedef int data_t ;



/*data_t Unroll6(data_t *buffer)
{
 data_t a,a1,a2,a3,a4,a5;
int x,limit=N-N%6;
a = a1= a2= a3=a4=a5= 0;
for (x=0; x<limit; x+=6) {
a += buffer[x];
a1 += buffer[x+1];
a2 += buffer[x+2];
a3 += buffer[x+3];
a4 += buffer[x+4];
a5 += buffer[x+5];
}
for(;x<N;x++)
a+=buffer[x];
a=a+a1+a2+a3+a4+a5;
return a;

}*/
/*
data_t Unroll7(data_t *buffer)
{
 data_t a,a1,a2,a3,a4,a5,a6;
int x,limit1=N-N%7;
a = a1= a2= a3=a4=a5=a6=0;
for (x=0; x<limit1; x+=7) {
a += buffer[x];
a1 += buffer[x+1];
a2 += buffer[x+2];
a3 += buffer[x+3];
a4 += buffer[x+4];
a5 += buffer[x+5];
a6 +=buffer[x+6];
}
for(;x<N;x++)
a+=buffer[x];
a=a+a1+a2+a3+a4+a5+a6;
return a;

}
*/
data_t Unroll(data_t *buffer)
{
data_t a=0;
int x;
for (x=0; x<N; x++) {
a += buffer[x];

}

return a;

}










int main()
{	
	data_t * buffer;
	tsc_counter a, b;
	double cycles;
        data_t result;
        int i;
	buffer = (data_t*)malloc(sizeof(data_t)*N);


	for ( i = 0; i<N; i++){
			buffer[i] = rand();	
	}
			

        Unroll(buffer);


	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for( i=0; i<NUM_RUNS; ++i)
	{ 
	   result=Unroll(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles , result : %d \n",cycles,result);
	

	
/*	//-----------------------------------------Timing 1
	//warm up	

	//-----------------No Vec Warmup-------------------
	//lookup task b from the HW here
	//
	//State the Asm. Instructions used by the compiler as a comment here:
	//
	// <--- List of Instructions --->
	//-----------------------------------------Timing 1
	//warm up
		Unroll6(buffer);


	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for( i=0; i<NUM_RUNS; ++i)
	{ 
	   result=Unroll6(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles , result : %f \n",cycles,result);


	//-----------------------------------------Timing 2
	//warm up*/
/*		Unroll7(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for( i=0; i<NUM_RUNS; ++i)
	{ 
	result=Unroll7(buffer );
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles,result=%f \n",cycles,result);
	
	
*/
       free(buffer);


	return 0;
}

