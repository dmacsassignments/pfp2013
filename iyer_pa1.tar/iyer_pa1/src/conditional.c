#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define n 2000
#define m 3000

int main()
{
  register double **a, **b,*arow,*brow,*arow1,*brow1;
  register double norm=0.0,norm1=0.0,norm2=0.0,norm3=0.0;
  register int i, j, l,n1=n,m1=m,size1,size;
  size1 = sizeof(double); 
  size = m1*size1;   
  a = (double**)malloc(n1*sizeof(double*));
  b = (double**)malloc(n1*sizeof(double*));

  for(i=0; i<n1; i++)
    {
      a[i] = (double*)malloc(size);
      b[i] = (double*)calloc(m1, size1);
      for(j=0; j<n1; j+=4) 
        {
            a[i][j] = drand48();
            a[i][j+1] = drand48();
            a[i][j+2] = drand48();
            a[i][j+3] = drand48();
    }
    
 }

  for(i=0; i<n1; i++)
   {
    arow = b[i];
    brow = a[i];

    for(l=1;l<=30;l++)
      {
       for(j=0;j<m1;j+=8)
	   { 
                arow1 = arow+j;
                brow1 = brow+j;



                *(arow1)=13* *(arow1) +  *(brow1);arow1++;brow1++;
                *(arow1)=13* *(arow1) -  *(brow1);arow1++;brow1++;

                *(arow1)=13* *(arow1) +  *(brow1);arow1++;brow1++;
                *(arow1)=13* *(arow1) -  *(brow1);arow1++;brow1++;
	
                *(arow1)=13* *(arow1) +  *(brow1);arow1++;brow1++;
                *(arow1)=13* *(arow1) -  *(brow1);arow1++;brow1++;
	
                *(arow1)=13* *(arow1) +  *(brow1);arow1++;brow1++;
                *(arow1)=13* *(arow1) -  *(brow1);
    
            }

       }

}
 
  for(i=0; i<n1; i++)
    {
    for(j=0; j<m1; j+=4)
     {
      norm = norm + fabs(b[i][j]*b[i][j]);
      norm1 = norm1 + fabs(b[i][j+1]*b[i][j+1]);
      norm2 = norm2 + fabs(b[i][j+2]*b[i][j+2]);
      norm3 = norm3 + fabs(b[i][j+3]*b[i][j+3]);
     }
    }
 norm =norm+norm1+norm2+norm3;
  printf("norm: %10.4e    Value: %10.4e\n",norm, b[10][10]);
}
