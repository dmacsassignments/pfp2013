/*
 * comp.c - contains the function superslow that you need to optimize
 *
 *
 */

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


/* f(x, i, j) multiplies or divides by a sine expression depending
   on i + j being odd or even
*/
double f(double x, int i, int j)
{
    if((i + j) & 0x1)
        return x / (1 + sin(M_PI/(i+1)));
    else
        return x * sin(M_PI/(i+1));
}

/* This is the function you need to optimize. It takes one
   square matrix as input
*/
void superslow(smat_t *a)
{
    int i, j;
    double x,x2;

    // i is the column of a we're computing right now
    for(i = 0; i < a->n; i++)
    {
        // j is the row of a we're computing right now
        for(j = 0; j < a->n; j++)
        {            
                // First, compute f(A) for the element of a in question
			x = get_elt(a, i, j);
                x = f(x, i, j);
                
                // Add this to the value of a we're computing and store it
                x2 = get_elt(a, i, j);
			x = x * x2;
                set_elt(a, i, j, x);
            
        }
    }
}


void superslow2(smat_t *a)
{
    int i, j,k=0,l=0;
    double *mat,x,x3;
    int n = a->n;
    // i is the column of a we're computing right now
    for(i = 0; i < n; i++)
     {   
        mat=a->mat+n*i;
        // j is the row of a we're computing right now
        for(j = 0; j < n; j++)
        {            
                x= *(mat + j);      		
                x3=x;
                
                if((i + j) & 0x1)
                x= x / (1 + sin(M_PI/(i+1)));
                else
                x= x * sin(M_PI/(i+1));
                
                x = x * x3;
                *(mat+ j) = x;
        }
    
     }
}


void superslow3(smat_t *a)
{
    int i, j;
    double *mat,x,x3,temp,value1;
    int n = a->n;
    for(i = 0; i < n; i++)
     {   
        mat=a->mat+n*i;
        temp =  sin(M_PI/(i+1));
        value1 = 1 + temp;
        
        for(j = 0; j < n; j++)
        {            
                x= *(mat + j);      		
                x3=x;
          
                if((i + j) & 0x1)
                x= x / value1;
                else
                x= x * temp;

                x = x * x3;
                *(mat+ j) = x;
        }
    
     }
}

void superslow4(smat_t *a)
{
    int i, j;
    double *mat,x,x3,temp,value1;
    int n = a->n;
    for(i = 0; i < n; i+=2)
     {   
        mat=a->mat+n*i;
        temp =  sin(M_PI/(i+1));
        value1 = 1 + temp;
        
        for(j = 0; j < n; j+=2)
        {            
                x= *(mat + j);      		
                x3=x;
                x= x * temp;
                *(mat+ j) = x*x3;
        }
        
        for(j = 1; j < n; j+=2)
        {            
                x= *(mat + j);      		
                x3=x;
                x= x /value1;
                *(mat+ j) = x*x3;
        }
    
     }
        
    for(i = 1; i < n; i+=2)
     {   
        mat=a->mat+n*i;
        temp =  sin(M_PI/(i+1));
        value1 = 1 + temp;
        
        
        for(j = 0; j < n; j+=2)
        {            
                x= *(mat + j);      		
                x3=x;
                x= x / value1;
                *(mat+ j)  = x*x3 ;
        }
        
        for(j = 1; j < n; j+=2)
        {            
                x= *(mat + j);      		
                x3=x;
                x= x *temp;
                *(mat+ j) = x*x3;
        }
    
     }
  }



void superslow5(smat_t *a)
{
    int i, j;
    double *mat,x,y,x3,x4,p,q,x5,x6,temp,value1;
    int n = a->n;
    for(i = 0; i < n; i+=2)
     {   
        
        mat=a->mat+n*i;
        temp =  sin(M_PI/(i+1));
        value1 = 1 + temp;
        
        for(j = 0; j < n; j+=6)
        {            

                mat[ j] = (mat[j]*temp)*mat[j];
                mat[j+1] = (mat[j+1]/value1)*mat[j+1];
                 
                mat[ j+2] = (mat[j+2]*temp)*mat[j+2];
                mat[j+3] = (mat[j+3]/value1)*mat[j+3];
               
                mat[ j+4] = (mat[j+4]*temp)*mat[j+4];
                mat[j+5] = (mat[j+5]/value1)*mat[j+5];
       
       }

    }
    
     
        
    for(i = 1; i < n; i+=2)
     {   
        
        mat=a->mat+n*i;
        temp =  sin(M_PI/(i+1));
        value1 = 1 + temp;
        
        
        for(j = 0; j < n; j+=6)
           {         
                mat[ j] = (mat[j]/value1)*mat[j];
                mat[j+1] = (mat[j+1]*temp)*mat[j+1];
                 
                mat[ j+2] = (mat[j+2]/value1)*mat[j+2];
                mat[j+3] = (mat[j+3]*temp)*mat[j+3];
               
                mat[ j+4] = (mat[j+4]/value1)*mat[j+4];
                mat[j+5] = (mat[j+5]*temp)*mat[j+5];

           }
    
     }

}


    
   
void superslow6(smat_t *a)
{
    int i, j;
    double *mat,temp,value1;
    int n = a->n;
    for(i = 0; i < n; i+=2)
     {   
        
        mat=a->mat+n*i;
        temp =  sin(M_PI/(i+1));
        value1 =1/(1 + temp);
         
        
        for(j = 0; j < n; j+=12)
        {            

                mat[ j] = (mat[j]*temp)*mat[j];
                mat[j+1] = (mat[j+1]*value1)*mat[j+1];
                 
                mat[ j+2] = (mat[j+2]*temp)*mat[j+2];
                mat[j+3] = (mat[j+3]*value1)*mat[j+3];
               
                mat[ j+4] = (mat[j+4]*temp)*mat[j+4];
                mat[j+5] = (mat[j+5]*value1)*mat[j+5];

                   
                mat[ j+6] = (mat[j+6]*temp)*mat[j+6];
                mat[j+7] = (mat[j+7]*value1)*mat[j+7];


                mat[ j+8] = (mat[j+8]*temp)*mat[j+8];
                mat[j+9] = (mat[j+9]*value1)*mat[j+9];

       
                mat[ j+10] = (mat[j+10]*temp)*mat[j+10];
                mat[j+11] = (mat[j+11]*value1)*mat[j+11];
       }

    }
    
     
        
    for(i = 1; i < n; i+=2)
     {   
        
        mat=a->mat+n*i;
        temp =  sin(M_PI/(i+1));
        value1 = 1/(1 + temp);
        
        
        for(j = 0; j < n; j+=12)
           {         
                mat[ j] = (mat[j]*value1)*mat[j];
                mat[j+1] = (mat[j+1]*temp)*mat[j+1];
                 
                mat[ j+2] = (mat[j+2]*value1)*mat[j+2];
                mat[j+3] = (mat[j+3]*temp)*mat[j+3];
               
                mat[ j+4] = (mat[j+4]*value1)*mat[j+4];
                mat[j+5] = (mat[j+5]*temp)*mat[j+5];


                mat[ j+6] = (mat[j+6]*value1)*mat[j+6];
                mat[j+7] = (mat[j+7]*temp)*mat[j+7];

                mat[ j+8] = (mat[j+8]*value1)*mat[j+8];
                mat[j+9] = (mat[j+9]*temp)*mat[j+9];
           
                            
                mat[ j+10] = (mat[j+10]*value1)*mat[j+10];
                mat[j+11] = (mat[j+11]*temp)*mat[j+11];
        }
    
     }

}


void saisuperfast(smat_t *a)
{
    register int i, j,k,n;
    register double *mat,*fmat,*cmat,*imat,temp,value1,temp1,value;
    n = a->n;
    for(i = 0; i < n; i+=2)
     {   
        mat=a->mat+n*i;
        cmat = a->mat+n*(i+1);
        temp = sin(M_PI/(i+1));
        value1 =1/(1 + temp);
        temp1 =sin(M_PI/(i+2));
        value = 1/(1+temp1);
         
        
        for(j = 0; j < n; j+=20)
        {            
                     
                fmat=mat+j;
 
                *fmat = (*fmat*temp)* *(fmat);fmat++;
                *(fmat) = (*(fmat)*value1)* *(fmat);fmat++;
                *(fmat) = (*(fmat)*temp)* *(fmat);fmat++;
                *(fmat) = (*(fmat)*value1)* *(fmat);fmat++;
                *(fmat) = (*(fmat)*temp)* *(fmat);fmat++;
                *(fmat) = (*(fmat)*value1)* *(fmat);fmat++;
                *(fmat) = (*(fmat)*temp)* *(fmat);fmat++;
                *(fmat) = (*(fmat)*value1)* *(fmat);fmat++;
                *(fmat) = (*(fmat)*temp)* *(fmat);fmat++;
                *(fmat) = (*(fmat)*value1)* *(fmat);fmat++;
        
                *fmat = (*fmat*temp)* *(fmat);fmat++;
                *(fmat) = (*(fmat)*value1)* *(fmat);fmat++;
                *(fmat) = (*(fmat)*temp)* *(fmat);fmat++;
                *(fmat) = (*(fmat)*value1)* *(fmat);fmat++;
                *(fmat) = (*(fmat)*temp)* *(fmat);fmat++;
                *(fmat) = (*(fmat)*value1)* *(fmat);fmat++;
                *(fmat) = (*(fmat)*temp)* *(fmat);fmat++;
                *(fmat) = (*(fmat)*value1)* *(fmat);fmat++;






                *(fmat) = (*(fmat)*temp)* *(fmat);fmat++;
                *(fmat) = (*(fmat)*value1)* *(fmat);
                

		imat=cmat+j;
                *imat = (*(imat)*value)* *imat;imat++;
                *(imat) = (*(imat)*temp1)* *(imat);imat++;
                *(imat) = (*(imat)*value)* *(imat);imat++;
                *(imat) = (*(imat)*temp1)* *(imat);imat++;
                *(imat) = (*(imat)*value)* *(imat);imat++;
                *(imat) = (*(imat)*temp1)* *(imat);imat++;
                *(imat) = (*(imat)*value)* *(imat);imat++;
                *(imat) = (*(imat)*temp1)* *(imat);imat++;
                *(imat) = (*(imat)*value)* *(imat);imat++;
                *(imat) = (*(imat)*temp1)* *(imat);imat++;

                *imat = (*(imat)*value)* *imat;imat++;
                *(imat) = (*(imat)*temp1)* *(imat);imat++;
                *(imat) = (*(imat)*value)* *(imat);imat++;
                *(imat) = (*(imat)*temp1)* *(imat);imat++;
                *(imat) = (*(imat)*value)* *(imat);imat++;
                *(imat) = (*(imat)*temp1)* *(imat);imat++;
                *(imat) = (*(imat)*value)* *(imat);imat++;
                *(imat) = (*(imat)*temp1)* *(imat);imat++;




                *(imat) = (*(imat)*value)* *(imat);imat++;
                *(imat) = (*(imat)*temp1)* *(imat);






}

  }
    
     
        
}


        

 




/* 
 * Called by the driver to register your functions
 * Use add_function(func, description) to add your own functions
 */
void register_functions()
{
    // Registers comp_superslow with the driver
    add_function(&superslow, "superslow: original function");
	
	//Add your functions here
	add_function(&superslow2, "superslow: Optimization X");
	
	add_function(&superslow3, "superslow: Optimization X");
	
	add_function(&superslow4, "superslow: Optimization X");
        
	add_function(&superslow5, "superslow: Optimization X");
           
	add_function(&superslow6, "superslow: Optimization X");

        add_function(&saisuperfast, "superslow: Optimization X");

              
  //      add_function(&superslow7, "superslow: Optimization X");


  //      add_function(&superslow8, "superslow: Optimization X");


}
