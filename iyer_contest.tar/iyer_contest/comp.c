/*
* comp.c - contains the function superslow that you need to optimize
*
*
*/

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"
#include<immintrin.h>

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


/* f(x1,x2, i, j) rotates the input vector
*/
double f(double x1, double x2, double* y1, double * y2, int i, int j)
{
	double m[2][2];	

	if (i %4 == 0)
	{
		m[0][0] = cos(i);
		m[0][1] = sin(i);
		m[1][0] = -sin(i);
		m[1][1] = cos(i);
	}
	else
	{
		m[0][0] = cos(-i);
		m[0][1] = sin(-i);
		m[1][0] = -sin(-i);
		m[1][1] = cos(-i);

	}

	*y1 = m[0][0] * x1 + m[0][1]* x2;
	*y2 = m[1][0] * x1 + m[1][1]* x2;
}

/* This is the function you need to optimize. It takes one
square matrix as input
*/
void superslow(smat_t *a)
{
	int i, j;
	double x1,x2,y1,y2;
	double sum1, sum2;


	// j is the column of a we're computing right now
	for(j = 0; j < a->n; j++)
		{

	 	// i is the row of a we're computing right now
			for(i = 0; i < a->n; i=i+2)        
	 		{        
			x1 = get_elt(a,i,j);
			x2 = get_elt(a,i+1,j);
			f(x1,x2,&y1,&y2, i, j);
			sum1 = get_elt(a, i, j) + y1;
			sum2 = get_elt(a, i+1, j) + y2;
			set_elt(a, i, j, sum1);
			set_elt(a, i+1, j, sum2);            
		}
	}
}




void superslow1(smat_t *a)
{
	int i, j;
        int n=a->n;
	double x1,x2,y1,y2;
	double sum1, sum2;
	double *mat;

	double m[2][2];	

	// j is the column of a we're computing right now
	for(i = 0; i < a->n; i+=2)
	{
              
	mat=a->mat+n*i;

	if (i %4 == 0)
	{
		m[0][0] = cos(i);
		m[0][1] = sin(i);
		m[1][0] = -sin(i);
		m[1][1] = cos(i);
	}
	else
	{
		m[0][0] = cos(-i);
		m[0][1] = sin(-i);
		m[1][0] = -sin(-i);
		m[1][1] = cos(-i);

	}


		for(j = 0; j < a->n;j++)        
		{            
			// First, compute f(A) for the element of a in question
			x1 = *(mat+j);
			x2 = *(mat+j+n);


			y1 = m[0][0] * x1 + m[0][1]* x2;
			y2 = m[1][0] * x1 + m[1][1]* x2;
			

			// Add this to the value of a we're computing and store it                
			sum1 = x1 + y1;
			sum2 = x2 + y2;

                        *(mat+j)=sum1;
			*(mat+j+n)=sum2;
		}
	}
}



void superslow2(smat_t *a)
{
	int i, j;
        int n=a->n;
	double x1,x2;
	double icos,isin;
	double *mat;

	double m[2][2];	

	// j is the column of a we're computing right now
	for(i = 0; i < n; i+=2)
	{
        icos=cos(i);
	isin=sin(i);      
	mat=a->mat+n*i;

	if (i %4 == 0)
	{
		m[0][0] = icos;
		m[0][1] = isin;
		m[1][0] =-isin;
		m[1][1] = icos;
	}
	else
	{
		m[0][0] = icos;
		m[0][1] = -isin;
		m[1][0] = isin;
		m[1][1] = icos;

	}

		for(j = 0; j < n;j++)        
		{            
			 x1 = mat[j];
			 x2 = mat[j+n];

		         mat[j]=x1+ m[0][0] * x1 + m[0][1]*x2;
			 mat[j+n]=x2+ m[1][0] *x1 + m[1][1]*x2;

		}
	}
}



void superslow3(smat_t *__restrict__ a)
{
	register int i, j,n;
        n=a->n;
	register double x1, x2,icos,isin;
	register double *mat;

	// j is the column of a we're computing right now
	for(i = 0; i < n-2;i+=4)
	{
        icos=cos(i);
	isin=sin(i);      
	mat=a->mat+n*i;

		for(j = 0; j < n;j++)        
		{            
			 x1 = mat[j];
			 x2 = mat[j+n];


		         mat[j]=x1+ icos * x1 + isin*x2;
			 mat[j+n]=x2 -isin *x1 + icos*x2;




		}
	}


	for(i = 2; i < n; i+=4)
	{
        icos=cos(i);
	isin=sin(i);      
	mat=a->mat+n*i;

		for(j = 0; j < n;j++)        
		{            
			 x1 = mat[j];
			 x2 = mat[j+n];

		         mat[j]=x1+ icos * x1  -isin*x2;
			 mat[j+n]=x2+ isin *x1 + icos*x2;

		}

	}

}



void superslow4(smat_t *__restrict__ a)
{
	register int i, j,n;
        n=a->n;

	register double x1, x2,x3,x4,icos,isin,icos1,isin1;
	register double *mat,*mat1;


	// j is the column of a we're computing right now
	for(i = 0; i < n-2;i+=4)
	{
        icos=cos(i);
	isin=sin(i);      
	mat=a->mat+n*i;
	icos1=cos(i+2);
	isin1=sin(i+2);
	mat1=mat+2*n;

	for(j = 0; j < n;j++)        
		{            
			 x1 = mat[j];
			 x2 = mat[j+n];

		         mat[j]=x1+ icos * x1 + isin*x2;
			 mat[j+n]=x2 - isin *x1 + icos*x2;

			 x3 = mat1[j];
			 x4 = mat1[j+n];



		         mat1[j]=x3+ icos1 * x3 -isin1*x4;
			 mat1[j+n]=x4+ isin1 *x3 + icos1*x4;

		}

	}

}


void superslow5(smat_t *a)
{
	register int i, j,n;
        n=a->n;

	register double icos,isin,icos1,isin1,x1,x2,x3,x4,y1,y2,y3,y4;
	register double *mat,*mat1;


	// j is the column of a we're computing right now
	for(i = 0; i < n-2;i+=4)
	{
        icos=cos(i);
	isin=sin(i);      
	mat=a->mat+n*i;
	icos1=cos(i+2);
	isin1=sin(i+2);
	mat1=mat+2*n;

	for(j = 0; j < n;j+=4)        
		{        


	 		 x1 = mat[j];
			 x2 = mat[j+1];
			 x3 = mat[j+2];
			 x4 = mat[j+3];
			 y1 = mat[j+n];
			 y2 = mat[j+1+n];
			 y3 = mat[j+2+n];
			 y4 = mat[j+3+n];
			 mat[j]=x1+ icos * x1 +isin*y1;
			 mat[j+1]=x2+ icos * x2 +isin*y2;
			 mat[j+2]=x3+ icos * x3 +isin*y3;
			 mat[j+3]=x4+ icos * x4 +isin*y4;
			 
			 mat[j+n]=y1- isin *x1 + icos*y1;
			 mat[j+1+n]=y2- isin *x2 + icos*y2;
			 mat[j+2+n]=y3- isin *x3 + icos*y3;
			 mat[j+3+n]=y4- isin *x4 + icos*y4;





/*



	          	__m256d x = _mm256_loadu_pd(mat+j);
	          	__m256d y = _mm256_loadu_pd(mat+j+n);
	          	__m256d ic = _mm256_set1_pd(icos);
	          	__m256d is = _mm256_set1_pd(isin);
	          	__m256d result1 = _mm256_add_pd(x,_mm256_add_pd(_mm256_mul_pd(ic,x),_mm256_mul_pd(is,y)));
	          	__m256d result2 = _mm256_sub_pd(y,_mm256_add_pd(_mm256_mul_pd(is,x),_mm256_mul_pd(ic,y)));

	          	 _mm256_storeu_pd(mat+j,result1);
	          	 _mm256_storeu_pd(mat+j+n,result2);

	          	__m256d x1 = _mm256_loadu_pd(mat1+j);
	          	__m256d y1 = _mm256_loadu_pd(mat1+j+n);
	          	__m256d ic1 = _mm256_set1_pd(icos1);
	          	__m256d is1 = _mm256_set1_pd(isin1);
	          	__m256d result11 = _mm256_add_pd(x1,_mm256_sub_pd(_mm256_mul_pd(ic1,x1),_mm256_mul_pd(is1,y1)));
	          	__m256d result21 = _mm256_add_pd(y1,_mm256_add_pd(_mm256_mul_pd(is1,x1),_mm256_mul_pd(ic1,y1)));

	          	 _mm256_storeu_pd(mat1+j,result11);
	          	 _mm256_storeu_pd(mat1+j+n,result21);*/


	 		 x1 = mat1[j];
			 x2 = mat1[j+1];
			 x3 = mat1[j+2];
			 x4 = mat1[j+3];
			 y1 = mat1[j+n];
			 y2 = mat1[j+1+n];
			 y3 = mat1[j+2+n];
			 y4 = mat1[j+3+n];
			 mat1[j]=x1+ icos1 * x1 -isin1*y1;
			 mat1[j+1]=x2+ icos1 * x2 -isin1*y2;
			 mat1[j+2]=x3+ icos1 * x3 -isin1*y3;
			 mat1[j+3]=x4+ icos1 * x4 -isin1*y4;
			 
			 mat1[j+n]=y1+ isin1 *x1 + icos1*y1;
			 mat1[j+1+n]=y2+ isin1 *x2 + icos1*y2;
			 mat1[j+2+n]=y3+ isin1 *x3 + icos1*y3;
			 mat1[j+3+n]=y4+ isin1 *x4 + icos1*y4;

		}

	}

}

/* 
* Called by the driver to register your functions
* Use add_function(func, description) to add your own functions
*/
void register_functions()
{
	// Registers comp_superslow with the driver
	add_function(&superslow, "superslow: original function");
	add_function(&superslow1, "fast: optimized version 1");

	add_function(&superslow2, "fast: optimized version 2");
	//Add your functions here
	
	add_function(&superslow3, "fast: optimized version 3");

	add_function(&superslow4, "fast: optimized version 4");

//	add_function(&superslow5, "fast: optimized version 5");
	//add_function(&superslow2, "superslow: Optimization X");


}
