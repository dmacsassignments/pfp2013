const char* dgemm_desc = "Aswini and Karthik.P dgemm.";

#ifndef BLOCK_SIZE
#define BLOCK_SIZE ((int) 32)
#endif


 void basic_dgemm(register const int lda, register const int M, register const int N, register const int K,
                 register const double *A, register const double *B, register double *C)
 {
                  register int ri,rj,rk,cnt;
                  register double b1,b2,b3,b4,b5,b6,b7,b8;
                for(rj=0;rj<N;++rj) {
                 cnt = rj*lda;
                     for(rk=0;rk <(K-7);rk+=8) {
		       b1 = B[cnt + rk];
                       b2 = B[cnt + rk+1];
                       b3 = B[cnt + rk+2];
                       b4 = B[cnt + rk+3];
                       b5 = B[cnt + rk+4];
                       b6 = B[cnt + rk+5];
                       b7 = B[cnt + rk+6];
           	       b8 = B[cnt + rk+7];
                          for(ri =0;ri<M;++ri) {
                   register double cij = C[rj*lda+ri],c1,c2,c3,c4,c5,c6,c7,c8; c1=c2=c3=c4=c5=c6=c7=c8=0;
                              cij += A[rk*lda+ri]*b1;
                              cij += A[(rk+1)*lda+ri]*b2;
                              cij += A[(rk+2)*lda+ri]*b3;
                              cij += A[(rk+3)*lda+ri]*b4;
                              cij += A[(rk+4)*lda+ri]*b5;
                              cij += A[(rk+5)*lda+ri]*b6;
                              cij += A[(rk+6)*lda+ri]*b7;
                              cij += A[(rk+7)*lda+ri]*b8;
                     C[rj*lda+ri]=cij;
                }
           }
   if(K%8) {
      b1=B[rj*lda+rk];
           for(ri =0;ri < M;++ri) {
                               double cij = C[rj*lda+ri];
                               cij += A[rk*lda+ri]*b1;
                               C[rj*lda+ri]=cij;
                             }
                        }
   }
 }

 void do_block(const int lda,
               const double *A, const double *B, double *C,
               const int i, const int j, const int k)
 {
     const int M = (i+BLOCK_SIZE > lda? lda-i : BLOCK_SIZE);
     const int N = (j+BLOCK_SIZE > lda? lda-j : BLOCK_SIZE);
     const int K = (k+BLOCK_SIZE > lda? lda-k : BLOCK_SIZE);
     basic_dgemm(lda, M, N, K,
                 A + i + k*lda, B + k + j*lda, C + i + j*lda);
 }

 void square_dgemm(const int M, const double *A, const double *B, double *C)
 {
     const int n_blocks = M / BLOCK_SIZE + (M%BLOCK_SIZE? 1 : 0);
     int bi, bj, bk;
         for (bj = 0; bj < n_blocks; ++bj) {
             const int j = bj * BLOCK_SIZE;
             for (bk = 0; bk < n_blocks; ++bk) {
                 const int k = bk * BLOCK_SIZE;
                for (bi = 0; bi < n_blocks; ++bi) {
                  const int i = bi * BLOCK_SIZE;
                 do_block(M, A, B, C, i, j, k);
             }
         }
     }
 }

