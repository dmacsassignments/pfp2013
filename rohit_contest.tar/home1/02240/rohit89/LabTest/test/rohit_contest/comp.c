CC     = gcc
# GCC architecture flags
#AFLAGS = -m64 -march=corei7-avx -fno-tree-vectorize
AFLAGS = -m64 -mavx -ftree-vectorize -funroll-loops -ffast-math -march=corei7-avx -mtune=corei7-avx
# GCC debugging flags

#DFLAGS #= -g -Wall
CFLAGS = -O0 $(AFLAGS)# $(DFLAGS)
LIBS   = -lm
