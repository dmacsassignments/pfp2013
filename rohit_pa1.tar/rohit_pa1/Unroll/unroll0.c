#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "rdtsc.h"
#define N 1000
#define M 1000
#define NUM_RUNS 50

typedef double data_t;

inline void Unroll1(data_t *);
inline void Unroll1(data_t *y)
{	data_t t1 = 0;
	int i;
	for ( i = 0; i < N; i=i+1)
	{	t1 += y[i];
	}
	for(; i < N; i++)
		t1 += y[i];


	y[0] = t1;
}

inline void Unroll2(data_t *);
inline void Unroll2(data_t *y)
{
	data_t t,t2;
	t = t2 = 0;
	int i;
	for ( i = 0; i < N; i=i+2)
	{	t += y[i];
		t2 += y[i+1];
	}
	for(; i < N; i++)
		t += y[i];
	
	t = t + t2; 
	y[0] = t;

}

inline void Unroll3(data_t *);
inline void Unroll3(data_t *y)
{
	data_t t, t1 ,t2;
	t = t1 = t2 = 0;
	int i;
	for ( i = 0; i < N; i=i+3)
	{
		t += y[i];
		t1 += y[i+1];
		t2 += y[i+2];
	}
	for(; i < N; i++)
		t1 += y[i];

	t = t + t1 + t2; 
	y[0] = t;

}

inline void Unroll4(data_t *);
inline void Unroll4(data_t *y)
{
	data_t t,t1,t2,t3;
	t = t1 = t2 = t3 = 0;
	int i;
	for ( i = 0; i < N; i=i+4)
	{
		t += y[i];
		t1 += y[i+1];
		t2 += y[i+2];
		t3 += y[i+3];
	}
	for(; i < N; i++)
		t1 += y[i];

	t = t + t1 + t2 + t3; 
	y[0] = t;
}

inline void Unroll5(data_t *);
inline void Unroll5(data_t *y)
{
	data_t t,t1,t2,t3,t4;
	t = t1 = t2 = t3 = t4 = 0;
	int i;
	for ( i = 0; i < N; i=i+5)
	{
		t += y[i];
		t1 += y[i+1];
		t2 += y[i+2];
		t3 += y[i+3];
		t4 += y[i+4];
	}
	for(; i < N; i++)
		t1 += y[i];

	t = t + t1 + t2 + t3 + t4; 
	y[0] = t;
}


inline void Unroll6(data_t *);
inline void Unroll6(data_t *y)
{
	data_t t ,t1,t2,t3,t4,t5;
	t = t1 = t2 = t3 = t4 = t5 = 0;
	int i;
	for ( i = 0; i < N; i=i+6)
	{
		t += y[i];
		t1 += y[i+1];
		t2 += y[i+2];
		t3 += y[i+3];
		t4 += y[i+4];
		t5 += y[i+5];
	}
	for(; i < N; i++)
		t1 += y[i];

	t = t + t1 + t2 + t3 +  t4 + t5; 	
	y[0] = t;
}

inline void Unroll7(data_t *);
inline void Unroll7(data_t *y)
{
	data_t t ,t1,t2,t3,t4,t5,t6;
	t = t1 = t2 = t3 = t4 = t5 = t6 = 0;
	int i;
	for ( i = 0; i < N; i=i+7)
	{
		t += y[i];
		t1 += y[i+1];
		t2 += y[i+2];
		t3 += y[i+3];
		t4 += y[i+4];
		t5 += y[i+5];
		t6 += y[i+6];
	}
	for(; i < N; i++)
		t1 += y[i];

	t = t + t1 + t2 + t3 +  t4 + t5 + t6; 	
	y[0] = t;
}

inline void Unroll8(data_t *);
inline void Unroll8(data_t *y)
{
	data_t t ,t1,t2,t3,t4,t5,t6,t7;
	t = t1 = t2 = t3 = t4 = t5 = t6= t7 = 0;
	int i;
	for ( i = 0; i < N; i=i+8)
	{
		t += y[i];
		t1 += y[i+1];
		t2 += y[i+2];
		t3 += y[i+3];
		t4 += y[i+4];
		t5 += y[i+5];
		t6 += y[i+6];
		t7 += y[i+7];
	}
	for(; i < N; i++)
		t1 += y[i];

	t = t + t1 + t2 + t3 +  t4 + t5 + t6 + t7;
	y[0] = t;
}

inline void Unroll9(data_t *);
inline void Unroll9(data_t *y)
{
	data_t t ,t1,t2,t3,t4,t5,t6,t7,t8;
	t = t1 = t2 = t3 = t4 = t5 = t6= t7 = t8 = 0;
	int i;
	for ( i = 0; i < N; i=i+9)
	{
		t += y[i];
		t1 += y[i+1];
		t2 += y[i+2];
		t3 += y[i+3];
		t4 += y[i+4];
		t5 += y[i+5];
		t6 += y[i+6];
		t7 += y[i+7];
		t8 += y[i+8];

	}
	for(; i < N; i++)
		t1 += y[i];

	t = t + t1 + t2 + t3 +  t4 + t5 + t6 + t7 + t8;
	y[0] = t;
}

inline void Unroll10(data_t *);
inline void Unroll10(data_t *y)
{
	data_t t ,t1,t2,t3,t4,t5,t6,t7,t8,t9;
	t = t1 = t2 = t3 = t4 = t5 = t6= t7 = t8 = t9 = 0;
	int i;
	for ( i = 0; i < N; i=i+10)
	{
		t += y[i];
		t1 += y[i+1];
		t2 += y[i+2];
		t3 += y[i+3];
		t4 += y[i+4];
		t5 += y[i+5];
		t6 += y[i+6];
		t7 += y[i+7];
		t8 += y[i+8];
		t9 += y[i+9];
	}
	for(; i < N; i++)
		t1 += y[i];

	t = t + t1 + t2 + t3 +  t4 + t5 + t6 + t7 + t8 + t9;
	y[0] = t;
}

inline void Unroll11(data_t *);
inline void Unroll11(data_t *y)
{
	data_t t ,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;
	t = t1 = t2 = t3 = t4 = t5 = t6= t7 = t8 = t9 = t10 = 0;
	int i;
	for ( i = 0; i < N; i=i+11)
	{
		t += y[i];
		t1 += y[i+1];
		t2 += y[i+2];
		t3 += y[i+3];
		t4 += y[i+4];
		t5 += y[i+5];
		t6 += y[i+6];
		t7 += y[i+7];
		t8 += y[i+8];
		t9 += y[i+9];
		t10 += y[i+10];
	}
	for(; i < N; i++)
		t1 += y[i];

	t = t + t1 + t2 + t3 +  t4 + t5 + t6 + t7 + t8 + t9 + t10;
	y[0] = t;
}


inline void Unroll12(data_t *);
inline void Unroll12(data_t *y)
{
	data_t t ,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11;
	t = t1 = t2 = t3 = t4 = t5 = t6= t7 = t8 = t9 = t10 = t11 = 0;
	int i;
	for ( i = 0; i < N; i=i+12)
	{
		t += y[i];
		t1 += y[i+1];
		t2 += y[i+2];
		t3 += y[i+3];
		t4 += y[i+4];
		t5 += y[i+5];
		t6 += y[i+6];
		t7 += y[i+7];
		t8 += y[i+8];
		t9 += y[i+9];
		t10 += y[i+10];
		t11 += y[i+11];
	}
	for(; i < N; i++)
		t1 += y[i];

	t = t + t1 + t2 + t3 +  t4 + t5 + t6 + t7 + t8 + t9 + t10 + t11;
	y[0] = t;
}

inline void Unroll13(data_t *);
inline void Unroll13(data_t *y)
{
	data_t t ,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12;
	t = t1 = t2 = t3 = t4 = t5 = t6= t7 = t8 = t9 = t10 = t11 = t12 = 0;
	int i;
	for ( i = 0; i < N; i=i+13)
	{
		t += y[i];
		t1 += y[i+1];
		t2 += y[i+2];
		t3 += y[i+3];
		t4 += y[i+4];
		t5 += y[i+5];
		t6 += y[i+6];
		t7 += y[i+7];
		t8 += y[i+8];
		t9 += y[i+9];
		t10 += y[i+10];
		t11 += y[i+11];
		t12 += y[i+12];
	}
	for(; i < N; i++)
		t1 += y[i];

	t = t + t1 + t2 + t3 +  t4 + t5 + t6 + t7 + t8 + t9 + t11 + t12;
	y[0] = t;
}

inline void Unroll15(data_t *);
inline void Unroll15(data_t *y)
{
	data_t t ,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14;
	t = t1 = t2 = t3 = t4 = t5 = t6= t7 = t8 = t9 =t10 = t11 = t12 = t13 = t14 = 0;
	int i;
	for ( i = 0; i < N; i=i+15)
	{
		t += y[i];
		t1 += y[i+1];
		t2 += y[i+2];
		t3 += y[i+3];
		t4 += y[i+4];
		t5 += y[i+5];
		t6 += y[i+6];
		t7 += y[i+7];
		t8 += y[i+8];
		t9 += y[i+9];
		t10 += y[i+10];
		t11 += y[i+11];
		t12 += y[i+12];
		t13 += y[i+13];
		t14 += y[i+15];
	
	}
	for(; i < N; i++)
		t1 += y[i];

	t = t + t1 + t2 + t3 +  t4 + t5 + t6 + t7 + t8 + t9 + t10 + t11 + t12 + t13 + t14;
	y[0] = t;
}

inline void Unroll18(data_t *);
inline void Unroll18(data_t *y)
{
	data_t t ,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16,t17;
	t = t1 = t2 = t3 = t4 = t5 = t6= t7 = t8 = t9 =t10 = t11 = t12 = t13 = t14 = t15 = t16 = t17 = 0;
	int i;
	for ( i = 0; i < N; i=i+18)
	{
		t += y[i];
		t1 += y[i+1];
		t2 += y[i+2];
		t3 += y[i+3];
		t4 += y[i+4];
		t5 += y[i+5];
		t6 += y[i+6];
		t7 += y[i+7];
		t8 += y[i+8];
		t9 += y[i+9];
		t10 += y[i+10];
		t11 += y[i+11];
		t12 += y[i+12];
		t13 += y[i+13];
		t14 += y[i+14];
		t15 += y[i+15];
		t16 += y[i+16];
		t17 += y[i+17];
	
	}
	for(; i < N; i++)
		t1 += y[i];

	t = t + t1 + t2 + t3 +  t4 + t5 + t6 + t7 + t8 + t9 + t10 + t11 + t12 + t13 + t14  + t15 + t16 + t17;
	y[0] = t;
}

inline void Unroll20(data_t *);
inline void Unroll20(data_t *y)
{
	data_t t ,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16,t17,t18,t19;
	t = t1 = t2 = t3 = t4 = t5 = t6= t7 = t8 = t9 =t10 = t11 = t12 = t13 = t14 = t15 = t16 = t17 = t18 = t19 = 0;
	int i;
	for ( i = 0; i < N; i=i+20)
	{
		t += y[i];
		t1 += y[i+1];
		t2 += y[i+2];
		t3 += y[i+3];
		t4 += y[i+4];
		t5 += y[i+5];
		t6 += y[i+6];
		t7 += y[i+7];
		t8 += y[i+8];
		t9 += y[i+9];
		t10 += y[i+10];
		t11 += y[i+11];
		t12 += y[i+12];
		t13 += y[i+13];
		t14 += y[i+14];
		t15 += y[i+15];
		t16 += y[i+16];
		t17 += y[i+17];
		t18 += y[i+18];
		t19 += y[i+19];
	
	}
	for(; i < N; i++)
		t1 += y[i];

	t = t + t1 + t2 + t3 +  t4 + t5 + t6 + t7 + t8 + t9 + t10 + t11 + t12 + t13 + t14  + t15 + t16 + t17 + t18 + t19;
	y[0] = t;
}


inline void Unroll24(data_t *);
inline void Unroll24(data_t *y)
{
	data_t t ,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16,t17,t18,t19,t20,t21,t22,t23;
	t = t1 = t2 = t3 = t4 = t5 = t6= t7 = t8 = t9 =t10 = t11 = t12 = t13 = t14 = t15 = t16 = t17 = t18 = t19 = t20 = t21 = t22 = t23 =  0;
	int i;
	for ( i = 0; i < N; i=i+24)
	{
		t += y[i];
		t1 += y[i+1];
		t2 += y[i+2];
		t3 += y[i+3];
		t4 += y[i+4];
		t5 += y[i+5];
		t6 += y[i+6];
		t7 += y[i+7];
		t8 += y[i+8];
		t9 += y[i+9];
		t10 += y[i+10];
		t11 += y[i+11];
		t12 += y[i+12];
		t13 += y[i+13];
		t14 += y[i+14];
		t15 += y[i+15];
		t16 += y[i+16];
		t17 += y[i+17];
		t18 += y[i+18];
		t19 += y[i+19];
		t20 += y[i+20];
		t21 += y[i+21];
		t22 += y[i+22];
		t23 += y[i+23];
	
	}
	for(; i < N; i++)
		t1 += y[i];

	t = t + t1 + t2 + t3 +  t4 + t5 + t6 + t7 + t8 + t9 + t10 + t11 + t12 + t13 + t14  + t15 + t16 + t17 + t18 + t19 + t20  + t21 + t22 + t23;
	y[0] = t;
}


inline void Unroll28(data_t *);
inline void Unroll28(data_t *y)
{
	data_t t ,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16,t17,t18,t19,t20,t21,t22,t23,t24,t25,t26,t27;
	t = t1 = t2 = t3 = t4 = t5 = t6= t7 = t8 = t9 =t10 = t11 = t12 = t13 = t14 = t15 = t16 = t17 = t18 = t19 = t20 = t21 = t22 = t23 = t24=  t25 = t26 = t27  = 0;
	int i;
	for ( i = 0; i < N; i=i+28)
	{
		t += y[i];
		t1 += y[i+1];
		t2 += y[i+2];
		t3 += y[i+3];
		t4 += y[i+4];
		t5 += y[i+5];
		t6 += y[i+6];
		t7 += y[i+7];
		t8 += y[i+8];
		t9 += y[i+9];
		t10 += y[i+10];
		t11 += y[i+11];
		t12 += y[i+12];
		t13 += y[i+13];
		t14 += y[i+14];
		t15 += y[i+15];
		t16 += y[i+16];
		t17 += y[i+17];
		t18 += y[i+18];
		t19 += y[i+19];
		t20 += y[i+20];
		t21 += y[i+21];
		t22 += y[i+22];
		t23 += y[i+23];
		t24 += y[i+24];
		t25 += y[i+25];
		t26 += y[i+26];
		t27 += y[i+27];
	
	}
	for(; i < N; i++)
		t1 += y[i];

	t = t + t1 + t2 + t3 +  t4 + t5 + t6 + t7 + t8 + t9 + t10 + t11 + t12 + t13 + t14  + t15 + t16 + t17 + t18 + t19 + t20  + t21 + t22 + t23+ t24 + t25 + t26 + t27;
	y[0] = t;
}


/*
inline data_t* duffUnroll(int , data_t *,int );
inline data_t* duffUnroll(int temp, data_t *y,int size)
{	register data_t *to = NULL, *from = NULL; 
	from = y;
	data_t x[temp];
	to = x;
	int temp1 = temp;
	register int count = temp;

      while( (temp1 += temp) < size)
      {
	register int n=(count + 24)/25;
		 switch(count % 25){
			 case 0: do{
					 *to++ = *from++;
			 case 24: *to++ = *from++;
			 case 23: *to++ = *from++;
			 case 22: *to++ = *from++;
			 case 21: *to++ = *from++;
			 case 20: *to++ = *from++;
			 case 19: *to++ = *from++;
			 case 18: *to++ = *from++;
			 case 17: *to++ = *from++;
			 case 16: *to++ = *from++;
			 case 15: *to++ = *from++;
			 case 14: *to++ = *from++;
			 case 13: *to++ = *from++;
			 case 12: *to++ = *from++;
			 case 11: *to++ = *from++;
			 case 10: *to++ = *from++;
			 case 9: *to++ = *from++;
			 case 8: *to++ = *from++;
			 case 7: *to++ = *from++;
			 case 6: *to++ = *from++;
			 case 5: *to++ = *from++;
			 case 4: *to++ = *from++;
			 case 3: *to++ = *from++; 
			 case 2: *to++ = *from++; 
			 case 1: *to++ = *from++;
				 }while(--n>0); 
			}
       }
//	to = NULL;
//	free(to);
//	from =NULL;
//	free(NULL); 
return to;
}
*/				

int main()
{	
	system("clear");
	data_t * buffer;
	tsc_counter a, b;
	double cycles, baseline;

	//N is a define
//	buffer = (float*)_mm_malloc(sizeof(float)*N*N,16);
	buffer = (data_t*)malloc(sizeof(data_t)*N);
	
//	x = (float*)_mm_malloc(sizeof(float)*N,16);
///	y = (float*)_mm_malloc(sizeof(float)*N,16);
//	y_vec = (float*)_mm_malloc(sizeof(float)*N,16);

	if (buffer == NULL)// x == NULL || y == NULL || y_vec == NULL)
		return 1;

	//init vars
	int i;
	for ( i = 0; i<N; i++){
			buffer[i] = rand();	
	}
	data_t temp = buffer[0];
	
	Unroll1(buffer);
	buffer[0]= temp;

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		buffer[0]= temp;
		Unroll1(buffer);

	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Single Unroll ... Result : %1.0f\n",cycles,buffer[0]);
	baseline = cycles;

/*
	//-----------------------------------------Timing 2
	//warm up	

	//-----------------No Vec Warmup-------------------
	buffer[0] = temp;
	data_t *res;
	int j;	
     for(j  = 1; j <= 25 ; j++)
     {
	res = duffUnroll(j,buffer,N);
//	buffer[0]= temp;

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ printf("SAiram\n"); 
	res = duffUnroll(j,buffer,N);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Unroll factor : %d ... Speedup: %2.2f x Result : %1.0f\n",cycles,j,baseline/cycles,*res);
    }
*/	//-----------------------------------------Timing 1
	//warm up	

	//-----------------No Vec Warmup-------------------
	//lookup task b from the HW here
	//
	//State the Asm. Instructions used by the compiler as a comment here:
	//
	// <--- List of Instructions --->
	//-----------------------------------------Timing 1
	//warm up
	//lookup task b from the HW here
	//
	//State the Asm. Instructions used by the compiler as a comment here:
	//
	// <--- List of Instructions --->
	//-----------------------------------------Timing 2
	//warm up
		buffer[0]= temp;
		Unroll2(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		buffer[0]= temp;
		Unroll2(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through double unrolling code - %1.0f\n",cycles,baseline/cycles,buffer[0]);

	//-----------------------------------------Timing 3
	//warm up	

	//-----------------No Vec Warmup-------------------
	//lookup task b from the HW here
	//
	//State the Asm. Instructions used by the compiler as a comment here:
	//
	// <--- List of Instructions --->
	//-----------------------------------------Timing 3
	//warm up
		buffer[0]= temp;
		Unroll3(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		buffer[0]= temp;
		Unroll3(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through triply unrolled code - %1.0f\n",cycles,baseline/cycles,buffer[0]);



	//-----------------------------------------Timing 4
	//warm up
	buffer[0]= temp;
		Unroll4(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for( i=0; i<NUM_RUNS; ++i)
	{ 
		buffer[0]= temp;
		Unroll4(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through quad unrolled code - %1.0f\n",cycles,baseline/cycles,buffer[0]);

	
	
	//-----------------------------------------Timing 5
	//warm up	

	//-----------------No Vec Warmup-------------------
	//lookup task b from the HW here
	//
	//State the Asm. Instructions used by the compiler as a comment here:
	//
	// <--- List of Instructions --->
	//-----------------------------------------Timing 5
	//warm up
		buffer[0]= temp;
		Unroll5(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		buffer[0]= temp;
		Unroll5(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through penta unrolled code - %1.0f\n",cycles,baseline/cycles,buffer[0]);


	//-----------------------------------------Timing 6
	//warm up	

	//-----------------No Vec Warmup-------------------
	//lookup task b from the HW here
	//
	//State the Asm. Instructions used by the compiler as a comment here:
	//
	// <--- List of Instructions --->
	//-----------------------------------------Timing 6
	//warm up
		buffer[0]= temp;
		Unroll6(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		buffer[0]= temp;
		Unroll6(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through hexa unrolled code - %1.0f\n",cycles,baseline/cycles,buffer[0]);


	//-----------------------------------------Timing 7
	//warm up	

	//-----------------No Vec Warmup-------------------
	//lookup task b from the HW here
	//
	//State the Asm. Instructions used by the compiler as a comment here:
	//
	// <--- List of Instructions --->
	//-----------------------------------------Timing 7
	//warm up
		buffer[0]= temp;
		Unroll7(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		buffer[0]= temp;
		Unroll7(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through septa unrolled code - %1.0f\n",cycles,baseline/cycles,buffer[0]);


	//-----------------------------------------Timing 8
	//warm up	

	//-----------------No Vec Warmup-------------------
	//lookup task b from the HW here
	//
	//State the Asm. Instructions used by the compiler as a comment here:
	//
	// <--- List of Instructions --->
	//-----------------------------------------Timing 8
	//warm up
		buffer[0]= temp;
		Unroll8(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		buffer[0]= temp;
		Unroll8(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through  octa unrolled code - %1.0f\n",cycles,baseline/cycles,buffer[0]);


		buffer[0]= temp;
		Unroll9(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		buffer[0]= temp;
		Unroll9(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through nine times unrolling code - %1.0f\n",cycles,baseline/cycles,buffer[0]);

	//-----------------------------------------Timing 3
	//warm up	
		buffer[0]= temp;
		Unroll10(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		buffer[0]= temp;
		Unroll10(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through ten times  unrolling code - %1.0f\n",cycles,baseline/cycles,buffer[0]);

	//-----------------------------------------Timing 3
	//warm up	
		buffer[0]= temp;
		Unroll11(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		buffer[0]= temp;
		Unroll11(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through eleven times unrolling code - %1.0f\n",cycles,baseline/cycles,buffer[0]);

	//-----------------------------------------Timing 3
	//warm up	
		buffer[0]= temp;
		Unroll12(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		buffer[0]= temp;
		Unroll12(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through 12 times unrolling code - %1.0f\n",cycles,baseline/cycles,buffer[0]);

	//-----------------------------------------Timing 3
	//warm up	
		buffer[0]= temp;
		Unroll13(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		buffer[0]= temp;
		Unroll13(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through 13 times unrolling code - %1.0f\n",cycles,baseline/cycles,buffer[0]);

	//-----------------------------------------Timing 3
	//warm up	
		buffer[0]= temp;
		Unroll15(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		buffer[0]= temp;
		Unroll15(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through fifteen times  unrolling code - %1.0f\n",cycles,baseline/cycles,buffer[0]);

	//-----------------------------------------Timing 3
	//warm up	
		buffer[0]= temp;
		Unroll18(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		buffer[0]= temp;
		Unroll18(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through eighteen times unrolling code - %1.0f\n",cycles,baseline/cycles,buffer[0]);

	//-----------------------------------------Timing 3
	//warm up	
		buffer[0]= temp;
		Unroll20(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		buffer[0]= temp;
		Unroll20(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through twenty times unrolling code - %1.0f\n",cycles,baseline/cycles,buffer[0]);

	//-----------------------------------------Timing 3
	//warm up	
		buffer[0]= temp;
		Unroll24(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		buffer[0]= temp;
		Unroll24(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through 24 times unrolling code - %1.0f\n",cycles,baseline/cycles,buffer[0]);

		buffer[0]= temp;
		Unroll28(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		buffer[0]= temp;
		Unroll28(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through 24 times unrolling code - %1.0f\n",cycles,baseline/cycles,buffer[0]);
	//-----------------------------------------Timing 3
	//warm up	
	free(buffer);
///	_mm_free(M);
//	_mm_free(y);
//	_mm_free(x);


	return 0;
}
