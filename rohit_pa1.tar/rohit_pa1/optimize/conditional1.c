#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define n 2000
#define m 3000

int main()
{
  double **a, **b, c, norm;
  int i, j, l;
  
  a = (double**)malloc(n*sizeof(double*));
  b = (double**)malloc(n*sizeof(double*));
	c = 13.0;
  for(i=0; i<n; i++)
    {
      a[i] = (double*)malloc(m*sizeof(double));
      for(j=0; j<n; j++) a[i][j] = drand48();
    
      b[i] = (double*)calloc(m, sizeof(double));
    }

  for(l=1; l<=30; l++)
    {
      for(i = 0;i<n ; i++)
	{

	for( j = 0;j < m; j+= 2)
		  b[i][j] = c*b[i][j]+a[i][j];

	for( j = 1;j < m; j+= 2)
		  b[i][j] = c*b[i][j]-a[i][j];

	}
    }

  norm = 0.0;

  for(i=0; i<n; i++)
    for(j=0; j<m; j++)
      norm = norm + fabs(b[i][j]*b[i][j]);
 
  printf("norm: %10.4e    Value: %10.4e\n",norm, b[10][10]);
}
