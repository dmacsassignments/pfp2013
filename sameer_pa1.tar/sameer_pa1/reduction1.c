#include <stdio.h>
#include <math.h>
#include<stdlib.h>
//#include "rdtsc.h"
#define N 2000
typedef float  data_t;
inline void Unroll1(data_t *y)
{
        float t1=0;
        int i;
        for (i = 0 ;i < N; i++)
        {
          t1 += y[i];
        }
        printf("%lf", t1);
}
int main()
{	
	data_t *buffer;
        //data_t * x[], * y[] ,* y_vec;
	//tsc_counter a, b;
	//double cycles, baseline;
        int i;
        //baseline = 0;
	//N is a define
	buffer = (data_t*)malloc(sizeof(data_t)*N); 
	for ( i = 0; i<N; i++){
			buffer[i] = rand()%1000;	
	}
			
     
           Unroll1(buffer);

	return 0;
}

