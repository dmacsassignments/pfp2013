#include <stdio.h>
#include <math.h>
#include<stdlib.h>
#include "rdtsc.h"
#define N 1000
#define NUM_RUNS 10
typedef float  data_t;
inline void Unroll2(data_t *y)
{
  register int n = (N+1)/2;
  data_t a,b,c; 
  a = b = c = 0;
     switch(N%2)
     {
        case 0: do { a += *y++;
        case 2:      b += *y++;
        case 1:      c += *y++;
                   }while(--n > 0);
     }
     a = a + b + c;
   //  printf("%f\n",a);
}
inline void Unroll3(data_t *y)
{
  register int n  = (N+2)/3;
  data_t a,b,c,d;
  a = b = c = d = 0;
     switch(N%3) 
     {
        case 0: do { a +=*y++;
        case 3:      b +=*y++;
        case 2:      c +=*y++;
        case 1:      d +=*y++;
                   }while(--n > 0);
     }
   a = a + b + c + d;
  // printf("%f\n",a);
}
inline void Unroll4(data_t *y)
{
  register int n = (N+3)/4;
  data_t a,b,c,d,e;
  a = b = c = d = e = 0;
     switch(N%4)
     {
        case 0: do { a += *y++;
        case 4:      b += *y++;
        case 3:      c += *y++;
        case 2:      d += *y++;
        case 1:      e += *y++;
                   }while(--n > 0);
     }
   a = a + b + c + d + e;
   //printf("%f\n",a);
}
inline void Unroll5(data_t *y)
{
  register int n = (N+4)/5;
  data_t a,b,c,d,e,f;
  a = b = c = d = e = f = 0;
     switch(N%5)
     {
        case 0: do { a += *y++;
        case 5:      b += *y++;
        case 4:      c += *y++;
        case 3:      d += *y++;
        case 2:      e += *y++;
        case 1:      f += *y++;
                   }while(--n > 0);
     }
     a = a + b + c +  d + e + f;
     //printf("%f\n",a);
}
inline void Unroll6(data_t *y)
{
  register int n = (N+5)/6;
  data_t a,b,c,d,e,f,g;
  a = b = c = d = e = f = g = 0;
     switch(N%6)
     {
        case 0: do { a += *y++;
        case 6:      b += *y++;
        case 5:      c += *y++;
        case 4:      d += *y++;
        case 3:      e += *y++;
        case 2:      f += *y++;
        case 1:      g += *y++;
                   }while(--n > 0);
     }
   a = a + b + c + d + e + f + g ;
   //printf("%f\n",a);
}
inline void Unroll7(data_t *y)
{
  register int n = (N+6)/7;
  data_t a,b,c,d,e,f,g,h;
  a = b = c = d = e = f = g = h = 0;
     switch(N%7)
     {
        case 0: do { a += *y++;
        case 7:      h += *y++;
        case 6:      b += *y++;
        case 5:      c += *y++;
        case 4:      d += *y++;
        case 3:      e += *y++;
        case 2:      f += *y++;
        case 1:      g += *y++;
                   }while(--n > 0);
     }
   a = a + b + c + d + e + f + g + h ;
   //printf("%f\n",a);
}
inline void Unroll8(data_t *y)
{
  register int n = (N+7)/8;
  data_t a,b,c,d,e,f,g,h,i;
  a = b = c = d = e = f = g = h = i = 0;
     switch(N%8)
     {
        case 0: do { a += *y++;
        case 8:      i += *y++;
        case 7:      h += *y++;
        case 6:      b += *y++;
        case 5:      c += *y++;
        case 4:      d += *y++;
        case 3:      e += *y++;
        case 2:      f += *y++;
        case 1:      g += *y++;
                   }while(--n > 0);
     }
   a = a + b + c + d + e + f + g + h + i;
  // printf("%f\n",a);
}

inline void Unroll9(data_t *y)
{
  register int n = (N+8)/9;
  data_t a,b,c,d,e,f,g,h,i,j;
  a = b = c = d = e = f = g = h = i = j = 0;
     switch(N%9)
     {
        case 0: do { a += *y++;
        case 9:      j += *y++;
        case 8:      i += *y++;
        case 7:      h += *y++;
        case 6:      b += *y++;
        case 5:      c += *y++;
        case 4:      d += *y++;
        case 3:      e += *y++;
        case 2:      f += *y++;
        case 1:      g += *y++;
                   }while(--n > 0);
     }
   a = a + b + c + d + e + f + g + h + i + j;
  // printf("%f\n",a);
}

/*
inline void Unroll2(data_t *y)
{
	float t1,t2;
        int i;
	for ( i = 0; i < N/2; i=i+2)
	{
	        t1 += y[i];
		t2 += y[i+1];
	}
        if(N%2 == 0)
           t1 = t1 + t2;
        else
           for(i = 0;i< N ;i++)
           t1 = t1 + t2 + 
inline void Unroll4(data_t *y)
{
        float t1,t2,t3,t4;
        int i;
        for (i = 0 ;i < N; i = i +4)
        {
          t1 += y[i];
          t2 += y[i+1];
          t3 += y[i+2];
          t4 += y[i+3];
        }
        t1 = t1 + t2 + t3 + t4;
}

inline void Unroll// typedef float data_t;
*/
int main()
{	
	data_t *buffer;
        //data_t * x[], * y[] ,* y_vec;
	tsc_counter a, b;
	double cycles, baseline;
        int i;
        baseline = 0;
	//N is a define
	buffer = (data_t*)malloc(sizeof(data_t)*N);
	//x = (float*)_mm_malloc(sizeof(float)*N,16);
	//y = (float*)_mm_malloc(sizeof(float)*N,16);
        //y_vec = (float*)_mm_malloc(sizeof(float)*N,16);

	//if (M == NULL || x == NULL || y == NULL || y_vec == NULL)
	   //	return 1;

	//init vars
	for ( i = 0; i<N; i++){
			buffer[i] = rand()%1000;	
	}
			
        for(i=0; i<NUM_RUNS;++i)
        {
           Unroll2(buffer);
        } 

	
	//-----------------------------------------Timing 1
	//warm up	

	//-----------------No Vec Warmup-------------------
	//lookup task b from the HW here
	//
	//State the Asm. Instructions used by the compiler as a comment here:
	//
	// <--- List of Instructions --->
	//-----------------------------------------Timing 1
	//warm up
	//	Unroll3(M,x,y);


	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		Unroll2(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through partially unrolled code - %1.0f\n",cycles,baseline/cycles,buffer[0]);


        for(i = 0;i<NUM_RUNS; ++i)
        {
              Unroll3(buffer);
        }

        CPUID(); RDTSC(a); CPUID(); RDTSC(b);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);

        RDTSC(a);
        for(i=0; i<NUM_RUNS; ++i)
        {
                Unroll3(buffer);
        }
        RDTSC(b);
        cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
        printf("%lf cycles -> Speedup: %2.2f x through vectorized code - %1.0f\n",cycles,baseline/cycles,buffer[0]);




	//-----------------------------------------Timing 2
	//warm up
	//	Unroll4(buffer); 
	for(i = 0;i<NUM_RUNS; ++i)
        {
              Unroll4(buffer);
        }

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		Unroll4(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through vectorized code - %1.0f\n",cycles,baseline/cycles,buffer[0]);
	
        for(i = 0;i<NUM_RUNS; ++i)
        {
              Unroll5(buffer);
        }

        CPUID(); RDTSC(a); CPUID(); RDTSC(b);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);

        RDTSC(a);
        for(i=0; i<NUM_RUNS; ++i)
        {
                Unroll5(buffer);
        }
        RDTSC(b);
        cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
        printf("%lf cycles -> Speedup: %2.2f x through vectorized code - %1.0f\n",cycles,baseline/cycles,buffer[0]);

	 for(i = 0;i<NUM_RUNS; ++i)
        {
              Unroll6(buffer);
        }

        CPUID(); RDTSC(a); CPUID(); RDTSC(b);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);

        RDTSC(a);
        for(i=0; i<NUM_RUNS; ++i)
        {
                Unroll6(buffer);
        }
        RDTSC(b);
        cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
        printf("%lf cycles -> Speedup: %2.2f x through vectorized code - %1.0f\n",cycles,baseline/cycles,buffer[0]);

         for(i = 0;i<NUM_RUNS; ++i)
        {
              Unroll7(buffer);
        }

        CPUID(); RDTSC(a); CPUID(); RDTSC(b);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);

        RDTSC(a);
        for(i=0; i<NUM_RUNS; ++i)
        {
                Unroll7(buffer);
        }
        RDTSC(b);
        cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
        printf("%lf cycles -> Speedup: %2.2f x through vectorized code - %1.0f\n",cycles,baseline/cycles,buffer[0]);

        for(i = 0;i<NUM_RUNS; ++i)
        {
              Unroll8(buffer);
        }

        CPUID(); RDTSC(a); CPUID(); RDTSC(b);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);

        RDTSC(a);
        for(i=0; i<NUM_RUNS; ++i)
        {
                Unroll8(buffer);
        }
        RDTSC(b);
        cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
        printf("%lf cycles -> Speedup: %2.2f x through vectorized code - %1.0f\n",cycles,baseline/cycles,buffer[0]);
      
         for(i = 0;i<NUM_RUNS; ++i)
        {
              Unroll9(buffer);
        }

        CPUID(); RDTSC(a); CPUID(); RDTSC(b);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);

        RDTSC(a);
        for(i=0; i<NUM_RUNS; ++i)
        {
                Unroll9(buffer);
        }
        RDTSC(b);
        cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
        printf("%lf cycles -> Speedup: %2.2f x through vectorized code - %1.0f\n",cycles,baseline/cycles,buffer[0]);


       //	_mm_free(M);
//	_mm_free(y);
//	_mm_free(x);
	 free(buffer);


	return 0;
}

