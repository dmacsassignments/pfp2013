#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define n 2000
#define m 3000

int main()
{
  double   c, norm;
  double *a,*b;
  int i, j, l;
  
  a = (double*)malloc(n*m*8);
  b = (double*)calloc(n*m,8);
  for(i=0; i<n; i++)
    {
       register int mi = m*i;
       for(j=0; j < n/2 ; j++) 
       {
         register int mij = mi + 2*j;
         a[mij] = drand48();                 
         a[mij + 1] = drand48();
       }
    }
 
  //c = 13.0;
 // int mdiv6 = m/6;
  for(i = 0;i < n ;i++)
  {
    //for(l = 0;l < 30;l++)
    //{
       /*for(j = 0;j < m - 2 ;j = j+4)
          {
             int mij = m*i + j;
             b[mij] = c * b[mij] + a[mij];
             b[mij+2] = c * b[mij+2] + a[mij+2];
          }
          for(j=1;j<m-2 ; j = j+4)
          {
             int mij = m*i + j;
             b[mij] = c * b[mij] + a[mij];
             b[mij+2] = c * b[mij+2]  - a[mij+2];
          }*/
        int mi = m*i;
      for(j = 0; j < 500; j++)
      {
        for(l = 0; l< 30;l++)
        {
         register int mij = mi + 6*j;
         register double *b1 = b+mij;
         register double *a1 = a+mij;
         *(b1) = 13 * *(b1) + *(a1);
         
         *(b1+1) = 13 * *(b1+1) - *(a1+1);
         *(b1+2) = 13* *(b1+2) + *(a1+2);
         *(b1+3) = 13 * *(b1+3) - *(a1+3);
         *(b1+4) = 13* *(b1+4) + *(a1+4);
         *(b1+5) = 13* *(b1+5) - *(a1+5);
         //*(b1+1) = 13 * *(b1+1) - *(a1+1);
        }
      //}
    
 
    }
          
   }
    
  
   
  norm = 0.0;
//  int mdiv3 = m/3;
  register double e , f , g ;
  e = f = g = 0.0;
  for(i=0; i<n; i++)
  {
    register int mi = m*i;
    for(j=0; j < 1000 ; j++)
      {
         int j3 = 3*j;
         register int mij = mi + j3;
        /* double a = b[mij]; 
         double d = b[mij + 1];
         double c = b[mij + 2];
         */
         e = e + b[mij++] * b[mij++];
         f = f + b[mij++] * b[mij++];
         g = g + b[mij++] * b[mij++];
      }
  }
  norm = e + f + g ;
  printf("norm: %10.4e    Value: %10.4e\n",norm, b[m*10 + 10]);
}
