#include <stdio.h>
#include <math.h>
#include<stdlib.h>
//#include "rdtsc.h"
#define N 2000
typedef float  data_t;
inline void Unroll4(data_t *y)
{
        float t1=0,t2=0,t3=0 ,t4 =0;
        int i;
        for (i = 0 ;i < N; i = i +4)
        {
          t1 += y[i];
          t2 += y[i+1];
          t3 += y[i+2];
          t4 += y[i+3];
        }
        t1 = t1 + t2 + t3 + t4;
        printf("%lf",t1);
}
int main()
{	
	data_t *buffer;
        //data_t * x[], * y[] ,* y_vec;
//	tsc_counter a, b;
//	double cycles, baseline;
        int i;
  //      baseline = 0;
	//N is a define
	buffer = (data_t*)malloc(sizeof(data_t)*N); 
	for ( i = 0; i<N; i++){
			buffer[i] = rand()%1000;	
	}
			
     
           Unroll4(buffer);

	return 0;
}

