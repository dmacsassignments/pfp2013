/*
 * comp.c - contains the function superslow that you need to optimize
 *
 *
 */

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


/* f(x, i, j) multiplies or divides by a sine expression depending
   on i + j being odd or even
*/
inline double f(double x, int i, int j)
{
    //double sinx = sin(M_PI/(i+1));
    if((i + j) & 0x1)
        return x / (1 + sin(M_PI/(i+1)));
    else
        return x * sin(M_PI/(i+1));
}

/* This is the function you need to optimize. It takes one
   square matrix as input
*/
void superslow(smat_t *a)
{
    int i, j;
    double x,x2;
    // i is the column of a we're computingx / (1 + sin(M_PI/(i+1))) right now
    for(i = 0; i < a->n; i++)
    {
        // j is the row of a we're computing right now
        for(j = 0; j < a->n; j++)
        {            
                // First, compute f(A) for the element of a in question
                x = get_elt(a, i, j);
                //x = ((i+j) & 0x1) ? x / sinx : x * sin(M_PI/(i + 1));
                x = f(x,i,j);
                // Add this to the value of a we're computing and store it
                x2 = get_elt(a, i, j);
			x = x * x2;
                set_elt(a, i, j, x);
            
        }
    }
} 

void superfast(smat_t *a)
{
   int i,j,n = a -> n;
   register double x,x2;
   //int n = a->n;
   register double* mat = a -> mat;  
   int ni = 0; 
   for(i = 0;i < n ;i++)
   {
      double sinx = 1 + sin(M_PI/(i+1));
      for(j = 0;j < n/6; j++)
      {
         register int j6 = 6 * j;
         register int inj = ni + j6;
         register double a = sinx - 1;
        // int ij6 = i + j6;
         x2 = x =  mat[inj];
         x = ((i+j6) & 0x1) ? x/sinx : x * a;
         x *=  x2;
         mat[inj] = x;

         inj++;
         x2 = x = mat[inj];
         x = ((i+j6 + 1) & 0x1) ? x/sinx : x * a;
         x *= x2;
         mat[inj] = x;

         inj++;
         x2 = x = mat[inj];
         x = ((i+j6 + 2) & 0x1) ? x/sinx : x * a;
         x *= x2;
         mat[inj] = x;
    
         inj++;
         x2 = x = mat[inj];
         x = ((i+j6 + 3) & 0x1) ? x/sinx : x * a;
         x *= x2;
         mat[inj] = x;

         inj++;
         x2 = x = mat[inj];
         x = ((i+j6 + 4) & 0x1) ? x/sinx : x * a;
         x *= x2;
         mat[inj] = x;

         inj++;
         x2 = x = mat[inj];
         x = ((i+j6 + 5) & 0x1) ? x/sinx : x * a;
         x *= x2;
         mat[inj] = x;
       


      }
      ni += n;
   }
}

void superfast1(smat_t *a)
{
   int i,j,n = a -> n;
   register double x,x2;
   register double* mat = a -> mat;
   for(i = 0;i < n ;i = i+2)
   {
       register double sinx = 1 + sin(M_PI/(i+1));
       register double a = sinx - 1;
       register int ni = n*i;
       for(j = 0;j < n - 6; j = j+12)
       { 
          register int inj = ni + j;
          x2 = x =  mat[inj];
          mat[inj] = x * (a * x2);
          //x *=  x2;
          //mat[inj] = x;
          inj = inj + 2;
          x2 = x =  mat[inj];
          mat[inj] = x * (a * x2);
          //x *=  x2;
          //mat[inj] = x;
          inj = inj + 2;
          x2 = x =  mat[inj];
          mat[inj] = x * (a * x2);
          //x *=  x2;
          //mat[inj] = x;
          inj = inj + 2;
          x2 = x =  mat[inj];
          mat[inj] = x * (a *x2);
         // x *=  x2;
          //mat[inj] = x;
          inj = inj + 2;
          x2 = x =  mat[inj];
          mat[inj] = x * (a*x2);
         // x *=  x2;
          //mat[inj] = x;
          inj = inj + 2;
          x2 = x =  mat[inj];
          mat[inj] = x * (a * x2);
          //x *=  x2;
          //mat[inj] = x;



       }
       
       for(j = 1 ; j < n - 6 ; j = j + 12)
       {
          register int inj = ni + j;
          x2 =  mat[inj];
          //x = x / sinx;
          //x *=  x2;
          mat[inj] = x2 * x2/sinx;
          inj = inj + 2;
          x2 = mat[inj];
          //x = x / sinx;
          //x *=  x2;
          mat[inj] = x2 * x2/sinx;
          inj = inj + 2;
          x2 = mat[inj];
          //x = x / sinx;
          //x *=  x2;
          mat[inj] = x2 * x2/sinx;
          inj = inj + 2;
          x2 = mat[inj];
          //x = x / sinx;
          //x *=  x2;
          mat[inj] = x2 * x2/sinx;
          inj = inj + 2;
          x2 =  mat[inj];
          //x = x / sinx;
          //x *=  x2;
          mat[inj] = x2 * x2/sinx;
          inj = inj + 2;
          x2 = mat[inj];
          //x = x / sinx;
          //x *=  x2;
          mat[inj] = x2 * x2/sinx;

           
          


       }
    

    }
    for(i = 1;i < n ;i = i+2)
    {
       register double sinx = 1 + sin(M_PI/(i+1));
       register double a = sinx - 1;
       register int ni = n*i;
       for(j = 1;j < n - 6; j = j+12)
       {
          register int inj = ni + j;
          x2 = x =  mat[inj];
          mat[inj] = x * (a*x2);
          //x *=  x2;
          //mat[inj] = x;
          inj = inj + 2;
          x2 = x =  mat[inj];
          mat[inj] = x * (a*x2);
          //x *=  x2;
          //mat[inj] = x;
          inj = inj + 2;
          x2 = x =  mat[inj];
          mat[inj] = x * (a*x2);
          //x *=  x2;
          //mat[inj] = x;
          inj = inj + 2;
          x2 = x =  mat[inj];
          mat[inj] = x * (a*x2);
          //x *=  x2;
          //mat[inj] = x;
          inj = inj + 2;
          x2 = x =  mat[inj];
          mat[inj] = x * (a*x2);
          //x *=  x2;
          //mat[inj] = x;
          inj = inj + 2;
          x2 = x =  mat[inj];
          mat[inj] = x * (a*x2);
          //x *=  x2;
          //mat[inj] = x;
          

         
       }
       for(j = 0;j < n - 6 ; j = j + 12)
       {
         register int inj = ni + j ;
         x2 =  mat[inj];
         //x = x / sinx;
         //x *= x2;
         mat[inj] = x2 * x2/sinx;
         inj = inj + 2;
         x2 =  mat[inj];
         //x = x / sinx;
         //x *= x2;
         mat[inj] = x2 * x2/sinx;
         inj = inj + 2;
         x2 = mat[inj];
         //x = x / sinx;
         //x *= x2;
         mat[inj] = x2 * x2/sinx;
         inj = inj + 2;
         x2 = mat[inj];
         //x = x / sinx;
         //x *= x2;
         mat[inj] = x2 * x2/sinx;
         inj = inj + 2;
         x2 = mat[inj];
         //x = x / sinx;
        // x *= x2;
         mat[inj] = x2 * x2/sinx;
         inj = inj + 2;
         x2 = x = mat[inj];
        // x = x / sinx;
         //x *= x2;
         mat[inj] = x2 * x2/sinx;


       }
  
   }
         

}
/* 
 * Called by the driver to register your functions
 * Use add_function(func, description) to add your own functions
 */
void register_functions()
{
    // Registers comp_superslow with the driver
    add_function(&superslow, "superslow: original function");
    add_function(&superfast, "superfast: sameer function");
    add_function(&superfast1,"superfast: sameer function");

	
	//Add your functions here
	//add_function(&superslow2, "superslow: Optimization X");
	
	
}
