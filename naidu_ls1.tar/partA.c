#include<stdio.h>
#include<stdlib.h>
#include<string.h>
char *strndup(char *src, int max)
{
  char *dest;
  int i;
   if (!src || max <= 0)
    return NULL;
  dest = malloc(max+1);
  for (i=0; i < max && src[i] != 0; i++)
     dest[i] = src[i];
  dest[i] = 0;
 return dest;
}
int main()
{
  char *str="hello world";
  int len = strlen(str);
  char *str1;
   str1=strndup(str,len);
   printf(" %s\n",str1);   
}
