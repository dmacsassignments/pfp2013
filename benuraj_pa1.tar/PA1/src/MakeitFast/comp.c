/*
 * comp.c - contains the function superslow that you need to optimize
 *
 *
 */

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


/* f(x, i, j) multiplies or divides by a sine expression depending
   on i + j being odd or even
*/
double f(double x, int i, int j)
{
    if((i + j) & 0x1)
        return x / (1 + sin(M_PI/(i+1)));
    else
        return x * sin(M_PI/(i+1));
}

/* This is the function you need to optimize. It takes one
   square matrix as input
*/
void superslow(smat_t *a)
{
    int i, j;
    double x,x2;

    // i is the column of a we're computing right now
    for(i = 0; i < a->n; i++)
    {
        // j is the row of a we're computing right now
        for(j = 0; j < a->n; j++)
        {            
                // First, compute f(A) for the element of a in question
			x = get_elt(a, i, j);
                x = f(x, i, j);
                
                // Add this to the value of a we're computing and store it
                x2 = get_elt(a, i, j);
			x = x * x2;
                set_elt(a, i, j, x);
            
        }
    }
}
//Optimization1

void superslow1(smat_t *a)
{
    int i, j;
    double x,x2;
    
    int n=a->n;
    double *matrix = a->mat;

    // i is the column of a we're computing right now
    for(i = 0; i < n; i++)
    {
        // j is the row of a we're computing right now
        for(j = 0; j < n; j++)
        {            
                // First, compute f(A) for the element of a in question
			x = get_elt(a, i, j);
                x = f(x, i, j);
                
                // Add this to the value of a we're computing and store it
                x2 = get_elt(a, i, j);
			x = x * x2;
                set_elt(a, i, j, x);
            
        }
    }
}

//Optiomization2

void superslow2(smat_t *a)
{
    int i, j;
    double x,x2;
    
    int n=a->n;
    double *matrix = a->mat;

    // i is the column of a we're computing right now
    for(i = 0; i < n; i++)
    {
        // j is the row of a we're computing right now
        
	for(j = 0; j < n; j++)
        {            
                // First, compute f(A) for the element of a in question
			//x = get_elt(a, i, j);
		x=matrix[i*n + j];
                x = f(x, i, j);
                
                // Add this to the value of a we're computing and store it
                x2 = matrix[i*n + j];
			x = x * x2;
                set_elt(a, i, j, x);
            
        }
    }
}

//Optimized3
void superslow3(smat_t *a)
{
    int i, j, ii;
    double x,x2;
    
    int n=a->n;
    double *matrix = a->mat;

    // i is the column of a we're computing right now
    for(i = ii = 0; i < n; i++, ii += n)
    {
	double even = sin(M_PI/(i+1));
	double odd = 1.0/(1.0 + even);
        // j is the row of a we're computing right now
        
	for(j = 0; j < n; j++)
        {            
		x=matrix[ii + j];
    		
		if((i + j) & 0x1)
			x *= x * odd;
		
		else
			x *= x * even;
                
                
                
		//x2=matrix[ii + j];
		//x = x * x2;
                
		matrix[ii + j] = x;
            
        }
    }
}
//Optimised4

void superslow4(smat_t *a)
{
    register int i,  ii,j1,j2;
    register double xO,xE;
    
    
   const int n=a->n;
   register  double *matrix = a->mat;

    // i is the column of a we're computing right now
    for(i = ii = 0; i < n; i++, ii += n)
    {
	register double even = sin(M_PI/(i+1));
	register double odd = 1.0/(1.0 + even);
        // j is the row of a we're computing right now
        
	for(j1 =(i & 0x1),j2=(j1 ^ 0x1); j1 < n; j1 += 2,j2 += 2)
        {       
		xE=matrix[ii + j1];
		xO=matrix[ii + j2];
    		
	/*	if((i + j) & 0x1)
			x= x * odd;
		
		else
			x= x * even;
        */      
		xO *= xO * odd;
		xE *= xE * even;
                
                
		//x2=matrix[ii + j];
		//x = x * x2;
                
		matrix[ii + j1] = xE;
		matrix[ii + j2] = xO;
            
        }
    }
}



/* 
 * Called by the driver to register your functions
 * Use add_function(func, description) to add your own functions
 */
void register_functions()
{
    // Registers comp_superslow with the driver
    add_function(&superslow, "superslow: original function");
    add_function(&superslow1, "Optimized1");
    add_function(&superslow2, "Optimized2");
    add_function(&superslow3, "Optimized3");
    add_function(&superslow4, "Optimized4");
	
	//Add your functions here
	//add_function(&superslow2, "superslow: Optimization X");
	
	
}
