#include <stdio.h>
#include <math.h>
#include "rdtsc.h"
#define N 1024
#define NUM_RUNS 30

typedef int data_t;
data_t Unroll0(data_t *y){
	int i;
	data_t sum = 0;
	for(i=0;i<N;i++)
		sum += y[i];
	printf("Sum %d\n",sum);
	return sum;
}

data_t Unroll2(data_t *y)
{
	data_t temp0=0;
	data_t temp1=0;
	data_t temp2=0;
	data_t sum = 0;
	int i;

	int lim =  N-N%2;
	for (i = 0; i < lim; i=i+2)
	{
		temp0 +=y[i];
		temp1 +=y[i+1];
	}
	for(;i<N;i++)
		temp2 += y[i];
	sum = temp0 + temp1 + temp2;
	printf("Sum %d\n",sum);
	return sum;
}



data_t Unroll3(data_t *y)
{
	data_t temp0=0;
	data_t temp1=0;
	data_t temp2=0;
	data_t temp3=0;
	data_t sum;
	int i;
	int lim = N-N%3;
	for (i = 0; i < lim; i=i+3)
	{
		temp0 += y[i];
		temp1 += y[i+1];
		temp2 += y[i+2];
	}
	for(;i<N;i++)
		temp3 += y[i];
//	printf(" m hea\n");
	sum = temp0 + temp1+temp2 + temp3;
	printf("Sum %d\n",sum);
	return sum;
}

data_t Unroll4(data_t *y)
{
	data_t temp0=0;
	data_t temp1=0;
	data_t temp2=0;
	data_t temp3=0;
	data_t temp4=0;
 	data_t sum = 0;
	int i; 
	int lim = N-N%4;
	for (i = 0; i < lim; i=i+4)
	{
		temp0 += y[i];
		temp1 += y[i+1];
		temp2 += y[i+2];
		temp3 += y[i+3];

	}
	for(;i<N;i++)
		temp4 += y[i];
	
	sum = temp0 + temp1 + temp2 + temp3 + temp4;
	printf("Sum %d\n",sum);
	return sum;
}

data_t Unroll5(data_t *y)
{
	data_t temp0=0;
	data_t temp1=0;
	data_t temp2=0;
	data_t temp3=0;
	data_t temp4=0;
	data_t temp5=0;
 	data_t sum = 0;
	int i; 
	int lim = N-N%5;
	for (i = 0; i < lim; i=i+5)
	{
		temp0 += y[i];
		temp1 += y[i+1];
		temp2 += y[i+2];
		temp3 += y[i+3];
		temp4 += y[i+4];

	}
	for(;i<N;i++)
		temp5 += y[i];
	
	sum = temp0 + temp1 + temp2 + temp3 + temp4 + temp5;
	printf("Sum %d\n",sum);
	return sum;
}

int main()
{	
	data_t * buffer;
	tsc_counter a, b;
	double cycles, baseline;
	data_t sum;
	int i;

	//N is a define
	buffer = (data_t*)_mm_malloc(sizeof(float)*N*N,16);
	//x = (float*)_mm_malloc(sizeof(float)*N,16);
	//y = (float*)_mm_malloc(sizeof(float)*N,16);
	//y_vec = (float*)_mm_malloc(sizeof(float)*N,16);

//	if (M == NULL || x == NULL || y == NULL || y_vec == NULL)
//		return 1;

	//init vars
	for (i = 0; i<N; i++){
			buffer[i] = rand();	
	}
			
	Unroll0(buffer);
	
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		Unroll0(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	//printf("%lf cycles -> Speedup: %2.2f x through partially unrolled code - %1.0f\n",cycles,baseline/cycles,y[0]);
	printf("%lf cycles -> Speedup\n",cycles);

	
	//-----------------------------------------Timing 1
	//warm up	

	//-----------------No Vec Warmup-------------------
	//lookup task b from the HW here
	//
	//State the Asm. Instructions used by the compiler as a comment here:
	//
	// <--- List of Instructions --->
	//-----------------------------------------Timing 1
	//warm up
		Unroll2(buffer);


	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		Unroll2(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	//printf("%lf cycles -> Speedup: %2.2f x through partially unrolled code - %1.0f\n",cycles,baseline/cycles,y[0]);
	printf("%lf cycles -> Speedup\n",cycles);


	//-----------------------------------------Timing 2
	//warm up
	Unroll3(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		Unroll3(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	//printf("%lf cycles -> Speedup: %2.2f x through vectorized code - %1.0f\n",cycles,baseline/cycles,y_vec[0]);
	printf("%lf cycles -> Speedup\n",cycles);
	
	//.................................................Timing 3
	//warm up
	Unroll4(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		Unroll4(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	//printf("%lf cycles -> Speedup: %2.2f x through vectorized code - %1.0f\n",cycles,baseline/cycles,y_vec[0]);
	printf("%lf cycles -> Speedup\n",cycles);
	
	Unroll5(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		Unroll5(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	//printf("%lf cycles -> Speedup: %2.2f x through vectorized code - %1.0f\n",cycles,baseline/cycles,y_vec[0]);
	printf("%lf cycles -> Speedup\n",cycles);
	
	

	_mm_free(buffer);
//	_mm_free(y);
//	_mm_free(x);


	return 0;
}

