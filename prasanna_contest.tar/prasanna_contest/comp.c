/*
* comp.c - contains the function superslow that you need to optimize
*
*
*/

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


//
//
//
/* f(x1,x2, i, j) rotates the input vector
*/
double f(double x1, double x2, double* y1, double * y2, int i, int j)
{
	double m[2][2];	

	if (i %4 == 0)
	{
		m[0][0] = cos(i);
		m[0][1] = sin(i);
		m[1][0] = -sin(i);
		m[1][1] = cos(i);
	}
	else
	{
		m[0][0] = cos(-i);
		m[0][1] = sin(-i);
		m[1][0] = -sin(-i);
		m[1][1] = cos(-i);

	}

	*y1 = m[0][0] * x1 + m[0][1]* x2;
	*y2 = m[1][0] * x1 + m[1][1]* x2;
}

/*VERSION 4*/
void superslow4(smat_t  *a)
{

	register int i, j,n=a->n;
	register double x1,x2,x3,x4,x5,x6,x7,x8;
	register double* p = a->mat;
        register double c1,s1,c2,s2;
        register double *p1;

	// j is the column of a we're computing right now
	for(i = 0; i < n; i=i+4)
	{
                         c1 = cos(i);s1 = sin(i);
                         c2 = cos(-(i+2));s2 = sin(-(i+2));    
		// i is the row of a we're computing right now
	        for(j = 0; j < n; j=j+4)        
		{           
	                
			p1 = p+i*n+j;
	                x1 =  *(p1);
	                x2 =  *(p1+2*n);
	                x3 =  *(p1+1);
	                x4 =  *(p1+2*n+1);
	                x5 =  *(p1+2);
	                x6 =  *(p1+2*n+2);
	                x7 =  *(p1+3);
	                x8 =  *(p1+2*n+3);
	                
			*(p1) +=  c1* x1  +  s1* *(p1+n);
			*(p1+n) += -s1* x1 + c1*  *(p1+n);
			*(p1+2*n) +=   c2*x2 + s2* *(p1+3*n);
			*(p1+3*n) +=   -s2*x2 + c2* *(p1+3*n);
			p1 ++;
	                *(p1) +=  c1* x3  +  s1* *(p1+n);
	                *(p1+n) += -s1* x3 + c1*  *(p1+n);
	                *(p1+2*n) +=   c2*x4 + s2* *(p1+3*n);
	                *(p1+3*n) +=   -s2*x4 + c2* *(p1+3*n);
			p1 ++;
	                *(p1) +=  c1* x5  +  s1* *(p1+n);
	                *(p1+n) += -s1* x5 + c1*  *(p1+n);
	                *(p1+2*n) +=   c2*x6 + s2* *(p1+3*n);
	                *(p1+3*n) +=   -s2*x6 + c2* *(p1+3*n);
			p1 ++;
	                *(p1) +=  c1* x7  +  s1* *(p1+n);
	                *(p1+n) += -s1* x7 + c1*  *(p1+n);
	                *(p1+2*n) +=   c2*x8 + s2* *(p1+3*n);
	                *(p1+3*n) +=   -s2*x8 + c2* *(p1+3*n);
		}
	}



}


/*VERSION 3*/
void superslow3(smat_t *a)
{

	register int i, j,n=a->n;
	register double x1,x2;
	register double* p = a->mat;
        register double c1,s1,c2,s2;
        register double *p1;

	for(i=0; i < n; i=i+4)
	{
                         c1 = cos(i);s1 = sin(i);
                         c2 = cos(-(i+2));s2 = sin(-(i+2));    
		// i is the row of a we're computing right now
		for(j = 0; j < n; j=j+1)        
		{           
	                p1 = p+i*n+j;
			x1 =  *(p1);
	                x2 =  *(p1+2*n);
	                *(p1) +=  c1* x1  +  s1* *(p1+n);
	                *(p1+n) += -s1* x1 + c1*  *(p1+n);
	                *(p1+2*n) +=   c2*x2 + s2* *(p1+3*n);
	                *(p1+3*n) +=   -s2*x2 + c2* *(p1+3*n);

		}
	}



}



/*VERSION 2*/
void superslow2(smat_t *a)
{
	register int i, j,n=a->n;
	register double x1,x2;
	register double* p = a->mat;
        register double c1,s1;

	// j is the column of a we're computing right now
	for(j = 0; j+7 < n; j=j+8)
	{

		// i is the row of a we're computing right now
		for(i = 0; i < n; i=i+4)        
		{            
			// First, compute f(A) for the element of a in question
			x1 =  *(p+i*n+j);
			x2 =  *(p+(i+2)*n+j);
                         c1 = cos(i);s1 = sin(i);


			// Add this to the value of a we're computing and store it                
			
			*(p+i*n+j) +=  c1* x1  +  s1* *(p+(i+1)*n+j);
			*(p+(i+1)*n+j) += -s1* x1 + c1*  *(p+(i+1)*n+j);
			
			*(p+(i+2)*n+j) +=   cos(-(i+2))*x2 + sin(-(i+2))* *(p+(i+3)*n+j);
			*(p+(i+3)*n+j) +=   -sin(-(i+2))*x2 + cos(-(i+2))* *(p+(i+3)*n+j);
			
			x1 =  *(p+i*n+j+1);
			x2 =  *(p+(i+2)*n+j+1);
			*(p+i*n+j+1) +=  c1* x1  +  s1* *(p+(i+1)*n+j+1);
			*(p+(i+1)*n+j+1) += -s1* x1 + c1*  *(p+(i+1)*n+j+1);
			
			*(p+(i+2)*n+j+1) +=   cos(-(i+2))*x2 + sin(-(i+2))* *(p+(i+3)*n+j+1);
			*(p+(i+3)*n+j+1) +=   -sin(-(i+2))*x2 + cos(-(i+2))* *(p+(i+3)*n+j+1);


			x1 =  *(p+i*n+j+2);
			x2 =  *(p+(i+2)*n+j+2);

			*(p+i*n+j+2) +=  c1* x1  +  s1* *(p+(i+1)*n+j+2);
			*(p+(i+1)*n+j+2) += -s1* x1 + c1*  *(p+(i+1)*n+j+2);
			
			*(p+(i+2)*n+j+2) +=   cos(-(i+2))*x2 + sin(-(i+2))* *(p+(i+3)*n+j+2);
			*(p+(i+3)*n+j+2) +=   -sin(-(i+2))*x2 + cos(-(i+2))* *(p+(i+3)*n+j+2);



			x1 =  *(p+i*n+j+3);
			x2 =  *(p+(i+2)*n+j+3);
			*(p+i*n+j+3) +=  c1* x1  +  s1* *(p+(i+1)*n+j+3);
			*(p+(i+1)*n+j+3) += -s1* x1 + c1*  *(p+(i+1)*n+j+3);
			
			*(p+(i+2)*n+j+3) +=   cos(-(i+2))*x2 + sin(-(i+2))* *(p+(i+3)*n+j+3);
			*(p+(i+3)*n+j+3) +=   -sin(-(i+2))*x2 + cos(-(i+2))* *(p+(i+3)*n+j+3);


			x1 =  *(p+i*n+j+4);
			x2 =  *(p+(i+2)*n+j+4);

			*(p+i*n+j+4) +=  c1* x1  +  s1* *(p+(i+1)*n+j+4);
			*(p+(i+1)*n+j+4) += -s1* x1 + c1*  *(p+(i+1)*n+j+4);
			
			*(p+(i+2)*n+j+4) +=   cos(-(i+2))*x2 + sin(-(i+2))* *(p+(i+3)*n+j+4);
			*(p+(i+3)*n+j+4) +=   -sin(-(i+2))*x2 + cos(-(i+2))* *(p+(i+3)*n+j+4);


			x1 =  *(p+i*n+j+5);
			x2 =  *(p+(i+2)*n+j+5);


                        *(p+i*n+j+5) +=  c1* x1  +  s1* *(p+(i+1)*n+j+5);
			*(p+(i+1)*n+j+5) += -s1* x1 + c1*  *(p+(i+1)*n+j+5);
			
			*(p+(i+2)*n+j+5) +=   cos(-(i+2))*x2 + sin(-(i+2))* *(p+(i+3)*n+j+5);
			*(p+(i+3)*n+j+5) +=   -sin(-(i+2))*x2 + cos(-(i+2))* *(p+(i+3)*n+j+5);


			x1 =  *(p+i*n+j+6);
			x2 =  *(p+(i+2)*n+j+6);



			*(p+i*n+j+6) +=  c1* x1  +  s1* *(p+(i+1)*n+j+6);
			*(p+(i+1)*n+j+6) += -s1* x1 + c1*  *(p+(i+1)*n+j+6);
			
			*(p+(i+2)*n+j+6) +=   cos(-(i+2))*x2 + sin(-(i+2))* *(p+(i+3)*n+j+6);
			*(p+(i+3)*n+j+6) +=   -sin(-(i+2))*x2 + cos(-(i+2))* *(p+(i+3)*n+j+6);



			x1 =  *(p+i*n+j+7);
			x2 =  *(p+(i+2)*n+j+7);


			*(p+i*n+j+7) +=  c1* x1  +  s1* *(p+(i+1)*n+j+7);
			*(p+(i+1)*n+j+7) += -s1* x1 + c1*  *(p+(i+1)*n+j+7);
			
			*(p+(i+2)*n+j+7) +=   cos(-(i+2))*x2 + sin(-(i+2))* *(p+(i+3)*n+j+7);
			*(p+(i+3)*n+j+7) +=   -sin(-(i+2))*x2 + cos(-(i+2))* *(p+(i+3)*n+j+7);

   }

}


	for(; j < n; j=j+4)
	{
         for(i = 0; i < n; i=i+4)        
         {
			x1 =  *(p+i*n+j);
			x2 =  *(p+(i+2)*n+j);
			


	 
			*(p+i*n+j) +=  cos(i)* x1  +  sin(i)* *(p+(i+1)*n+j);
			*(p+(i+1)*n+j) += -sin(i)* x1 + cos(i)*  *(p+(i+1)*n+j);
			
			*(p+(i+2)*n+j) +=   cos(-(i+2))*x2 + sin(-(i+2))* *(p+(i+3)*n+j);
			*(p+(i+3)*n+j) +=   -sin(-(i+2))*x2 + cos(-(i+2))* *(p+(i+3)*n+j);
			
			x1 =  *(p+i*n+j+1);
			x2 =  *(p+(i+2)*n+j+1);
			*(p+i*n+j+1) +=  cos(i)* x1  +  sin(i)* *(p+(i+1)*n+j+1);
			*(p+(i+1)*n+j+1) += -sin(i)* x1 + cos(i)*  *(p+(i+1)*n+j+1);
			
			*(p+(i+2)*n+j+1) +=   cos(-(i+2))*x2 + sin(-(i+2))* *(p+(i+3)*n+j+1);
			*(p+(i+3)*n+j+1) +=   -sin(-(i+2))*x2 + cos(-(i+2))* *(p+(i+3)*n+j+1);
	
			x1 =  *(p+i*n+j+2);
			x2 =  *(p+(i+2)*n+j+2);
			*(p+i*n+j+2) +=  cos(i)* x1  +  sin(i)* *(p+(i+1)*n+j+2);
			*(p+(i+1)*n+j+2) += -sin(i)* x1 + cos(i)*  *(p+(i+1)*n+j+2);
			
			*(p+(i+2)*n+j+2) +=   cos(-(i+2))*x2 + sin(-(i+2))* *(p+(i+3)*n+j+2);
			*(p+(i+3)*n+j+2) +=   -sin(-(i+2))*x2 + cos(-(i+2))* *(p+(i+3)*n+j+2);

			x1 =  *(p+i*n+j+3);
			x2 =  *(p+(i+2)*n+j+3);
			*(p+i*n+j+3) +=  cos(i)* x1  +  sin(i)* *(p+(i+1)*n+j+3);
			*(p+(i+1)*n+j+3) += -sin(i)* x1 + cos(i)*  *(p+(i+1)*n+j+3);
			
			*(p+(i+2)*n+j+3) +=   cos(-(i+2))*x2 + sin(-(i+2))* *(p+(i+3)*n+j+3);
			*(p+(i+3)*n+j+3) +=   -sin(-(i+2))*x2 + cos(-(i+2))* *(p+(i+3)*n+j+3);

	 
	 
	 }
	 }

}


/*VERSION 1*/
void superslow1(smat_t *a)
{
	register int i, j,n=a->n;
	register double x1,x2;
	double y1,y2;


	// j is the column of a we're computing right now
	for(j = 0; j < n; j++)
	{

		// i is the row of a we're computing right now
		for(i = 0; i < n; i=i+2)        
		{            
			// First, compute f(A) for the element of a in question
			x1 =  a->mat[i*n+j];
			x2 =  a->mat[(i+1)*n+j];
			f(x1,x2,&y1,&y2, i, j);

			// Add this to the value of a we're computing and store it                
			// *(p+i*n+j) = x1+y1;
			// *(p+(i+1)*n+j) = x2+y2;
			a->mat[i*n+j] = x1+y1;
			a->mat[(i+1)*n+j] = x2+y2;
		}
	}
}


/* This is the function you need to optimize. It takes one
square matrix as input
*/
void superslow(smat_t *a)
{
	int i, j;
	double x1,x2,y1,y2;
	double sum1, sum2;


	// j is the column of a we're computing right now
	for(j = 0; j < a->n; j++)
	{

		// i is the row of a we're computing right now
		for(i = 0; i < a->n; i=i+2)        
		{            
			// First, compute f(A) for the element of a in question
			x1 = get_elt(a,i,j);
			x2 = get_elt(a,i+1,j);
			f(x1,x2,&y1,&y2, i, j);

			// Add this to the value of a we're computing and store it                
			sum1 = get_elt(a, i, j) + y1;
			sum2 = get_elt(a, i+1, j) + y2;
			set_elt(a, i, j, sum1);
			set_elt(a, i+1, j, sum2);            
		}
	}
}





/* 
* Called by the driver to register your functions
* Use add_function(func, description) to add your own functions
*/
void register_functions()
{
	// Registers comp_superslow with the driver
add_function(&superslow, "superslow: original function");
//	add_function(&superslow1, "VERSION 1");
//	add_function(&superslow2, "VERSION 2");
	add_function(&superslow4, "\n\nVERSION 4");
	add_function(&superslow3, "\n\n\nVERSION 3");
//	add_function(&fast, "fast: optimized version 1");
	//Add your functions here
	//add_function(&superslow2, "superslow: Optimization X");


}
