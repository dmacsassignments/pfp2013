/*
* comp.c - contains the function superslow that you need to optimize
*
*
*/

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


/* f(x1,x2, i, j) rotates the input vector
*/
double f(double x1, double x2, double* y1, double * y2, int i, int j)
{
	double m[2][2];	

	if (i %4 == 0)
	{
		m[0][0] = cos(i);
		m[0][1] = sin(i);
		m[1][0] = -sin(i);
		m[1][1] = cos(i);
	}
	else
	{
		m[0][0] = cos(-i);
		m[0][1] = sin(-i);
		m[1][0] = -sin(-i);
		m[1][1] = cos(-i);

	}

	*y1 = m[0][0] * x1 + m[0][1]* x2;
	*y2 = m[1][0] * x1 + m[1][1]* x2;
}

/* This is the function you need to optimize. It takes one
square matrix as input
*/
void superslow(smat_t *a)
{
	int i, j;
	double x1,x2,y1,y2;
	double sum1, sum2;


	// j is the column of a we're computing right now
	for(j = 0; j < a->n; j++)
	{

	//	 i is the row of a we're computing right now
		for(i = 0; i < a->n; i=i+2)        
		{            
			// First, compute f(A) for the element of a in question
			x1 = get_elt(a,i,j);
			x2 = get_elt(a,i+1,j);
			f(x1,x2,&y1,&y2, i, j);

			// Add this to the value of a we're computing and store it                
			sum1 = get_elt(a, i, j) + y1;
			sum2 = get_elt(a, i+1, j) + y2;
			set_elt(a, i, j, sum1);
			set_elt(a, i+1, j, sum2);            
		}
	}
}


void Better(smat_t *a)
{
        int i, j;
        double x1,x2,y1,y2,reg1,reg2;
        double sum1, sum2;
	int max = a->n;
	double *mat = a->mat;
   
        for(j = 0; j < max; j++)
        {

         
                for(i = 0; i < max; i=i+2)
                {       
		 reg1 =  mat[i * max + j];
		 reg2 =  mat[(i+1) * max + j];
		  x1 = reg1;
		  x2 = reg2;
                        f(x1,x2,&y1,&y2, i, j);
                        mat[i * max + j] =reg1 + y1;
                        mat[(i+1) * max + j] = reg2 + y2;
                }
        }
}

void Better_ok(smat_t *a)
{
        int i, j;
        double x1,x2,y1,y2,reg1,reg2,reg3,reg4,reg5,reg6;
        double sum1, sum2;
        int max = a->n;
        double *mat = a->mat;

        for(j = 0; j < max; j++)
        {
                for(i = 0; i < max; i+=2)
                {
                 reg1 =  mat[i * max + j];
                 reg2 =  mat[(i+1) * max + j];
		 double m[2][2];
	        if (i %4 == 0)
        	{
                	m[0][0] = cos(i);
	                m[0][1] = sin(i);
        	        m[1][0]= -sin(i);
   	            	m[1][1] = cos(i);
        	}
	        else
        	{
                	m[0][0] = cos(-i);
	                m[0][1] = sin(-i);
        	        m[1][0] = -sin(-i);
                	m[1][1]= cos(-i);

        	}
	        y1 = m[0][0] * reg1 + m[0][1]* reg2;
        	y2 = m[1][0] * reg1 + m[1][1]* reg2;

                        mat[i * max + j] =reg1 + y1;
                         mat[(i+1) * max + j] = reg2 + y2;
                }
        }
}


void Better_ok_1(smat_t *a)
{
        int i, j;
	register  double x1,x2,y1,y2,reg1,reg2,reg3,reg4,reg5,reg6;
        double sum1, sum2;
        int max = a->n;
        double *mat = a->mat;

        for(i= 0; i< max; i+=2)
        {
                for(j = 0; j < max; j++)
                {
                 reg1 =  mat[i * max + j];
                 reg2 =  mat[(i+1) * max + j];
                 double m[2];
                if (i %4 == 0)
                {
    //                    m[0][0] = cos(i);
                       reg3 = sin(i);
                        reg4= -sin(i);
  //                      m[1][1] = cos(i);
                }
                else
                {
//                        m[0][0] = cos(-i);
                        reg3 = sin(-i);
                        reg4 = -sin(-i);

                }
                y1 = cos(i) * reg1 + reg3* reg2;
                y2 = reg4 * reg1 + cos(i)* reg2;

                        mat[i * max + j] =reg1 + y1;
                         mat[(i+1) * max + j] = reg2 + y2;
                }
        }
}

void Better_ok_2(smat_t *a)
{
        int i, j;
        double x1,x2,y1,y2,reg1,reg2;
	int reg3,reg4,reg5,reg6;
        double sum1, sum2,m[2][2];
        int max = a->n;
        double *mat = a->mat;

        for(i = 0; i < max; i+=2)
        {
	 reg3 = i * max;
	 reg4 = (i+1)*max;
	  if (i %4 == 0)
                {
                        m[0][0] = cos(i);
                        m[0][1] = sin(i);
                        m[1][0]= -sin(i);
                        m[1][1] = cos(i);
                }
                else
                {
                        m[0][0] = cos(-i);
                        m[0][1] = sin(-i);
                        m[1][0] = -sin(-i);
                        m[1][1]= cos(-i);

                }

                for(j = 0; j < max; j++)
                {
                 reg1 =  mat[reg3 + j];
                 reg2 =  mat[reg4 + j];
                y1 = m[0][0] * reg1 + m[0][1]* reg2;
                y2 = m[1][0] * reg1 + m[1][1]* reg2;

                        mat[reg3 + j] =reg1 + y1;
		         mat[reg4 + j] = reg2 + y2;
                }
        }
}

void super(smat_t *a)
{
        int i, j;
        double x1,x2,y1,y2,y3,y4,reg1,reg2,reg5,reg6;
        int reg3,reg4;
        double sum1, sum2,m[2][2];
        int max = a->n;
        double *mat = a->mat;

        for(i = 0; i < max; i+=2)
        {
         reg3 = i * max;
         reg4 = (i+1)*max;
          if (i %4 == 0)
                {
                        m[0][0] = cos(i);
                        m[0][1] = sin(i);
                        m[1][0]= -sin(i);
                        m[1][1] = cos(i);
                }
                else
                {
                        m[0][0] = cos(-i);
                        m[0][1] = sin(-i);
                        m[1][0] = -sin(-i);
                        m[1][1]= cos(-i);
                }
                for(j = 0; j < max; j+=2)
                {
                 reg1 =  mat[reg3 + j];
		 reg5 =  mat[reg3 + (j+1)];
                 reg2 =  mat[reg4 + j];
		 reg6 =  mat[reg4 + (j+1)];
                y1 = m[0][0] * reg1 + m[0][1]* reg2;
		y3 = m[0][0] * reg5 + m[0][1]* reg6;
   	        y2 = m[1][0] * reg1 + m[1][1]* reg2;
		y4 =  m[1][0] * reg5 + m[1][1]* reg6;

                        mat[reg3 + j] =reg1 + y1;
			mat[reg3 + (j+1)] = reg5 + y3;
                        mat[reg4 + j] = reg2 + y2;
			mat[reg4 + (j+1)] = reg6 + y4;
                }
        }
}
void kirru_super(smat_t *a)
{
        int i, j;
        double x1,x2,y1,y2,y3,y4,reg1,reg2,reg5,reg6;
        int reg3,reg4;
        double sum1, sum2,m[4],sinreg,cosreg;
        int max = a->n;
        double *mat = a->mat;

        for(i = 0; i < max; i+=2)
        {
         reg3 = i * max;
         reg4 = (i+1)*max;
	 cosreg = cos(i); sinreg = sin(i);
          if (i %4 == 0)
                {
                        m[0] = cosreg;
                        m[1] = sinreg;
                        m[2]= -sinreg;
                        m[3] = cosreg;
                }
                else
                {
                        m[0] = cosreg;
                        m[1] =-sinreg;
                        m[2] = sinreg;
                        m[3] = cosreg;
                }
                for(j = 0; j < max; j+=2)
                {
                 reg1 =  mat[reg3 + j];
                 reg5 =  mat[reg3 + (j+1)];
                 reg2 =  mat[reg4 + j];
                 reg6 =  mat[reg4 + (j+1)];

                 mat[reg3 + j] =reg1*(1 + m[0]) + m[1]* reg2;
                 mat[reg3 + (j+1)] = reg5*(1 +  m[0]) + m[1]* reg6;
                 mat[reg4 + j] =  m[2] * reg1 +reg2*(1+ m[3]);
                 mat[reg4 + (j+1)] =   m[2] * reg5 +reg6 *(1+ m[3]);
                }
        }
}
void kirru_superfast(smat_t *a)
{
        int i, j;
        double x1,x2,y1,y2,y3,y4,reg1,reg2,reg5,reg6;
        int reg3,reg4;
        double sum1, sum2,sinreg,cosreg,ss,sss;
        int max = a->n;
        double *mat = a->mat;

        for(i = 0; i < max; i+=2)
        {
         reg3 = i * max;
         reg4 = (i+1)*max;
         cosreg = cos(i); sinreg = sin(i);
          if (i %4 == 0)
                {
                        ss = sinreg;
                        sss= -sinreg;
                }
                else
                {
                        ss =-sinreg;
                        sss = sinreg;
                }
                for(j = 0; j < max; j+=2)
                {
                 reg1 =  mat[reg3 + j];
                 reg5 =  mat[reg3 + (j+1)];
                 reg2 =  mat[reg4 + j];
                 reg6 =  mat[reg4 + (j+1)];

                 mat[reg3 + j] =reg1*(1 + cosreg) + ss* reg2;
                 mat[reg3 + (j+1)] = reg5*(1 + cosreg ) + ss* reg6;
                 mat[reg4 + j] =  sss * reg1 +reg2*(1+ cosreg);
                 mat[reg4 + (j+1)] =  sss * reg5 +reg6 *(1+ cosreg);
                }
        }
}

void saikirru_superfast(smat_t *a)
{
        int i, j,i1,j1;
        double x1,x2,y1,y2,y3,y4,reg1,reg2,reg5,reg6;
        int reg3,reg4,block=12;
        double sum1, sum2,sinreg,cosreg,ss,sss;
        int max = a->n;
        double *mat = a->mat;
        for(i = 0; i < max; i+=block)
        {
	 for(j = 0; j < max; j+=block)
	 {
	  for(i1 = i; i1 < i+block; i1+=2)
	  {
           reg3 = i1 * max;
           reg4 = (i1+1)*max;
           cosreg = cos(i1); sinreg = sin(i1);
            if (i1 %4 == 0)
                {
                        ss = sinreg;
                        sss= -sinreg;
                }
                else
                {
                        ss =-sinreg;
                        sss = sinreg;
                }
                for(j1 = j; j1 < j+block; j1+=2)
                {
                 reg1 =  mat[reg3 + j1];
                 reg5 =  mat[reg3 + (j1+1)];
                 reg2 =  mat[reg4 + j1];
                 reg6 =  mat[reg4 + (j1+1)];

                 mat[reg3 + j1] =reg1*(1 + cosreg) + ss* reg2;
                 mat[reg3 + (j1+1)] = reg5*(1 + cosreg ) + ss* reg6;
                 mat[reg4 + j1] =  sss * reg1 +reg2*(1+ cosreg);
                 mat[reg4 + (j1+1)] =  sss * reg5 +reg6 *(1+ cosreg);
                }
        }
}}}


void saikirru_superfast_2(smat_t *a)
{
        int i, j;
        double x1,x2,y1,y2,y3,y4,reg1,reg2,reg5,reg6,reg8,reg9,reg10,reg11,reg12;
        int reg3,reg4,reg7;
        double sum1, sum2,sinreg,cosreg,ss,sss;
        int max = a->n;
        double *mat = a->mat;

        for(i = 0; i < max; i+=3)
        {
         reg3 = i * max;
         reg4 = (i+1)*max;
	 reg7 = (i+2)*max;
         cosreg = cos(i); sinreg = sin(i);
          if (i %4 == 0)
                {
                        ss = sinreg;
                        sss= -sinreg;
                }
                else
                {
                        ss =-sinreg;
                        sss = sinreg;
                }
                for(j = 0; j < max; j+=3)
                {
                 reg1 =  mat[reg3 + j];
                 reg5 =  mat[reg3 + (j+1)];
		 reg8 =  mat[reg3 + (j+2)];
                 reg2 =  mat[reg4 + j];
                 reg6 =  mat[reg4 + (j+1)];
		 reg9 =  mat[reg4 + (j+2)];
		 reg10=  mat[reg7 + j];
		 reg11=  mat[reg7 + (j+1)];
		 reg12=  mat[reg7 + (j+2)];

                 mat[reg3 + j] = reg1*(1 + cosreg) + ss* reg2;
                 mat[reg3 + (j+1)] = reg5*(1 + cosreg ) + ss* reg6;
		 mat[reg3 + (j+2)] = reg8*(1 + cosreg ) + ss* reg9;
                 mat[reg4 + j] =  sss * reg1 +reg2*(1+ cosreg);
                 mat[reg4 + (j+1)] =  sss * reg5 +reg6 *(1+ cosreg);
		 mat[reg4 + (j+2)] = sss * reg8 + reg9*(1+ cosreg);
		 mat[reg7 + j] = reg10*(1+ cosreg) + sss * reg2;
		 mat[reg7 + (j+1)] = reg11*(1+ cosreg) + sss * reg6;
		 mat[reg7 + (j+2)] = reg12*(1+ cosreg) + sss * reg9;
                }
        }
}

void improved_Better_ok_2(smat_t *a)
{
        int i, j;
        double x1,x2,reg1,reg2,reg5,reg6,cosreg1;
        int reg3,reg4;
        double sum1, sum2,sinreg,cosreg,sin1,sin2;
        int max = a->n;
        double *mat = a->mat;

        for(i = 0; i < max; i+=2)
        {
         reg3 = i * max;
         reg4 = (i+1)*max;
	 cosreg = cos(i);
	 sinreg = sin(i);
          if (i %4 == 0)
                {
            
                       sin1 = sinreg;
                       sin2= -sinreg;
          
                }
                else
                {
          
                      sin1 =-sinreg;
                        sin2 = sinreg;
           

                }

                for(j = 0; j < max; j+=2)
                {
                 reg1 =  mat[reg3 + j];
		 reg5 = mat[reg3 +(j+1)];
                 reg2 =  mat[reg4 + j];
		 reg6 = mat[reg4 + (j+1)];
		   cosreg1 =1+ cosreg;
                        mat[reg3 + j] =reg1*cosreg1 +sin1* reg2;
			mat[reg3 + (j+1)]=reg5 * cosreg1 + sin1* reg6;
                         mat[reg4 + j] = sin2 * reg1 +reg2* cosreg1;
			mat[reg4 + (j+1)]=sin2 * reg5 +reg6*cosreg1;
                }
        }
}



/* 
* Called by the driver to register your functions
* Use add_function(func, description) to add your own functions
*/
void register_functions()
{
	// Registers comp_superslow with the driver
	add_function(&superslow, "superslow: original function");
	add_function(&Better, "Better:improved function");
	add_function(&Better_ok, "Better_ok:improved function");
	add_function(&Better_ok_1, "Better_ok_1:improved function");
        add_function(&Better_ok_2, "Better_ok_2:improved function");
	add_function(&super, "super:improved function");
	add_function(&kirru_super, "kirru_super:improved function");
	add_function(&kirru_superfast, "kirru_superfast:improved function");
add_function(&saikirru_superfast, "saikirru_superfast:improved function");
 add_function(&improved_Better_ok_2, "improved_Better_ok_2:improved function");
add_function(&saikirru_superfast_2, "saikirru_superfast_2:improved function");
//	add_function(&fast, "fast: optimized version 1");
	//Add your functions here
	//add_function(&superslow2, "superslow: Optimization X");
}
