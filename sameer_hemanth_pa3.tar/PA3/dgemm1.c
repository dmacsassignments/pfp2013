#define MIN(a,b) ((a) < (b) ? a : b)
#include<nmmintrin.h>
const char* dgemm_desc = "My awesome dgemm.";

/*void square_dgemm(const int M, const double *A, const double *B, double *C)
{
   int i, j, k;
   for (j = 0; j < M; ++j) {
      for (k = 0; k < M; ++k) {
          double bkj = B[j*M+k];
             for (i = 0; i < M; ++i)
                 C[j*M+i] += A[k*M+i] * bkj ;
                            }
                  }
}*/

void square_dgemm(const int M, const double *A, const double *B, double *C)
{
   int i,j,k,kk,ii;
   int Bl = 104;
   for(kk = 0; kk < M ;kk += Bl)
      for(ii = 0 ; ii < M ; ii += Bl)
         for(j = 0 ; j < M ;j++)
             for(k = kk; k < MIN(kk + Bl,M);k++)
             {  register int jM = j*M;
                register double bkj = B[jM + k];
               const __m128d br = _mm_set1_pd(B[jM+k]);
                register int kM = k*M;
                for(i = ii; i < MIN(ii + Bl,M-1);i+=2)
                {
					__m128d cr= _mm_loadu_pd(C+jM+i);
					const __m128d ar= _mm_loadu_pd(A+kM+i);
					cr = _mm_add_pd(cr, _mm_mul_pd(ar,br));
//                   C[jM + i] += A[kM + i] * bkj;
                    _mm_storeu_pd(C+jM+i,cr);

                }
                for(; i < M;i+=2)
				                {
									//__m128 c= _mm_load_ps(C+jM+i);
									//__m128 a= _mm_load_ps(A+km+i);
									//c = _mm_add_ps(c, _mm_mul_ps(a,b));
				                   C[jM + i] += A[kM + i] * bkj;
				                    //_mm_store_ps(C+jM+i,c);

                }
             }

}
