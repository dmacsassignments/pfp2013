#!/bin/sh
MATMUL_DIR=`pwd`

cat > serial.qsub <<EOF
#!/bin/bash
#$ -V
#$ -S /bin/bash
#$ -N matmul	 # Job Name
#$ -j y	 # Combine stderr and stdout
#$ -o $JOB_NAME.o$JOB_ID	 # Name of the output file (eg. matmul.oJobID)
#$ -pe 1way 12	 # Requests 1 core
#$ -q normal	 # Queue name normal
#$ -l h_rt=00:30:00	 # Run time (hh:mm:ss) - 1.5 hours
#$ -M	email@email.com # Address for email notification
#$ -m be	 # Email at Begin and End of job
set -x	 # Echo commands, use set echo with csh

cd $MATMUL_DIR
module load swap intel gcc/4.4.5
module load atlas
export LD_LIBRARY_PATH=\$(TACC_ATLAS_LIB):\$LD_LIBRARY_PATH
hostname > timing-$2.out
$1 >> timing-$2.out
exit 0;
EOF
