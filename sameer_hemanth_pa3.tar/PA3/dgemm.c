#include<smmintrin.h>
#include<immintrin.h>
#include<nmmintrin.h>
#define MIN(a,b) ((a) < (b) ? a : b)
#define MOD(x,y) ((x) - (x)%y)
const char* dgemm_desc = "My awesome dgemm.";

/*void square_dgemm(const int M, const double *A, const double *B, double *C)
{
   int i, j, k;
   for (j = 0; j < M; ++j) {
      for (k = 0; k < M; ++k) {
          double bkj = B[j*M+k];
             for (i = 0; i < M; ++i)
                 C[j*M+i] += A[k*M+i] * bkj ;
                            }
                  }
}*/

void square_dgemm(const int M, const double *A, const double *B, double *C)
{
   int i,j,k,kk,ii;
   int mod2 = MOD(M,2),mod4=MOD(M,4);
   int Bl =60;
   for(kk = 0; kk < M ;kk += Bl)
   {int mink = MIN(kk+Bl,mod4);
      for(ii = 0 ; ii < M ; ii += Bl)
    {int mini = MIN(ii+Bl,M);
     int i_terminate = MIN(ii+Bl,mod4);
         for(j = 0 ; j < mod2 ;j+=2)
	 {
             /*for(k = kk; k < MIN(kk + Bl,M);k++)
             {
                register double bkj = B[j*M + k];
                register int jM = j*M;
                register int kM = k*M;
                for(i = ii; i < MIN(ii + Bl,M);i++)
                {
                   C[jM + i] += A[kM + i] * bkj;
                }
             }*/
	                         register int jM1 = j*M;
	                         register int jM2 = (j+1)*M;
	                         register int kM1 = k*M;
	                         register int kM2 = (k+1)*M;
	                         register int kM3 = (k+2)*M;
	                         register int kM4 = (k+3)*M;
       for(k = kk; k < mink; k+=4)
	                       //for(j0 = j; j0 < MIN(j + MU, MIN(jj + Bl,M)); j0++)
	                       {
	                         //register double bkj = B[j0*M + k0];
	                         register int jM1 = j*M;
	                         register int jM2 = (j+1)*M;
	                         register int kM1 = k*M;
	                         register int kM2 = (k+1)*M;
	                         register int kM3 = (k+2)*M;
	                         register int kM4 = (k+3)*M;
	                         const __m256d br11 = _mm256_set1_pd(B[jM1+k]);
	                         const __m256d br12 = _mm256_set1_pd(B[jM1+k+1]);
	                         const __m256d br13 = _mm256_set1_pd(B[jM1+k+2]);
	                         const __m256d br14 = _mm256_set1_pd(B[jM1+k+3]);
	                         const __m256d br21 = _mm256_set1_pd(B[jM2+k]);
							 const __m256d br22 = _mm256_set1_pd(B[jM2+k+1]);
							 const __m256d br23 = _mm256_set1_pd(B[jM2+k+2]);
	                         const __m256d br24 = _mm256_set1_pd(B[jM2+k+3]);
	                      //   int i_terminate = MIN(ii + Bl,mod4);
	                         for(i = ii; i < i_terminate; i+=4)
	                         {
	                            //C[j0M + i0] += A[k0M + i0] * bkj;
	                            //C[j0M + i0 + 1] += A[k0M + i0 + 1] * bkj;
	                            __m256d cr1= _mm256_loadu_pd(C+jM1+i);
	                            __m256d cr2= _mm256_loadu_pd(C+jM2+i);
	   			const __m256d ar1= _mm256_loadu_pd(A+kM1+i);
	   			const __m256d ar2= _mm256_loadu_pd(A+kM2+i);
	   			const __m256d ar3= _mm256_loadu_pd(A+kM3+i);
	   			const __m256d ar4= _mm256_loadu_pd(A+kM4+i);
	   			cr1 = _mm256_add_pd(cr1, _mm256_mul_pd(ar1,br11));
	   			cr1 = _mm256_add_pd(cr1, _mm256_mul_pd(ar2,br12));
	   			cr1 = _mm256_add_pd(cr1, _mm256_mul_pd(ar3,br13));
	   			cr1 = _mm256_add_pd(cr1, _mm256_mul_pd(ar4,br14));
                cr2 = _mm256_add_pd(cr2, _mm256_mul_pd(ar1,br21));
	   			cr2 = _mm256_add_pd(cr2, _mm256_mul_pd(ar2,br22));
	   			cr2 = _mm256_add_pd(cr2, _mm256_mul_pd(ar3,br23));
	   			cr2 = _mm256_add_pd(cr2, _mm256_mul_pd(ar4,br24));
	                       _mm256_storeu_pd(C+jM1+i,cr1);
	                       _mm256_storeu_pd(C+jM2+i,cr2);

	                         }
	                         for( ; i <mini;i++)
	                         {
	                            C[jM1 + i] += A[kM1 + i] * B[jM1 + k];
	                            C[jM1 + i] += A[kM2 + i] * B[jM1 + k+1];
	                            C[jM1 + i] += A[kM3 + i] * B[jM1 + k+2];
	                            C[jM1 + i] += A[kM4 + i] * B[jM1 + k+3];
                                C[jM2 + i] += A[kM1 + i] * B[jM2 + k];
	                            C[jM2 + i] += A[kM2 + i] * B[jM2 + k+1];
	                            C[jM2 + i] += A[kM3 + i] * B[jM2 + k+2];
	                            C[jM2 + i] += A[kM4 + i] * B[jM2 + k+3];
	                         }
	                       }
	   				for(; k < MIN(kk + Bl,M); k++)
	   				  //for(j0 = j; j0 < MIN(j + MU, MIN(jj + Bl,M)); j0++)
	   				   {
	   					  //register double bkj = B[j0*M + k0];
	   					  //register int jM = j*M;
	   					  register int kM = k*M;

	   					const __m256d br11 = _mm256_set1_pd(B[jM1+k]);
	   					const __m256d br21 = _mm256_set1_pd(B[jM2+k]);

	   					//const __m256d br2 = _mm256_set1_pd(B[j0M+k0+1]);
	   				//	int i_terminate =  MIN(ii + Bl,mod4);
	   					for(i = ii; i < i_terminate; i+=4)
	   						{
	   										 //C[j0M + i0] += A[k0M + i0] * bkj;
	   										 //C[j0M + i0 + 1] += A[k0M + i0 + 1] * bkj;
	   						 __m256d cr1= _mm256_loadu_pd(C+jM1+i);
	   						 __m256d cr2= _mm256_loadu_pd(C+jM2+i);

	   						const __m256d ar= _mm256_loadu_pd(A+kM+i);
	   						//const __m256d ar2= _mm256_loadu_pd(A+k0M2+i0);
	   							cr1 = _mm256_add_pd(cr1, _mm256_mul_pd(ar,br11));
	   							cr2 = _mm256_add_pd(cr2, _mm256_mul_pd(ar,br21));

	   							//cr = _mm256_add_pd(cr, _mm256_mul_pd(ar2,br2));
	   									_mm256_storeu_pd(C+jM1+i,cr1);
	   									_mm256_storeu_pd(C+jM2+i,cr2);

	   									  }
	   									  for( ; i < mini;i++)
	   									  {
	   										 C[jM1 + i] += A[kM + i] * B[jM1 + k];
	   										 C[jM2 + i] += A[kM + i] * B[jM2 + k];

	   							//			 C[j0M + i0] += A[k0M2 + i0] * B[j0*M + k0+1];
	   									  }
	   				}
                }
      for( ; j < M ;j++)
	 {
             /*for(k = kk; k < MIN(kk + Bl,M);k++)
             {
                register double bkj = B[j*M + k];
                register int jM = j*M;
                register int kM = k*M;
                for(i = ii; i < MIN(ii + Bl,M);i++)
                {
                   C[jM + i] += A[kM + i] * bkj;
                }
             }*/
       for(k = kk; k < mink; k+=4)
	                       //for(j0 = j; j0 < MIN(j + MU, MIN(jj + Bl,M)); j0++)
	                       {
	                         //register double bkj = B[j0*M + k0];
	                         register int jM = j*M;
	                         register int kM1 = k*M;
	                         register int kM2 = (k+1)*M;
	                         register int kM3 = (k+2)*M;
	                         register int kM4 = (k+3)*M;
	                         const __m256d br1 = _mm256_set1_pd(B[jM+k]);
	                         const __m256d br2 = _mm256_set1_pd(B[jM+k+1]);
	                         const __m256d br3 = _mm256_set1_pd(B[jM+k+2]);
	                         const __m256d br4 = _mm256_set1_pd(B[jM+k+3]);
	                      //   int i_terminate = MIN(ii + Bl,mod4);
	                         for(i = ii; i < i_terminate; i+=4)
	                         {
	                            //C[j0M + i0] += A[k0M + i0] * bkj;
	                            //C[j0M + i0 + 1] += A[k0M + i0 + 1] * bkj;
	                            __m256d cr= _mm256_loadu_pd(C+jM+i);
	   			const __m256d ar1= _mm256_loadu_pd(A+kM1+i);
	   			const __m256d ar2= _mm256_loadu_pd(A+kM2+i);
	   			const __m256d ar3= _mm256_loadu_pd(A+kM3+i);
	   			const __m256d ar4= _mm256_loadu_pd(A+kM4+i);
	   			cr = _mm256_add_pd(cr, _mm256_mul_pd(ar1,br1));
	   			cr = _mm256_add_pd(cr, _mm256_mul_pd(ar2,br2));
	   			cr = _mm256_add_pd(cr, _mm256_mul_pd(ar3,br3));
	   			cr = _mm256_add_pd(cr, _mm256_mul_pd(ar4,br4));
	                       _mm256_storeu_pd(C+jM+i,cr);
	                         }
	                         for( ; i <mini;i++)
	                         {
	                            C[jM + i] += A[kM1 + i] * B[j*M + k];
	                            C[jM + i] += A[kM2 + i] * B[j*M + k+1];
	                            C[jM + i] += A[kM3 + i] * B[j*M + k+2];
	                            C[jM + i] += A[kM4 + i] * B[j*M + k+3];
	                         }
	                       }
	   				for(; k < MIN(kk + Bl,M); k++)
	   				  //for(j0 = j; j0 < MIN(j + MU, MIN(jj + Bl,M)); j0++)
	   				   {
	   					  //register double bkj = B[j0*M + k0];
	   					  register int jM = j*M;
	   					  register int kM = k*M;

	   					const __m256d br = _mm256_set1_pd(B[jM+k]);
	   					//const __m256d br2 = _mm256_set1_pd(B[j0M+k0+1]);
	   				//	int i_terminate =  MIN(ii + Bl,mod4);
	   					for(i = ii; i < i_terminate; i+=4)
	   						{
	   										 //C[j0M + i0] += A[k0M + i0] * bkj;
	   										 //C[j0M + i0 + 1] += A[k0M + i0 + 1] * bkj;
	   						 __m256d cr= _mm256_loadu_pd(C+jM+i);
	   						const __m256d ar= _mm256_loadu_pd(A+kM+i);
	   						//const __m256d ar2= _mm256_loadu_pd(A+k0M2+i0);
	   							cr = _mm256_add_pd(cr, _mm256_mul_pd(ar,br));
	   							//cr = _mm256_add_pd(cr, _mm256_mul_pd(ar2,br2));
	   									_mm256_storeu_pd(C+jM+i,cr);
	   									  }
	   									  for( ; i < mini;i++)
	   									  {
	   										 C[jM + i] += A[kM + i] * B[j*M + k];
	   							//			 C[j0M + i0] += A[k0M2 + i0] * B[j0*M + k0+1];
	   									  }
	   				}
                }
         }
      }
}

