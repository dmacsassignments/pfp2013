#include<smmintrin.h>
#include<immintrin.h>
#include<nmmintrin.h>
#define MIN(a,b) ((a) < (b) ? a : b)
#define MOD(x) ((x) - (x)%4)
const char* dgemm_desc = "My awesome dgemm.";

/*void square_dgemm(const int M, const double *A, const double *B, double *C)
{
   int i, j, k;
   for (j = 0; j < M; ++j) {
      for (k = 0; k < M; ++k) {
          double bkj = B[j*M+k];
             for (i = 0; i < M; ++i)
                 C[j*M+i] += A[k*M+i] * bkj ;
                            }
                  }
}*/

/*void square_dgemm(const int M, const double *A, const double *B, double *C)
{
   int i,j,k,kk,jj,ii,i0,j0,k0;
   int Bl = 2048;
   int MU = 16;
   for(kk = 0; kk < M ;kk += Bl)
      for(ii = 0 ; ii < M ; ii += Bl)
         for(j = 0 ; j < M ;j+= Bl)
             for(k = kk; k < MIN(kk + Bl,M);k += MU)
             {
                for(i = ii; i < MIN(ii + Bl,M);i += MU)
                {
                   for(k0 = k; k0 < MIN(k + MU, MIN(kk + Bl,M)); k0++)
                      for(j0 = j; j0 < MIN(j + Bl, M);j0++)
                         for(i0 = i; i0 < MIN(i + MU, MIN(ii + Bl,M)); i0++)
                            {
                              C[j0*M + i0] += A[k0*M + i0] * B[j0*M + k0];
                            }
                }
             }

}*/
void square_dgemm(const int M, const double *A, const double *B, double *C)
{
   int i,j,k,kk,ii,jj,i0,j0,k0,mini,minj,mink;
   int Bl = 400;
   int MU = 40;
   int modM = MOD(M);
    for(jj = 0; jj < M ;jj += Bl)
    for(kk = 0; kk < M ;kk += Bl)
      for(ii = 0; ii < M ; ii += Bl)
         for(j = jj; j < (minj=MIN(jj + Bl,M))  ;j += MU)
           for(k = kk; k < (mink=MIN(kk + Bl,M));k += MU)
             for(i = ii; i < (mini=MIN(ii + Bl,M));i += MU)
                for(j0 = j; j0 < MIN(j + MU, minj); j0++)
                 for(k0 = k; k0 < MIN(k + MU, mink); k0++)
                    //for(j0 = j; j0 < MIN(j + MU, MIN(jj + Bl,M)); j0++)
                    {
                      //register double bkj = B[j0*M + k0];
                      register int j0M = j0*M;
                      register int k0M = k0*M;
                      const __m256d br = _mm256_set1_pd(B[j0M+k0]);
                      for(i0 = i; i0 < (MIN(i + MU, MIN(ii + Bl,modM))); i0+=4)
                      {
                         //C[j0M + i0] += A[k0M + i0] * bkj;
                         //C[j0M + i0 + 1] += A[k0M + i0 + 1] * bkj;
                         __m256d cr= _mm256_loadu_pd(C+j0M+i0);
			const __m256d ar= _mm256_loadu_pd(A+k0M+i0);
			cr = _mm256_add_pd(cr, _mm256_mul_pd(ar,br));
                    _mm256_storeu_pd(C+j0M+i0,cr);
                      }
                      for( ; i0 < MIN(i + MU,MIN(ii + Bl,M));i0++)
                      {
                         C[j0M + i0] += A[k0M + i0] * B[j0*M + k0];
                      }
                    }

}

