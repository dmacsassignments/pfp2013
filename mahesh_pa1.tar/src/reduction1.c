#include <stdio.h>
#include<stdlib.h>
#include <math.h>
#include "rdtsc.h"

#define N 10000
#define NUM_RUNS 50

int main()
{
        int * buffer;
        tsc_counter a, b;
        int i;
        long int sum=0;
        long int sum_func = 0;
        double cycles;
        
        buffer = (int*) malloc(sizeof(int)*N);

        for ( i = 0; i<N; i++){
                        buffer[i] = rand();
        }
         
        for( i=0; i<N; ++i)
        {
                sum += buffer[i];
        }

        CPUID(); RDTSC(a); CPUID(); RDTSC(b);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);

        RDTSC(a);
        for( i=0; i<N; ++i)
        {
                sum_func += buffer[i];
        }

        RDTSC(b);
        cycles = ((double)COUNTER_DIFF(b, a));
        printf("Sum is %ld\n",sum);
        printf("Sum function is %ld\n",sum_func);
        printf("%lf cycles\n ",cycles);
}
