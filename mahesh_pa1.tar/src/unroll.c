

#include <stdio.h>
#include<stdlib.h>
#include <math.h>
#include "rdtsc.h"


#define N 1024
#define NUM_RUNS 50
// typedef data_t int;



float Unroll4(float *x)
{
   int i;
   float a,a0,a1,a2,a3;
   a=a0=a1=a2=a3=0;
   for(i=0;i<N;i+=4)
   {
      a0 += x[i];
      a1 += x[i+1];
      a2 += x[i+2];
      a3 += x[i+3];
   }
   a = a0+a1+a2+a3;

   return a;
}
      
float Unroll5(float *x)
{
   int i;
   float a,a0,a1,a2,a3,a4;
   a=a0=a1=a2=a3=a4=0;
   for(i=0;i<N;i+=5)
   {
      a0 += x[i];
      a1 += x[i+1];
      a2 += x[i+2];
      a3 += x[i+3];
      a4 += x[i+4];
   }
   a = a0+a1+a2+a3+a4;
   while(i<N)
   {
     a += x[i];
     i++;
   }
   return a;
}

float Unroll6(float *x)
{
   int i;
   float a,a0,a1,a2,a3,a4,a5;
   a0=a1=a2=a3=a4=a5=0;
   for(i=0;i<N;i+=6)
   {
      a0 += x[i];
      a1 += x[i+1];
      a2 += x[i+2];
      a3 += x[i+3];
      a4 += x[i+4];
      a5 += x[i+5];
   }
   a = a0+a1+a2+a3+a4+a5;
   while(i<N)
   {
     a += x[i];
     i++;
   }
   return a;
}


float Unroll7(float *x)
{
   int i,j;
   j = j%7;
   float a,a0,a1,a2,a3,a4,a5,a6;
   a0=a1=a2=a3=a4=a5=a6=0;
   for(i=0;i<j;i+=7)
   {
      a0 += x[i];
      a1 += x[i+1];
      a2 += x[i+2];
      a3 += x[i+3];
      a4 += x[i+4];
      a5 += x[i+5];
      a6 += x[i+6];
   }
   a = a0+a1+a2+a3+a4+a5+a6;
   for(;i<N;i++)
   {
     a += x[i];
   }
   return a;
}
float Unroll8(float *x)
{
   int i;
   float a,a0,a1,a2,a3,a4,a5,a6,a7;
   a0=a1=a2=a3=a4=a5=a6=a7=0;
   for(i=0;i<N;i+=8)
   {
      a0 += x[i];
      a1 += x[i+1];
      a2 += x[i+2];
      a3 += x[i+3];
      a4 += x[i+4];
      a5 += x[i+5];
      a6 += x[i+6];
      a7 += x[i+7];
   }
   a = a0+a1+a2+a3+a4+a5+a6+a7;
   while(i<N)
   {
     a += x[i];
     i++;
   }
   return a;
}


float Unroll9(float *x)
{
   int i;
   float a,a0,a1,a2,a3,a4,a5,a6,a7,a8;
   a0=a1=a2=a3=a4=a5=a6=a7=a8=0;
   for(i=0;i<N;i+=9)
   {
      a0 += x[i];
      a1 += x[i+1];
      a2 += x[i+2];
      a3 += x[i+3];
      a4 += x[i+4];
      a5 += x[i+5];
      a6 += x[i+6];
      a7 += x[i+7];
      a8 += x[i+8];
   }
   a = a0+a1+a2+a3+a4+a5+a6+a7+a8;
   while(i<N)
   {
     a += x[i];
     i++;
   }
   return a;
}


float Unroll10(float *x)
{
   int i,j;
   j = N-N%10;
   float a,a0,a1,a2,a3,a4,a5,a6,a7,a8,a9;
   a0=a1=a2=a3=a4=a5=a6=a7=a8=a9=0.0;
   for(i=0;i<j;i+=10)
   {
      a0 += x[i];
      a1 += x[i+1];
      a2 += x[i+2];
      a3 += x[i+3];
      a4 += x[i+4];
      a5 += x[i+5];
      a6 += x[i+6];
      a7 += x[i+7];
      a8 += x[i+8];
      a9 += x[i+9];
   }
   a = a0+a1+a2+a3+a4+a5+a6+a7+a8+a9;
   for(;i<N;i++)
   {
     a += x[i];
   }
   return a;
}


float Unroll11(float *x)
{
   int i;
   float a,a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10;
   a0=a1=a2=a3=a4=a5=a6=a7=a8=a9=a10=0;
   for(i=0;i<N;i+=11)
   {
      a0 += x[i];
      a1 += x[i+1];
      a2 += x[i+2];
      a3 += x[i+3];
      a4 += x[i+4];
      a5 += x[i+5];
      a6 += x[i+6];
      a7 += x[i+7];
      a8 += x[i+8];
      a9 += x[i+9];
      a10 += x[i+10];
   }
   a = a0+a1+a2+a3+a4+a5+a6+a7+a8+a9+a10;
   while(i<N)
   {
     a += x[i];
     i++;
   }
   return a;
}
float Unroll12(float *x)
{
   int i;
   float a,a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11;
   a0=a1=a2=a3=a4=a5=a6=a7=a8=a9=a10=a11=0;
   for(i=0;i<N;i+=12)
   {
      a0 += x[i];
      a1 += x[i+1];
      a2 += x[i+2];
      a3 += x[i+3];
      a4 += x[i+4];
      a5 += x[i+5];
      a6 += x[i+6];
      a7 += x[i+7];
      a8 += x[i+8];
      a9 += x[i+9];
      a10 += x[i+10];
      a11 += x[i+11];
   }
   a = a0+a1+a2+a3+a4+a5+a6+a7+a8+a9+a10+a11;
   while(i<N)
   {
     a += x[i];
     i++;
   }
   return a;
}

float Unroll13(float *x)
{
   int i;
   float a,a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12;
   a0=a1=a2=a3=a4=a5=a6=a7=a8=a9=a10=a11=a12=0;
   for(i=0;i<N;i+=13)
   {
      a0 += x[i];
      a1 += x[i+1];
      a2 += x[i+2];
      a3 += x[i+3];
      a4 += x[i+4];
      a5 += x[i+5];
      a6 += x[i+6];
      a7 += x[i+7];
      a8 += x[i+8];
      a9 += x[i+9];
      a10 += x[i+10];
      a11 += x[i+11];
      a12 += x[i+12];
   }
   a = a0+a1+a2+a3+a4+a5+a6+a7+a8+a9+a10+a11+a12;
   while(i<N)
   {
     a += x[i];
     i++;
   }
   return a;
}


int main()
{	
	 float * buffer;
	tsc_counter a, b;
        int i; 
        float sum=0;
        float sum_func = 0;
	double cycles, baseline;
      //  float *x,*y,*y_vec,*M;
	//N is a define
	buffer = (float*) malloc(sizeof(float)*N);
//	x = (float*) malloc(sizeof(float)*N);
//	y = (float*) malloc(sizeof(float)*N);
//	y_vec = (float*) malloc(sizeof(float)*N);

	//if (M == NULL || x == NULL || y == NULL || y_vec == NULL)
	//	return 1;

	//init vars
	for ( i = 0; i<N; i++){
			buffer[i] = rand();	
	}
			
        for(i=0;i<N;i++)
        {
           sum +=buffer[i];
        }
	printf("%f\n",sum);
	

	
	//-----------------------------------------Timing 1
	//warm up	

	//-----------------No Vec Warmup-------------------
	//lookup task b from the HW here
	//
	//State the Asm. Instructions used by the compiler as a comment here:
	//
	// <--- List of Instructions --->
	//-----------------------------------------Timing 1
	//warm up
		Unroll4(buffer);


	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for( i=0; i<NUM_RUNS; ++i)
	{ 
  		sum_func = Unroll4(buffer);
	}
         
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	//printf("%lf cycles -> Speedup: %2.2f x through partially unrolled code - %1.0f\n",cycles,baseline/cycles,y[0]);
	printf("%f\n",sum_func);
        printf("%lf cycles\n ",cycles);
 
        if(sum == sum_func)
            printf("The values are equal........\n");
	//-----------------------------------------Timing 2
	//warm up
/*		Unroll4(buffer,a);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for(i=0; i<NUM_RUNS; ++i)
	{ 
		Unroll4(buffer,a);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles -> Speedup: %2.2f x through vectorized code - %1.0f\n",cycles,baseline/cycles,y_vec[0]);
	
	

	free(M);
	free(y);
	free(x);*/
        free(buffer);


	return 0;
}

