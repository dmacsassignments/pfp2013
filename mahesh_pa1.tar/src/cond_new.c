#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define n 2000
#define m 3000

void main()
{
  register double **a, **b, *p,*q,*r,*s,c, norm,norm1,norm2,norm3,norm4,norm5,norm6,norm7,norm8;
  register int i, j, l,size,size2;
  
  a = (double**)malloc(n*sizeof(double*));
  b = (double**)malloc(n*sizeof(double*));
  size2 = sizeof(double);
  size = m*size2;
  
  for(i=0; i<n; i++)
    {
      a[i] = (double*)malloc(size);
      for(j=0; j<n; j++) a[i][j] = drand48();b[i] = (double*)calloc(m, size2);
    }
    
//  for(i=0; i<n; i++) b[i] = (double*)calloc(m, sizeof(double));
 

  for(i=0;i<n;i++)
  {
   p = b[i];
   q = a[i];
  for(l=1; l<=30; l++)
        for(j=0;j<m;j+=8)
        {     r = p+j;
              s = q+j;
	      b[i][j] = 13.0 *  *(r) + *(s);
	      b[i][j+1] = 13.0 * *(r+1) - *(s+1);
	      b[i][j+2] = 13.0 * *(r+2) + *(s+2);
	      b[i][j+3] = 13.0 * *(r+3) - *(s+3);
              b[i][j+4] = 13.0 * *(r+4) + *(s+4);
              b[i][j+5] = 13.0 * *(r+5) - *(s+5);
	      b[i][j+6] = 13.0 * *(r+6) + *(s+6);
              b[i][j+7] = 13.0 * *(r+7) - *(s+7);
	     
        }
    
  }
  norm = 0.0;
  norm1 = norm2 = norm3 = norm4 = norm5 = norm6 = norm7 = norm8 = 0.0;
  for(i=0; i<n; i++)
  {
     p = b[i];
   //  q = a[i];

    for(j=0; j<m; j+=8)
    {
      r = p+j;
      norm1 = norm1 + fabs( *(r) * *(r));
      norm2 = norm2 + fabs(*(r+1) * *(r+1));
      norm3 = norm3 + fabs(*(r+2) * *(r+2));
      norm4 = norm4 + fabs(*(r+3) * *(r+3));
      norm5 = norm5 + fabs(*(r+4) * *(r+4));
      norm6 = norm6 + fabs(*(r+5) * *(r+5));
      norm7 = norm7 + fabs(*(r+6) * *(r+6));
      norm8 = norm8 + fabs(*(r+7) * *(r+7));
     }
  }
   norm = norm1 + norm2 + norm3 + norm4 + norm5 + norm6 + norm7 + norm8;
  printf("norm: %10.4e    Value: %10.4e\n",norm, b[10][10]);
}
