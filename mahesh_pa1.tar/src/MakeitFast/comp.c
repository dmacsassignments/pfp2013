/*
 * comp.c - contains the function superslow that you need to optimize
 *
 *
 */

#include <math.h>
#include <stdio.h>
#include<stdlib.h>
#include "comp.h"
#include "perf.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


/* f(x, i, j) multiplies or divides by a sine expression depending
   on i + j being odd or even
*/
 inline double f(double x, int i, int j)
{
    if((i + j) & 0x1)
        return x / (1 + sin(M_PI/(i+1)));
    else
        return x * sin(M_PI/(i+1));
}

/* This is the function you need to optimize. It takes one
   square matrix as input
*/
void superslow(smat_t *a)
{
    int i, j;
    double x,x2;

    //i is the column of a we're computing right now
    for(i = 0; i < a->n; i++)
    {
        // j is the row of a we're computing right now
         for(j = 0; j < a->n; j++)
         {
              // First, compute f(A) for the element of a in question
                   x = get_elt(a, i, j);
                   x = f(x, i, j);
               // Add this to the value of a we're computing and store it
                        x2 = get_elt(a, i, j);
                        x = x * x2;
                        set_elt(a,i,j,x);                                                                                                                                         }    
     }
}
void superslow2(smat_t *a)
{
    int i, j,len,var;
    double *mat;
    double x,y,z,w,x1,y1,z1,w1,val;
    len = a->n;
    mat = a->mat;
    // i is the column of a we're computing right now
    for(i = 0; i < len; i++)
    {    var = i * len;
         val = sin(M_PI/(i+1));
         //bool even = i&0x1;
        // j is the row of a we're computing right now
        for(j = 0; j < len; j+=4)
        {            
                // First, compute f(A) for the element of a in question
		//	x = get_elt(a, i, j);
		x = mat[var + j];	
                y = mat[var +j+1];
                z = mat[var +j+2];
                w = mat[var + j+3];
               if((i+j) & 0x1)
               {
               //if((i^j))
                   x1 = x / (1 + val);
                   y1 = y * val;
                   z1 = z / (1 + val);
                   w1 = w * val;
               }
               else
               {
                   x1 = x * val;
                   y1 = y / (1 +val);
                   z1 = z * val;
                   w1 = w / (1 + val);
               }


		x1 = x1 * x;
                y1 = y1 * y;
                z1 = z1 * z;
                w1 = w1 * w;
               // set_elt(a, i, j, x);
                  mat[var + j] = x1;
                  mat[var + j + 1] = y1;
                  mat[var + j + 2] = z1;
                  mat[var + j + 3] = w1;
                
            
        }
    }
}
void superslow3(smat_t *a)
{
    int i, j,len;
    double *mat;
    double x;
    len = a->n;
    mat = a->mat;
    
    for(i = 0; i < len; i++)
    {
      for(j = 0; j < a->n; j++)
      {
        x = mat[i*len + j];
        x = f(x, i, j);
        x = x * mat[i*len + j];
        mat[i*len + j] = x;
      }
    }
}
void superslow4(smat_t *a)
{
    int i, j,len,var;
    double *mat;
    double x;
    len = a->n;
    mat = a->mat;
    
    for(i = 0; i < len; i++)
    { var = i*len;
      for(j = 0; j < a->n; j++)
      {
        x = mat[var + j];
        x = f(x, i, j);
        x = x * mat[var + j];
        mat[var + j] = x;
      }
    }
}
void superslow5(smat_t *a)
{
    int i, j,len,var;
    double *mat;
    double x;
    len = a->n;
    mat = a->mat;
    
    for(i = 0; i < len; i++)
    { var = i*len;
      for(j = 0; j < a->n; j++)
      {
        x = mat[var + j];
        if((i + j) & 0x1)
          x = x / (1 + sin(M_PI/(i+1)));
        else
          x = x * sin(M_PI/(i+1));

        
        x = x * mat[var + j];
        mat[var + j] = x;
      }
    }
}
void superslow6(smat_t *a)
{
    int i, j,len,var;
    double *mat;
    double x,val;
    len = a->n;
    mat = a->mat;
    
    for(i = 0; i < len; i++)
    { var = i*len;
      val = sin(M_PI/(i+1));
      for(j = 0; j < a->n; j++)
      {
        x = mat[var + j];
        if((i + j) & 0x1)
          x = x / (1 + val);
        else
          x = x * val;

        
        x = x * mat[var + j];
        mat[var + j] = x;
      }
    }
}

void superslow7(smat_t *a)
{
    int i, j,len,var,var2,ind1,ind2,ind3,ind4;
    double *mat;
    double x,y,z,w,x1,y1,z1,w1,val,val2,sinval1,sinval2;
    len = a->n;
    mat = a->mat;
    
    for(i = 0; i < len; i+=2)
    { var = i*len;
      var2 = (i+1)*len;
      val = sin(M_PI/(i+1));
      sinval1 = 1 + val;
      sinval1 = 1/sinval1;
      val2 = sin(M_PI/(i+2));
      sinval2 = 1 + val2;
      sinval2 = 1/sinval2;
      for(j = 0; j < len; j+=2)
      {
        ind1 = var + j;
        ind2 = var2 + j;
        ind3 = var +j+1;
        ind4 = var2 + j+1;
        x = mat[ind1];
        y = mat[ind2];
        z = mat[ind3];
        w = mat[ind4];
        

        x1 = x * val;
        y1 = y * sinval2;
        z1 = z * sinval1;
        w1 = w * val2;
          
        
               
        x1 = x1 * x;
        y1 = y1 * y;
        z1 = z1 * z;
        w1 = w1 * w;
        
        mat[ind1] = x1;
        mat[ind2] = y1;
        mat[ind3] = z1;
        mat[ind4] = w1;
        
      }
    }
}

void superslow8(smat_t *a)
{
    int i, j,len,var,var2;
    double *mat;
    double x1,y1,z1,w1,val,val2;
    len = a->n;
    mat = a->mat;
    
    for(i = 0; i < len; i+=2)
    { var = i*len;
      var2 = (i+1)*len;
      val = sin(M_PI/(i+1));
      val2 = sin(M_PI/(i+2));
      for(j = 0; j < len; j+=2)
      {
            
        x1 = mat[var + j] * val;
        y1 = mat[var2 +j] / (1 + val2);
        z1 = mat[var +j+1] / (1 + val);
        w1 = mat[var2 +j+1] * val2;
          
        
               
        x1 = x1 * mat[var + j];
        y1 = y1 * mat[var2 +j];
        z1 = z1 * mat[var +j+1];
        w1 = w1 * mat[var2 +j+1];
        
        mat[var + j] = x1;
        mat[var2 + j] = y1;
        mat[var + j+1] = z1;
        mat[var2 + j+1] = w1;
        
      }
    }
}

void superslow9(smat_t *a)
{
    int i, j,len,var,var2;
    double *mat;
    double x,y,z,w,x1,y1,z1,w1,val,val2,sinval1,sinval2;
    len = a->n;
    mat = a->mat;

    for(i = 0; i < len; i+=2)
    { var = i*len;
      var2 = (i+1)*len;
      val = sin(M_PI/(i+1));
      sinval1 = 1/(1 + val);
    
      val2 = sin(M_PI/(i+2));
      sinval2 = 1/(1 + val2);
    
      for(j = 0; j < len; j+=2)
      {
        
     
        x = mat[var + j];
        y = mat[var2 + j];
        z = mat[var +j+1];
        w = mat[var2 + j+1];


        x1 = (x * val) * x;
        y1 = (y * sinval2) * y;
        z1 = (z * sinval1) * z;
        w1 = (w * val2) * w;


        mat[var + j] = x1;
        mat[var2 + j] = y1;
        mat[var +j+1] = z1;
        mat[var2 + j+1] = w1;

      }
    }
}

void superslow10(smat_t *a)
{
    register int i, j,len,var,var2;
    register double *mat;
    register double x1,y1,z1,w1,val,val2,sinval1,sinval2;
    len = a->n;
    mat = a->mat;

    for(i = 0; i < len; i+=2)
    { var = i*len;
      var2 = (i+1)*len;
      val = sin(M_PI/(i+1));
      sinval1 = 1/(1 + val);

      val2 = sin(M_PI/(i+2));
      sinval2 = 1/(1 + val2);

      for(j = 0; j < len; j+=2)
      {


        //x = mat[var + j];
        //y = mat[var2 + j];
        //z = mat[var +j+1];
        //w = mat[var2 + j+1];


        x1 = (mat[var + j] * val) * mat[var + j];
        y1 = (mat[var2 + j] * sinval2) * mat[var2 + j];
        z1 = (mat[var +j+1] * sinval1) * mat[var +j+1];
        w1 = (mat[var2 + j+1] * val2) * mat[var2 + j+1];


        mat[var + j] = x1;
        mat[var2 + j] = y1;
        mat[var +j+1] = z1;
        mat[var2 + j+1] = w1;

      }
    }
}

void superslow11(smat_t *a)
{
    register int i, j,len,var,var2;
    register double *mat;
    double x,y,z,w,val,val2,sinval1,sinval2;
    len = a->n;
    mat = a->mat;

    for(i = 0; i < len; i+=2)
    { var = i*len;
      var2 = (i+1)*len;
      val = sin(M_PI/(i+1));
      sinval1 = 1/(1 + val);

      val2 = sin(M_PI/(i+2));
      sinval2 = 1/(1 + val2);

      for(j = 0; j < len; j+=2)
      {


        x = mat[var + j];
        y = mat[var2 + j];
        z = mat[var +j+1];
        w = mat[var2 + j+1];

        mat[var + j] = (x * val) * x;
        mat[var2 + j] = (y * sinval2) * y;
        mat[var +j+1] = (z * sinval1) * z;
        mat[var2 + j+1] = (w * val2) * w;

      }
    }
}

void superslow12(smat_t *a)
{
    int i, j,len,var,var2;
    double *mat;
    double val,val2,sinval1,sinval2;
    len = a->n;
    mat = a->mat;

    for(i = 0; i < len; i+=2)
    { var = i*len;
      var2 = (i+1)*len;
      val = sin(M_PI/(i+1));
      sinval1 = 1/(1 + val);

      val2 = sin(M_PI/(i+2));
      sinval2 = 1/(1 + val2);

      for(j = 0; j < len; j+=2)
      {


        //x = mat[var + j];
        //y = mat[var2 + j];
        //z = mat[var +j+1];
        //w = mat[var2 + j+1];

        mat[var + j] = (mat[var + j] * val) * mat[var + j];
        mat[var2 + j] = (mat[var2 + j] * sinval2) * mat[var2 + j];
        mat[var +j+1] = (mat[var +j+1] * sinval1) * mat[var +j+1];
        mat[var2 + j+1] = (mat[var2 + j+1] * val2) * mat[var2 + j+1];

      }
    }
}

void superslow13(smat_t *a)
{
    register int i, j,len,var,var2;
    register double *mat;
    register double x,y,z,w,p,q,r,s,val,val2,sinval1,sinval2;
    len = a->n;
    mat = a->mat;

    for(i = 0; i < len; i+=2)
    { var = i*len;
      var2 = (i+1)*len;
      val = sin(M_PI/(i+1));
      sinval1 = 1/(1 + val);                               

      val2 = sin(M_PI/(i+2));
      sinval2 = 1/(1 + val2);

      for(j = 0; j < len; j+=4)
      {


        x = mat[var + j];
        y = mat[var2 + j];
        z = mat[var +j+1];
        w = mat[var2 + j+1];

        p = mat[var + j+2];
        q = mat[var2 + j+2];
        r = mat[var + j+3];
        s = mat[var2 + j+3];

        mat[var + j] = (mat[var + j] * val) * mat[var + j];
        mat[var2 + j] = (mat[var2 + j] * sinval2) * mat[var2 + j];
        mat[var +j+1] = (mat[var +j+1] * sinval1) * mat[var +j+1];
        mat[var2 + j+1] = (mat[var2 + j+1] * val2) * mat[var2 + j+1];

        mat[var + j+2] = (mat[var + j+2] * val) * mat[var + j+2];
        mat[var2 + j+2] = (mat[var2 + j+2] * sinval2) * mat[var2 + j+2];
        mat[var + j+3] = (mat[var + j+3] * sinval1) * mat[var + j+3];
        mat[var2 + j+3] = (mat[var2 + j+3] * val2) * mat[var2 + j+3];

      }
    }
}

void superslow14(smat_t *a)
{
    int i, j,len,var,var2;
    double *mat,*x,*y;
    double val,val2,sinval1,sinval2;
    len = a->n;
    mat = a->mat;

    for(i = 0; i < len; i+=2)
    { var = i*len;
      var2 = (i+1)*len;
      val = sin(M_PI/(i+1));
      sinval1 = 1/(1 + val);

      val2 = sin(M_PI/(i+2));
      sinval2 = 1/(1 + val2);

      for(j = 0; j < len; j+=2)
      {


        x = &mat[var + j];
        y = &mat[var2 + j];
        
        mat[var + j] = (*x * val) * *x;
        mat[var2 + j] = (*y * sinval2) * *y;
        mat[var +j+1] = (*(x+1) * sinval1) * *(x+1);
        mat[var2 + j+1] = (*(y+1) * val2) * *(y+1);

      }
   }
}

void superslow15(smat_t *a)
{
    int i, j,len,var,var2;
    double *mat,*x,*y;
    double val,val2,sinval1,sinval2;
    len = a->n;
    mat = a->mat;

    for(i = 0; i < len; i+=2)
    { var = i*len;
      var2 = (i+1)*len;
      val = sin(M_PI/(i+1));
      sinval1 = 1/(1 + val);

      val2 = sin(M_PI/(i+2));
      sinval2 = 1/(1 + val2);

      for(j = 0; j < len; j+=4)
      {


        x = &mat[var + j];
        y = &mat[var2 + j];

        mat[var + j] = (*x * val) * *x;
        mat[var2 + j] = (*y * sinval2) * *y;
        mat[var +j+1] = (*(x+1) * sinval1) * *(x+1);
        mat[var2 + j+1] = (*(y+1) * val2) * *(y+1);
        

        mat[var + j+2] = (*(x+2) * val ) * *(x+2);
        mat[var2 + j+ 2] = (*(y+2) * sinval2) * *(y+2);
        mat[var + j+3] = (*(x+3) * sinval1) * *(x+3);
        mat[var2 + j+3] = (*(y+3) * val2) * *(y+3);

      }
   }
}

void superslow16(smat_t *a)
{
    int i, j,len,var,var2;
    double *mat,*x,*y;
    double val,val2,sinval1,sinval2;
    len = a->n;
    mat = a->mat;

    for(i = 0; i < len; i+=2)
    { var = i*len;
      var2 = (i+1)*len;
      val = sin(M_PI/(i+1));
      sinval1 = 1/(1 + val);

      val2 = sin(M_PI/(i+2));
      sinval2 = 1/(1 + val2);

      for(j = 0; j < len; j+=10)
      {


        x = &mat[var + j];
        y = &mat[var2 + j];

        mat[var + j] = (*x * val) * *x;
        mat[var2 + j] = (*y * sinval2) * *y;
        mat[var +j+1] = (*(x+1) * sinval1) * *(x+1);
        mat[var2 + j+1] = (*(y+1) * val2) * *(y+1);
        

        mat[var + j+2] = (*(x+2) * val ) * *(x+2);
        mat[var2 + j+ 2] = (*(y+2) * sinval2) * *(y+2);
        mat[var + j+3] = (*(x+3) * sinval1) * *(x+3);
        mat[var2 + j+3] = (*(y+3) * val2) * *(y+3);


        mat[var + j+4] = (*(x+4) * val ) * *(x+4);
        mat[var2 + j+ 4] = (*(y+4) * sinval2) * *(y+4);
        mat[var + j+5] = (*(x+5) * sinval1) * *(x+5);
        mat[var2 + j+5] = (*(y+5) * val2) * *(y+5);


        mat[var + j+6] = (*(x+6) * val ) * *(x+6);
        mat[var2 + j+ 6] = (*(y+6) * sinval2) * *(y+6);
        mat[var + j+7] = (*(x+7) * sinval1) * *(x+7);
        mat[var2 + j+7] = (*(y+7) * val2) * *(y+7);


        mat[var + j+8] = (*(x+8) * val ) * *(x+8);
        mat[var2 + j+ 8] = (*(y+8) * sinval2) * *(y+8);
        mat[var + j+9] = (*(x+9) * sinval1) * *(x+9);
        mat[var2 + j+9] = (*(y+9) * val2) * *(y+9);

      }
   }
}

void superslow17(smat_t *a)
{
    register int i, j,len,var,var2;
    register double *mat,*x,*y;
    register double val,val2,sinval1,sinval2;
    len = a->n;
    mat = a->mat;

    for(i = 0; i < len; i+=2)
    { 
      var = i*len;
      var2 = (i+1)*len;
      val = sin(M_PI/(i+1));
      sinval1 = 1/(1 + val);

      val2 = sin(M_PI/(i+2));
      sinval2 = 1/(1 + val2);

      for(j = 0; j < len; j+=12)
      {


        x = &mat[var + j];
        y = &mat[var2 + j];

        mat[var + j] = (*x * val) * *x;
        mat[var2 + j] = (*y * sinval2) * *y;
        mat[var +j+1] = (*(x+1) * sinval1) * *(x+1);
        mat[var2 + j+1] = (*(y+1) * val2) * *(y+1);
        

        mat[var + j+2] = (*(x+2) * val ) * *(x+2);
        mat[var2 + j+ 2] = (*(y+2) * sinval2) * *(y+2);
        mat[var + j+3] = (*(x+3) * sinval1) * *(x+3);
        mat[var2 + j+3] = (*(y+3) * val2) * *(y+3);


        mat[var + j+4] = (*(x+4) * val ) * *(x+4);
        mat[var2 + j+ 4] = (*(y+4) * sinval2) * *(y+4);
        mat[var + j+5] = (*(x+5) * sinval1) * *(x+5);
        mat[var2 + j+5] = (*(y+5) * val2) * *(y+5);


        mat[var + j+6] = (*(x+6) * val ) * *(x+6);
        mat[var2 + j+ 6] = (*(y+6) * sinval2) * *(y+6);
        mat[var + j+7] = (*(x+7) * sinval1) * *(x+7);
        mat[var2 + j+7] = (*(y+7) * val2) * *(y+7);


        mat[var + j+8] = (*(x+8) * val ) * *(x+8);
        mat[var2 + j+ 8] = (*(y+8) * sinval2) * *(y+8);
        mat[var + j+9] = (*(x+9) * sinval1) * *(x+9);
        mat[var2 + j+9] = (*(y+9) * val2) * *(y+9);

        mat[var + j+10] = (*(x+10) * val ) * *(x+10);
        mat[var2 + j+ 10] = (*(y+10) * sinval2) * *(y+10);
        mat[var + j+11] = (*(x+11) * sinval1) * *(x+11);
        mat[var2 + j+11] = (*(y+11) * val2) * *(y+11);


      }
   }
}

void superslow18(smat_t *a)
{
    register int i, j,len,var,var2;
    register double *mat,*x,*y;
    register double val,val2,sinval1,sinval2;
    len = a->n;
    mat = a->mat;

    for(i = 0; i < len; i+=2)
    { var = i*len;
      var2 = (i+1)*len;
      val = sin(M_PI/(i+1));
      sinval1 = 1/(1 + val);

      val2 = sin(M_PI/(i+2));
      sinval2 = 1/(1 + val2);

      for(j = 0; j < len; j+=20)
      {


        x = &mat[var + j];
        y = &mat[var2 + j];

        mat[var + j] = (*x * val) * *x;
        mat[var2 + j] = (*y * sinval2) * *y;
        mat[var +j+1] = (*(x+1) * sinval1) * *(x+1);
        mat[var2 + j+1] = (*(y+1) * val2) * *(y+1);
        

        mat[var + j+2] = (*(x+2) * val ) * *(x+2);
        mat[var2 + j+ 2] = (*(y+2) * sinval2) * *(y+2);
        mat[var + j+3] = (*(x+3) * sinval1) * *(x+3);
        mat[var2 + j+3] = (*(y+3) * val2) * *(y+3);


        mat[var + j+4] = (*(x+4) * val ) * *(x+4);
        mat[var2 + j+ 4] = (*(y+4) * sinval2) * *(y+4);
        mat[var + j+5] = (*(x+5) * sinval1) * *(x+5);
        mat[var2 + j+5] = (*(y+5) * val2) * *(y+5);


        mat[var + j+6] = (*(x+6) * val ) * *(x+6);
        mat[var2 + j+ 6] = (*(y+6) * sinval2) * *(y+6);
        mat[var + j+7] = (*(x+7) * sinval1) * *(x+7);
        mat[var2 + j+7] = (*(y+7) * val2) * *(y+7);


        mat[var + j+8] = (*(x+8) * val ) * *(x+8);
        mat[var2 + j+ 8] = (*(y+8) * sinval2) * *(y+8);
        mat[var + j+9] = (*(x+9) * sinval1) * *(x+9);
        mat[var2 + j+9] = (*(y+9) * val2) * *(y+9);

        mat[var + j+10] = (*(x+10) * val ) * *(x+10);
        mat[var2 + j+ 10] = (*(y+10) * sinval2) * *(y+10);
        mat[var + j+11] = (*(x+11) * sinval1) * *(x+11);
        mat[var2 + j+11] = (*(y+11) * val2) * *(y+11);

        mat[var + j+12] = (*(x+12) * val ) * *(x+12);
        mat[var2 + j+ 12] = (*(y+12) * sinval2) * *(y+12);
        mat[var + j+13] = (*(x+13) * sinval1) * *(x+13);
        mat[var2 + j+13] = (*(y+13) * val2) * *(y+13);

        mat[var + j+14] = (*(x+14) * val ) * *(x+14);
        mat[var2 + j+ 14] = (*(y+14) * sinval2) * *(y+14);
        mat[var + j+15] = (*(x+15) * sinval1) * *(x+15);
        mat[var2 + j+15] = (*(y+15) * val2) * *(y+15);

        mat[var + j+16] = (*(x+16) * val ) * *(x+16);
        mat[var2 + j+ 16] = (*(y+16) * sinval2) * *(y+16);
        mat[var + j+17] = (*(x+17) * sinval1) * *(x+17);
        mat[var2 + j+17] = (*(y+17) * val2) * *(y+17);

        mat[var + j+18] = (*(x+18) * val ) * *(x+18);
        mat[var2 + j+ 18] = (*(y+18) * sinval2) * *(y+18);
        mat[var + j+19] = (*(x+19) * sinval1) * *(x+19);
        mat[var2 + j+19] = (*(y+19) * val2) * *(y+19);
    
 
      }
   }
}

void superslow19(smat_t *a)
{
    register int i, j,len,var,var2,var3,var4;
    register double *mat,*x,*y,*z,*w;
    double val,val2,val3,val4,sinval1,sinval2,sinval3,sinval4;
    len = a->n;
    mat = a->mat;

    for(i = 0; i < len; i+=4)
    { var = i*len;
      var2 = (i+1)*len;
      var3 = (i+2)* len;
      var4 = (i+3)*len;
      val = sin(M_PI/(i+1));
      sinval1 = 1/(1 + val);

      val2 = sin(M_PI/(i+2));
      sinval2 = 1/(1 + val2);

      val3 = sin(M_PI/(i+3));
      sinval3 = 1/(1 + val3);

      val4 = sin(M_PI/(i+4));
      sinval4 = 1/(1 + val4);

      for(j = 0; j < len; j+=4)
      {


        x = &mat[var + j];
        y = &mat[var2 + j];
        z = &mat[var3 + j];
        w = &mat[var4 + j];

        mat[var + j] = (*x * val) * *x;
        mat[var2 + j] = (*y * sinval2) * *y;
        mat[var +j+1] = (*(x+1) * sinval1) * *(x+1);
        mat[var2 + j+1] = (*(y+1) * val2) * *(y+1);

        mat[var3 + j] = (*z * val3) * *z;
        mat[var4 + j] = (*w * sinval4) * *w;
        mat[var3 +j+1] = (*(z+1) * sinval3) * *(z+1);
        mat[var4 + j+1] = (*(w+1) * val4) * *(w+1);

        mat[var + j+2] = (*(x+2) * val ) * *(x+2);
        mat[var2 + j+ 2] = (*(y+2) * sinval2) * *(y+2);
        mat[var + j+3] = (*(x+3) * sinval1) * *(x+3);
        mat[var2 + j+3] = (*(y+3) * val2) * *(y+3);

        mat[var3 + j+2] = (*(z+2) * val3 ) * *(z+2);
        mat[var4 + j+ 2] = (*(w+2) * sinval4) * *(w+2);
        mat[var3 + j+3] = (*(z+3) * sinval3) * *(z+3);
        mat[var4 + j+3] = (*(w+3) * val4) * *(w+3);

      }
   }
}

void superslow20(smat_t *a)
{
    register int i, j,len,var,var2;
    register double *mat,*x,*y;
    register double val,val2,sinval1,sinval2;
    len = a->n;
    mat = a->mat;

    for(i = 0; i < len; i+=2)
    { var = i*len;
      var2 = (i+1)*len;
      val = sin(M_PI/(i+1));
      sinval1 = 1/(1 + val);

      val2 = sin(M_PI/(i+2));
      sinval2 = 1/(1 + val2);
 
      x = &mat[var];
      y = &mat[var2];

      for(j = 0; j < len; j+=2)
      {

        mat[var + j] = (*(x+j) * val) * *(x+j);
        mat[var2 + j] = (*(y+j) * sinval2) * *(y+j);
        mat[var +j+1] = (*(x+j+1) * sinval1) * *(x+j+1);
        mat[var2 + j+1] = (*(y+j+1) * val2) * *(y+j+1);

      }
   }
}

void superslow21(smat_t *a)
{
    register int i, j,len,var,var2;
    register double *mat,*x,*y;
    register double val,val2,sinval1,sinval2;
    len = a->n;
    mat = a->mat;

    for(i = 0; i < len; i+=2)
    { var = i*len;
      var2 = (i+1)*len;
      val = sin(M_PI/(i+1));
      sinval1 = 1/(1 + val);

      val2 = sin(M_PI/(i+2));
      sinval2 = 1/(1 + val2);

        x = &mat[var];
        y = &mat[var2];

      for(j = 0; j < len; j+=20)
      {

        mat[var + j] = (*(x+j) * val) * *(x+j);
        mat[var2 + j] = (*(y+j) * sinval2) * *(y+j);
        mat[var +j+1] = (*(x+j+1) * sinval1) * *(x+j+1);
        mat[var2 + j+1] = (*(y+j+1) * val2) * *(y+j+1);


        mat[var + j+2] = (*(x+j+2) * val ) * *(x+j+2);
        mat[var2 + j+ 2] = (*(y+j+2) * sinval2) * *(y+j+2);
        mat[var + j+3] = (*(x+j+3) * sinval1) * *(x+j+3);
        mat[var2 + j+3] = (*(y+j+3) * val2) * *(y+j+3);


        mat[var + j+4] = (*(x+j+4) * val ) * *(x+j+4);
        mat[var2 + j+ 4] = (*(y+j+4) * sinval2) * *(y+j+4);
        mat[var + j+5] = (*(x+j+5) * sinval1) * *(x+j+5);
        mat[var2 + j+5] = (*(y+j+5) * val2) * *(y+j+5);

        mat[var + j+6] = (*(x+j+6) * val ) * *(x+j+6);
        mat[var2 + j+ 6] = (*(y+j+6) * sinval2) * *(y+j+6);
        mat[var + j+7] = (*(x+j+7) * sinval1) * *(x+j+7);
        mat[var2 + j+7] = (*(y+j+7) * val2) * *(y+j+7);


        mat[var + j+8] = (*(x+j+8) * val ) * *(x+j+8);
        mat[var2 + j+ 8] = (*(y+j+8) * sinval2) * *(y+j+8);
        mat[var + j+9] = (*(x+j+9) * sinval1) * *(x+j+9);
        mat[var2 + j+9] = (*(y+j+9) * val2) * *(y+j+9);

        mat[var + j+10] = (*(x+j+10) * val ) * *(x+j+10);
        mat[var2 + j+ 10] = (*(y+j+10) * sinval2) * *(y+j+10);
        mat[var + j+11] = (*(x+j+11) * sinval1) * *(x+j+11);
        mat[var2 + j+11] = (*(y+j+11) * val2) * *(y+j+11);

        mat[var + j+12] = (*(x+j+12) * val ) * *(x+j+12);
        mat[var2 + j+ 12] = (*(y+j+12) * sinval2) * *(y+j+12);
        mat[var + j+13] = (*(x+j+13) * sinval1) * *(x+j+13);
        mat[var2 + j+13] = (*(y+j+13) * val2) * *(y+j+13);

        mat[var + j+14] = (*(x+j+14) * val ) * *(x+j+14);
        mat[var2 + j+ 14] = (*(y+j+14) * sinval2) * *(y+j+14);
        mat[var + j+15] = (*(x+j+15) * sinval1) * *(x+j+15);
        mat[var2 + j+15] = (*(y+j+15) * val2) * *(y+j+15);

        mat[var + j+16] = (*(x+j+16) * val ) * *(x+j+16);
        mat[var2 + j+ 16] = (*(y+j+16) * sinval2) * *(y+j+16);
        mat[var + j+17] = (*(x+j+17) * sinval1) * *(x+j+17);
        mat[var2 + j+17] = (*(y+j+17) * val2) * *(y+j+17);

        mat[var + j+18] = (*(x+j+18) * val ) * *(x+j+18);
        mat[var2 + j+ 18] = (*(y+j+18) * sinval2) * *(y+j+18);
        mat[var + j+19] = (*(x+j+19) * sinval1) * *(x+j+19);
        mat[var2 + j+19] = (*(y+j+19) * val2) * *(y+j+19);


      }
   }
}
/* 
 * Called by the driver to register your functions
 * Use add_function(func, description) to add your own functions
 */
void register_functions()
{
    // Registers comp_superslow with the driver
    add_function(&superslow, "superslow: original function");
    add_function(&superslow2,"superslow2:modified function");
    add_function(&superslow3,"superslow3:the get and set functions are removed");
    add_function(&superslow4,"superslow4:the var = i* len was added ");
    add_function(&superslow5,"superslow5:the f function was removed ");
    add_function(&superslow6,"superslow6:in the f function the constant was kept outside ");
    add_function(&superslow7,"superslow7:the if statement was removed ");
    add_function(&superslow8,"superslow8:the if statement extra variable  was removed ");
    add_function(&superslow9,"superslow9:the if statement was removed ");
    add_function(&superslow10,"superslow10:the if stmt and some vars were removed ");
    add_function(&superslow11,"superslow11:the if stmt and x1 vars were removed ");
    add_function(&superslow12,"superslow12:the if stmt and x1 vars and x vars were removed ");
    add_function(&superslow13,"superslow13:the if stmt 4 way unroll ");
    add_function(&superslow14,"superslow14:the if stmt with pointers ");
    add_function(&superslow15,"superslow15:the if stmt with pointers and 4 way unroll ");
    add_function(&superslow16,"superslow16:the if stmt with pointers and 10 way unroll ");
    add_function(&superslow17,"superslow17:the if stmt with pointers and 12 way unroll ");
    add_function(&superslow18,"superslow18:the if stmt with pointers and 20 way unroll ");
    add_function(&superslow19,"superslow19:the if stmt with pointers and 20 way unroll and i loop 4 way");
    add_function(&superslow20,"superslow20:the if stmt with pointers in i loop ");
    add_function(&superslow20,"superslow21:the if stmt with pointers in i loop 20 way ");
	//Add your functions here
	//add_function(&superslow2, "superslow: Optimization X");
	
	
}
