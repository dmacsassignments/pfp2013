#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define n 2000
#define m 3000

void main()
{
  double **a, **b,*p,*q, *c,*d, norm,norm1,norm2,norm3,norm4,norm5,norm6,norm7,norm8;
  int i, j, l, limit,size;
  size = m*sizeof(double);
  a = (double**)malloc(n*sizeof(double*));
  b = (double**)malloc(n*sizeof(double*));

  for(i=0; i<n; i++)
    {
      a[i] = (double*)malloc(size);
      for(j=0; j<n; j++) a[i][j] = drand48();b[i] = (double*)calloc(m, sizeof(double));
    }
    
//  for(i=0; i<n; i++) b[i] = (double*)calloc(m, sizeof(double));
 
  //c = 13.0;

  //for(l=1; l<=30; l++)
  for(i=0;i<n;i++)
  {            
          p = b[i];
           q = a[i];
  for(l=1; l<=30; l++)
     {
        for(j=0;j<m;j+=8)
        {
              c = p + j;
              d = q + j;              
	      b[i][j] = 13.0 * (*c)+(*d);
	      b[i][j+1] = 13.0 * *(c+1) - *(c+1);
  	      b[i][j+2] = 13.0 * *(c+2) + *(d+2);
              b[i][j+3] = 13.0 * *(c+3) - *(d+3);
              b[i][j+4] = 13.0 * *(c+4) + *(d+4);
              b[i][j+5] = 13.0 * *(c+5) - *(d+5);
              b[i][j+6] = 13.0 * *(c+6) + *(d+6);
              b[i][j+7] = 13.0 * *(c+7) - *(d+7);
        }   
     }
  }  
  limit = m-(m%8);
  norm = 0.0;
  norm1 = norm2 = norm3 = norm4 = norm5 = norm6 = norm7 = norm8 =0.0;
  for(i=0; i<n; i++)
  {
    for(j=0; j<m; j+=6)
    {
      norm1 = norm1 + fabs(b[i][j]*b[i][j]);
      norm2 = norm2 + fabs(b[i][j+1]*b[i][j+1]);
      norm3 = norm3 + fabs(b[i][j+2]*b[i][j+2]);
      norm4 = norm4 + fabs(b[i][j+3]*b[i][j+3]);
      norm5 = norm5 + fabs(b[i][j+4]*b[i][j+4]);
      norm6 = norm6 + fabs(b[i][j+5]*b[i][j+5]);
      norm7 = norm7 + fabs(b[i][j+6]*b[i][j+6]);
      norm8 = norm8 + fabs(b[i][j+7]*b[i][j+7]);
 
    }
    //norm = norm1 + norm2 + norm3 + norm4;
  //printf("%d\n",j);  
  for(;j<m;j++)
    norm = norm + fabs(b[i][j]*b[i][j]);
  }
    norm = norm + norm1 + norm2 + norm3 + norm4 + norm5 + norm6;
  printf("norm: %10.4e    Value: %10.4e\n",norm, b[10][10]);
}
