#include <stdio.h>
#include<stdlib.h>
#include <math.h>
#include "rdtsc.h"

#define N 10000
#define NUM_RUNS 50

int main()
{
        int * buffer;
        tsc_counter a, b;
        int i;
        long int a0,a1,a2,a3;
        long int sum=0;
        long int sum_func = 0;
        double cycles;
        sum_func=a0=a1=a2=a3=0;
        buffer = (int*) malloc(sizeof(int)*N);

        for ( i = 0; i<N; i++){
                        buffer[i] = rand();
        }
         
        for( i=0; i<N; ++i)
        {
                sum += buffer[i];
        }


        CPUID(); RDTSC(a); CPUID(); RDTSC(b);
        CPUID(); RDTSC(a); CPUID(); RDTSC(b);

        RDTSC(a);
        
        for(i=0;i<N;i+=4)
        {
           a0 += buffer[i];
           a1 += buffer[i+1];
           a2 += buffer[i+2];
           a3 += buffer[i+3];
        }
        sum_func = a0+a1+a2+a3;
        RDTSC(b);
        cycles = ((double)COUNTER_DIFF(b, a));
        printf("Sum is %ld\n",sum);
        printf("Sum function is %ld\n",sum_func);
        printf("%lf cycles\n ",cycles);
}
