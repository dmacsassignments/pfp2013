/*
* comp.c - contains the function superslow that you need to optimize
*
*
*/

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


/* f(x1,x2, i, j) rotates the input vector
*/
double f(double x1, double x2, double* y1, double * y2, int i, int j)
{
	double m[2][2];	

	if (i %4 == 0)
	{
		m[0][0] = cos(i);
		m[0][1] = sin(i);
		m[1][0] = -sin(i);
		m[1][1] = cos(i);
	}
	else
	{
		m[0][0] = cos(-i);
		m[0][1] = sin(-i);
		m[1][0] = -sin(-i);
		m[1][1] = cos(-i);

	}

	*y1 = m[0][0] * x1 + m[0][1]* x2;
	*y2 = m[1][0] * x1 + m[1][1]* x2;
}

/* This is the function you need to optimize. It takes one
square matrix as input
*/
void superslow(smat_t *a)
{
	int i, j;
	double x1,x2,y1,y2;
	double sum1, sum2;


	// j is the column of a we're computing right now
	for(j = 0; j < a->n; j++)
	{

		// i is the row of a we're computing right now
		for(i = 0; i < a->n; i=i+2)        
		{            
			// First, compute f(A) for the element of a in question
			x1 = get_elt(a,i,j);
			x2 = get_elt(a,i+1,j);
			f(x1,x2,&y1,&y2, i, j);

			// Add this to the value of a we're computing and store it                
			sum1 = get_elt(a, i, j) + y1;
			sum2 = get_elt(a, i+1, j) + y2;
			set_elt(a, i, j, sum1);
			set_elt(a, i+1, j, sum2);            
		}
	}
}


void superslow1(smat_t *a)
{
	int i, j;
	double x1,x2,y1,y2;
	double sum1, sum2;


	// j is the column of a we're computing right now
	for(i = 0; i < a->n; i+=2)
	{

		// i is the row of a we're computing right now
		for(j = 0; j < a->n; j++)        
		{            
			// First, compute f(A) for the element of a in question
			x1 = get_elt(a,i,j);
			x2 = get_elt(a,i+1,j);
			f(x1,x2,&y1,&y2, i, j);

			// Add this to the value of a we're computing and store it                
			sum1 = get_elt(a, i, j) + y1;
			sum2 = get_elt(a, i+1, j) + y2;
			set_elt(a, i, j, sum1);
			set_elt(a, i+1, j, sum2);            
		}
	}
}


void superslow2(smat_t *a)
{
	int i, j;
	double x1,x2,y1,y2;
	double sum1, sum2;
        double *mat = a->mat;
        int n = a->n;
	// j is the column of a we're computing right now
	for(i = 0; i < n; i+=2)
	{
              register double* mat1 = mat+(i*n);
              register double* mat2 = mat+(i+1)*n;
		// i is the row of a we're computing right now
		for(j = n; j > 0; j--)        
		{            
			// First, compute f(A) for the element of a in question
			//x1 = mat[i*n+j];
			x1 = *mat1;
			x2 = *mat2;
			f(x1,x2,&y1,&y2, i, j);

			// Add this to the value of a we're computing and store it                
			sum1 = x1 + y1;
			sum2 = x2 + y2;
			
			*mat1++ = sum1;
			*mat2++ = sum2;            
		}
	}
}

 
void superslow3(smat_t *a)
{
	int i, j;
	double y3,y4,y1,y2;
	double sum1, sum2;
        double *mat = a->mat;
        int n = a->n;
	// j is the column of a we're computing right now
	for(i = 0; i < n; i+=4)
	{    register double m00 = cos(i);
             register double m01 = sin(i);
             register double n00 = cos(-i);
             register double n01 = sin(-i);
             
             register double* mat1 = mat+(i*n);
             register double* mat2 = mat+(i+1)*n;
             register double* mat3 = mat+(i+2)*n;
             register double* mat4 = mat+(i+3)*n;
                  

		// i is the row of a we're computing right now
		for(j = 0; j < n; j++)        
		{            
			// First, compute f(A) for the element of a in question
			register double x1 = *mat1;
			register double x2 = *mat2;
                        register double x3 = *mat3;
                        register double x4 = *mat4;
                               
                 /*       register double y1 = m00*x1 + m01*x2;
                        register double y2 = (-m01)*x1 + m00*x2;

			
                        register double y3 = n00*x3 + n01*x4;
                        register double y4 = (-n01)*x3 + n00*x4;*/
                       f(x1,x2,&y1,&y2,i,j);
                        f(x3,x4,&y3,&y4,i+2,j);
                     
			// Add this to the value of a we're computing and store it                
			//sum1 = x1 + y1;
			//sum2 = x2 + y2;
			
			*mat1++ = x1 + y1;
			*mat2++ = x2 + y2;            
                        *mat3++ = x3 + y3;
                        *mat4++ = x4 + y4;
		}      
	}
}



/*
* Called by the driver to register your functions
* Use add_function(func, description) to add your own functions
*/
void register_functions()
{
	// Registers comp_superslow with the driver
	add_function(&superslow, "superslow: original function");
	add_function(&superslow1, "superslow1: loops permutated");
	add_function(&superslow2, "superslow2: function calls to get-elt and set-elt removed");
	add_function(&superslow3, "superslow2: function call to f removed and outer loop is unrolled ");
//	add_function(&fast, "fast: optimized version 1");
	//Add your functions here
	//add_function(&superslow2, "superslow: Optimization X");


}
