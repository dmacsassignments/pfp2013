/*
* comp.c - contains the function superslow that you need to optimize
*
*
*/

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"
#include<immintrin.h>
#include<nmmintrin.h>

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


/* f(x1,x2, i, j) rotates the input vector
*/
double f(double x1, double x2, double* y1, double * y2, int i, int j)
{
	double m[2][2];

	if (i %4 == 0)
	{
		m[0][0] = cos(i);
		m[0][1] = sin(i);
		m[1][0] = -sin(i);
		m[1][1] = cos(i);
	}
	else
	{
		m[0][0] = cos(i);
		m[0][1] = -sin(i);
		m[1][0] = sin(i);
		m[1][1] = cos(i);

	}

	*y1 = x1*m[0][0] + x2*m[0][1];
	*y2 = m[1][1] * x2 + m[1][0]* x1;
}

/* This is the function you need to optimize. It takes one
square matrix as input
*/
void superslow(smat_t *a)
{
	int i, j;
	double x1,x2,y1,y2;
	double sum1, sum2;


	// j is the column of a we're computing right now
	for(j = 0; j < a->n; j++)
	{

		// i is the row of a we're computing right now
		for(i = 0; i < a->n; i=i+2)
		{
			// First, compute f(A) for the element of a in question
			x1 = get_elt(a,i,j);
			x2 = get_elt(a,i+1,j);
			f(x1,x2,&y1,&y2, i, j);

			// Add this to the value of a we're computing and store it
			sum1 = get_elt(a, i, j) + y1;
			sum2 = get_elt(a, i+1, j) + y2;
			set_elt(a, i, j, sum1);
			set_elt(a, i+1, j, sum2);
		}
	}
}
void superslow_firstopt(smat_t *A)
{
	int i, j,n=A->n;
	//double x1,x2,*y1,*y2,x3,x4,*y3,*y4;
	double sum1, sum2;
        double *a = A->mat;

	// j is the column of a we're computing right now
	//for(j = 0; j <n; j++)
	//{

		// i is the row of a we're computing right now
		for(i = 0; i < n; i=i+4)
		{ double cosi = cos(i)+1,sini=sin(i),cosi1=cos(i+2)+1,sini1=sin(i+2);
                   double  *y1=a+i*n,*y2=a+(i+1)*n;
                   double  *y3=y1+n+n,*y4=y2+n+n;
                   #pragma(vector always)
	           for(j = 0; j <n; j++)
	             {
			// First, compute f(A) for the element of a in question
			const double x1 =*y1;

			const double x2 = *y2;

			const double x3 =*y3;

			const double x4 = *y4;

			/*f(x1,x2,&y1,&y2, i, j);

			// Add this to the value of a we're computing and store it
			a[i*n+j] =y1 + x1;
			a[i*n+n+j] = x2 + y2;
			//a[i*n+ j]= sum1;
			//a[(i+1)*n+ j]= sum2;
                        */
                        //if(i%4==0){
                        *y1 = x1*cosi+x2*sini;y1++;

                        *y2 =x2*cosi-x1*sini;y2++;

                        //}else{
                        *y3 = x3*cosi1-x4*sini1;y3++;

                        *y4 = x4*cosi1+x3*sini1; y4++;


		}
	}
}

void superslow_unroll(smat_t *A)
{
	int i, j,n=A->n;
	//double x1,x2,*y1,*y2,x3,x4,*y3,*y4;
	double sum1, sum2;
        double *a = A->mat;

	// j is the column of a we're computing right now
	//for(j = 0; j <n; j++)
	//{

		// i is the row of a we're computing right now
		for(i = 0; i < n; i=i+4)
		{ double cosi = cos(i)+1,sini=sin(i),cosi1=cos(i+2)+1,sini1=sin(i+2);
                   double  *y1=a+i*n,*y2=a+(i+1)*n;
                   double  *y3=y1+n+n,*y4=y2+n+n;
                   #pragma(vector always)
	           for(j = 0; j <n; j+=4)
	             {
			// First, compute f(A) for the element of a in question
			const double x11 =*y1;
			const double x12 =*(y1+1);
			const double x13 =*(y1+2);
			const double x14 =*(y1+3);
			const double x21 = *y2;
			const double x22 = *(y2+1);
			const double x23 = *(y2+2);
			const double x24 = *(3+y2);
			const double x31 =*y3;
			const double x32 =*(y3+1);
			const double x33 =*(y3+2);
			const double x34 =*(y3+3);
			const double x41 = *y4;
			const double x42 = *(y4+1);
			const double x43 = *(y4+2);
			const double x44 = *(y4+3);
			/*f(x1,x2,&y1,&y2, i, j);

			// Add this to the value of a we're computing and store it
			a[i*n+j] =y1 + x1;
			a[i*n+n+j] = x2 + y2;
			//a[i*n+ j]= sum1;
			//a[(i+1)*n+ j]= sum2;
                        */
                        //if(i%4==0){
                        *y1 = x11*cosi+x21*sini;y1++;
                        *y1 = x12*cosi+x22*sini;y1++;
                        *y1 = x13*cosi+x23*sini;y1++;
                        *y1 = x14*cosi+x24*sini;y1++;
                        *y2 =x21*cosi-x11*sini;y2++;
                        *y2 =x22*cosi-x12*sini;y2++;
                        *y2 =x23*cosi-x13*sini;y2++;
                        *y2 =x24*cosi-x14*sini;y2++;
                        //}else{
                        *y3 = x31*cosi1-x41*sini1;y3++;
                        *y3 = x32*cosi1-x42*sini1;y3++;
                        *y3 = x33*cosi1-x43*sini1;y3++;
                        *y3 = x34*cosi1-x44*sini1;y3++;
                        *y4 = x41*cosi1+x31*sini1; y4++;
                        *y4 = x42*cosi1+x32*sini1; y4++;
                        *y4 = x43*cosi1+x33*sini1; y4++;
                        *y4 = x44*cosi1+x34*sini1; y4++;

		}
	}
}



void superslow_vector(smat_t *A)
{
	 int i, j,n=A->n;
	//double x1,x2,*y1,*y2,x3,x4,*y3,*y4;
	//double *temp;
        double *a = A->mat;
        register double *y1 = a;
        register double *y2 = a+n;
        register double *y3 = y1+n+n;
        register double *y4 = y2+n+n;

	// j is the column of a we're computing right now
	//for(j = 0; j <n; j+=4)
	//{
	  // for(i=0;i<n;i+=2){
	    //     temp[i]=cos(i)+1;
	      //  temp[i+1]=sin(i); }

		// i is the row of a we're computing right now
		for(i = 0; i < n; i=i+4)
		{   double cosi = cos(i)+1,sini=sin(i),cosi1=cos(i+2)+1,sini1=sin(i+2);
                  __m256d c11 = _mm256_set1_pd(cosi);
                  __m256d c12 = _mm256_set1_pd(cosi);
                  __m256d s11 = _mm256_set1_pd(sini);
                  __m256d s12 = _mm256_set1_pd(sini);
                  __m256d c21 = _mm256_set1_pd(cosi1);
                  __m256d c22 = _mm256_set1_pd(cosi1);
                  __m256d s21 = _mm256_set1_pd(sini1);
                  __m256d s22 = _mm256_set1_pd(sini1);
                   //register double *y1=a+i*n,*y2=a+(i+1)*n;
                   //register double  *y3=y1+n+n,*y4=y2+n+n;
	           for(j = 0; j <n; j+=12)
	             {
			// First, compute f(A) for the element of a in question
			//const double x1 =*y1;
			__m256d x11 = _mm256_loadu_pd(y1+j);
		        __m256d x12 = _mm256_loadu_pd(y1+j+4);
			__m256d x13 = _mm256_loadu_pd(y1+j+8);
			__m256d x21 = _mm256_loadu_pd(y2+j);
			__m256d x22 = _mm256_loadu_pd(y2+j+4);
			__m256d x23 = _mm256_loadu_pd(y2+j+8);
			__m256d x31 = _mm256_loadu_pd(y3+j);
			__m256d x32 = _mm256_loadu_pd(y3+j+4);
			__m256d x33 = _mm256_loadu_pd(y3+j+8);
			__m256d x41 = _mm256_loadu_pd(y4+j);
			__m256d x42 = _mm256_loadu_pd(y4+j+4);
			__m256d x43 = _mm256_loadu_pd(y4+j+8);
			//const double x2 = *y2;
			//const double x3 =*y3;
			//const double x4 = *y4;
			/*f(x1,x2,&y1,&y2, i, j);

			// Add this to the value of a we're computing and store it
			a[i*n+j] =y1 + x1;
			a[i*n+n+j] = x2 + y2;
			//a[i*n+ j]= sum1;
			//a[(i+1)*n+ j]= sum2;
                        */
                        //if(i%4==0){
                        _mm256_storeu_pd(y1+j, _mm256_add_pd(     _mm256_mul_pd(x11,c11),_mm256_mul_pd(x21,s11)) );
                        _mm256_storeu_pd(y1+j+4, _mm256_add_pd(     _mm256_mul_pd(x12,c12),_mm256_mul_pd(x22,s12)) );
                        _mm256_storeu_pd(y1+j+8, _mm256_add_pd(     _mm256_mul_pd(x13,c11),_mm256_mul_pd(x23,s11)) );
                        _mm256_storeu_pd(y2+j,_mm256_sub_pd(      _mm256_mul_pd(x21,c12),_mm256_mul_pd(x11,s12)) );
                        _mm256_storeu_pd(y2+j+4,_mm256_sub_pd(      _mm256_mul_pd(x22,c11),_mm256_mul_pd(x12,s11)) );
                        _mm256_storeu_pd(y2+j+8,_mm256_sub_pd(      _mm256_mul_pd(x23,c12),_mm256_mul_pd(x13,s12)) );
                        _mm256_storeu_pd(y3+j,_mm256_sub_pd(      _mm256_mul_pd(x31,c21),_mm256_mul_pd(x41,s21)) );
                        _mm256_storeu_pd(y3+j+4,_mm256_sub_pd(      _mm256_mul_pd(x32,c22),_mm256_mul_pd(x42,s22)) );
                        _mm256_storeu_pd(y3+j+8,_mm256_sub_pd(      _mm256_mul_pd(x33,c21),_mm256_mul_pd(x43,s21)) );
                        _mm256_storeu_pd(y4+j,_mm256_add_pd(      _mm256_mul_pd(x41,c22),_mm256_mul_pd(x31,s22)) );
                        _mm256_storeu_pd(y4+j+4,_mm256_add_pd(      _mm256_mul_pd(x42,c21),_mm256_mul_pd(x32,s21)) );
                        _mm256_storeu_pd(y4+j+8,_mm256_add_pd(      _mm256_mul_pd(x43,c22),_mm256_mul_pd(x33,s22)) );

		}
                     y1=y3+n+n;y2=y4+n+n;y3=y1+n+n;y4=y2+n+n;
	}
}


void superslow_vectoroptimized(smat_t *smat)
{
	 register int i, j,n=smat->n;
	//double x1,x2,*y1,*y2,x3,x4,*y3,*y4;
	//double temp[n];
        double *temp = (double*) _mm_malloc(sizeof(double)*n,64);
        double *a = smat->mat;
        double *y1 = (double*) _mm_malloc(sizeof(double)*n,64);
        double *y2 = (double*) _mm_malloc(sizeof(double)*n,64);
        double *y3 = (double*) _mm_malloc(sizeof(double)*n,64);
        double *y4 = (double*) _mm_malloc(sizeof(double)*n,64);
        y1 =a;
        y2 = a+n;
        y3 = y1+n+n;
        y4 = y2+n+n;

	// j is the column of a we're computing right now
	//for(j = 0; j <n; j+=4)
	//{
	   //for(i=0;i<n;i+=2){
	     //    temp[i]=cos(i)+1;
	       // temp[i+1]=sin(i); }

		// i is the row of a we're computing right now
		for(i = 0; i < n; i=i+4)
		{   double cosi = cos(i)+1,sini=sin(i),cosi1=cos(i+2)+1,sini1=sin(i+2);
                  __m256d c11 = _mm256_set1_pd(cosi);//temp[i]);
                  __m256d c12 = _mm256_set1_pd(cosi);//temp[i]);
                  __m256d s11 = _mm256_set1_pd(sini);//temp[i+1]);
                  __m256d s12 = _mm256_set1_pd(sini);//temp[i+1]);
                  __m256d c21 = _mm256_set1_pd(cosi1);//temp[i+2]);
                  __m256d c22 = _mm256_set1_pd(cosi1);//temp[i+2]);
                  __m256d s21 = _mm256_set1_pd(sini1);//temp[i+3]);
                  __m256d s22 = _mm256_set1_pd(sini1);//temp[i+3]);
                   //register double *y1=a+i*n,*y2=a+(i+1)*n;
                   //register double  *y3=y1+n+n,*y4=y2+n+n;
	           for(j = 0; j <n; j+=12)
	             {
			// First, compute f(A) for the element of a in question
			//const double x1 =*y1;
			//y1+=j;y2+=j;y3+=j;y4+=j;
	   	        register double *a11 = y1+j,*a21=y2+j,*a31=y3+j,*a41=y4+j;
			register double *a12 = y1+j,*a22=y2+j,*a32=y3+j,*a42=y4+j;
			register double *a13 = y1+j,*a23=y2+j,*a33=y3+j,*a43=y4+j;
			__m256d x11 = _mm256_load_pd(a11);
		        __m256d x12 = _mm256_load_pd(a12+4);
			__m256d x13 = _mm256_load_pd(a13+8);
			__m256d x21 = _mm256_load_pd(a21);
			__m256d x22 = _mm256_load_pd(a22+4);
			__m256d x23 = _mm256_load_pd(a23+8);
			__m256d x31 = _mm256_load_pd(a31);
			__m256d x32 = _mm256_load_pd(a32+4);
			__m256d x33 = _mm256_load_pd(a33+8);
			__m256d x41 = _mm256_load_pd(a41);
			__m256d x42 = _mm256_load_pd(a42+4);
			__m256d x43 = _mm256_load_pd(a43+8);




                        _mm256_store_pd(a11, _mm256_add_pd(     _mm256_mul_pd(x11,c11),_mm256_mul_pd(x21,s11)) );
                        _mm256_store_pd(a21,_mm256_sub_pd(      _mm256_mul_pd(x21,c12),_mm256_mul_pd(x11,s12)) );
                        _mm256_store_pd(a31,_mm256_sub_pd(      _mm256_mul_pd(x31,c21),_mm256_mul_pd(x41,s21)) );
                        _mm256_store_pd(a41,_mm256_add_pd(      _mm256_mul_pd(x41,c22),_mm256_mul_pd(x31,s22)) );
                        _mm256_store_pd(a12+4, _mm256_add_pd(     _mm256_mul_pd(x12,c12),_mm256_mul_pd(x22,s12)) );
                        _mm256_store_pd(a13+8, _mm256_add_pd(     _mm256_mul_pd(x13,c11),_mm256_mul_pd(x23,s11)) );
                        //_mm256_storeu_pd(y2+j,_mm256_sub_pd(      _mm256_mul_pd(x21,c12),_mm256_mul_pd(x11,s12)) );
                        _mm256_store_pd(a22+4,_mm256_sub_pd(      _mm256_mul_pd(x22,c11),_mm256_mul_pd(x12,s11)) );
                        _mm256_store_pd(a23+8,_mm256_sub_pd(      _mm256_mul_pd(x23,c12),_mm256_mul_pd(x13,s12)) );
                       // _mm256_storeu_pd(y3+j,_mm256_sub_pd(      _mm256_mul_pd(x31,c21),_mm256_mul_pd(x41,s21)) );
                        _mm256_store_pd(a32+4,_mm256_sub_pd(      _mm256_mul_pd(x32,c22),_mm256_mul_pd(x42,s22)) );
                        _mm256_store_pd(a33+8,_mm256_sub_pd(      _mm256_mul_pd(x33,c21),_mm256_mul_pd(x43,s21)) );
                        //_mm256_storeu_pd(y4+j,_mm256_add_pd(      _mm256_mul_pd(x41,c22),_mm256_mul_pd(x31,s22)) );
                        _mm256_store_pd(a42+4,_mm256_add_pd(      _mm256_mul_pd(x42,c21),_mm256_mul_pd(x32,s21)) );
                        _mm256_store_pd(a43+8,_mm256_add_pd(      _mm256_mul_pd(x43,c22),_mm256_mul_pd(x33,s22)) );
			//y1+=j;y2+=j;y3+=j;y4+=j;
		}
                     y1=y3+n+n;y2=y4+n+n;y3=y1+n+n;y4=y2+n+n;
	}
}





/*
* Called by the driver to register your functions
* Use add_function(func, description) to add your own functions
*/
void register_functions()
{
	// Registers comp_superslow with the driver
	add_function(&superslow, "superslow: original function");
	add_function(&superslow_firstopt, "superslow: eliminate f");
	add_function(&superslow_unroll, "superslow: unrolling");
	add_function(&superslow_vector, "superslow: vectorization");
	add_function(&superslow_vectoroptimized, "superslow: vectorization optimized");
//	add_function(&fast, "fast: optimized version 1");
	//Add your functions here
	//add_function(&superslow2, "superslow: Optimization X");


}
