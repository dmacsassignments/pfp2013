/*
* comp.c - contains the function superslow that you need to optimize
*
*
*/

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


/* f(x1,x2, i, j) rotates the input vector
*/
double f(double x1, double x2, double* y1, double * y2, int i, int j)
{
	double m[2][2];	

	if (i %4 == 0)
	{
		m[0][0] = cos(i);
		m[0][1] = sin(i);
		m[1][0] = -sin(i);
		m[1][1] = cos(i);
	}
	else
	{
		m[0][0] = cos(-i);
		m[0][1] = sin(-i);
		m[1][0] = -sin(-i);
		m[1][1] = cos(-i);

	}

	*y1 = m[0][0] * x1 + m[0][1]* x2;
	*y2 = m[1][0] * x1 + m[1][1]* x2;
}

/* This is the function you need to optimize. It takes one
square matrix as input
*/
void superslow(smat_t *a)
{
	int i, j;
	double x1,x2,y1,y2;
	double sum1, sum2;


	// j is the column of a we're computing right now
	for(i = 0; i < a->n; i+=2)
	{

		// i is the row of a we're computing right now
		for(j = 0; j < a->n; j++)        
		{            
			// First, compute f(A) for the element of a in question
			x1 = get_elt(a,i,j);
			x2 = get_elt(a,i+1,j);
			f(x1,x2,&y1,&y2, i, j);

			// Add this to the value of a we're computing and store it                
			sum1 = get_elt(a, i, j) + y1;
			sum2 = get_elt(a, i+1, j) + y2;
			set_elt(a, i, j, sum1);
			set_elt(a, i+1, j, sum2);            
		}
	}
}



void myversion1(smat_t *a)
{
        int i, j;
        double x1,x2,y1,y2;
        double sum1, sum2;
        register int n=a->n;

       
        for(j = 0; j < a->n; j++)
        {
                 
                for(i = 0; i < a->n; i+=2)
                {
                                             
                         x1=a->mat[i*n+j];                    
                         x2 = a->mat[(i+1)*n+(j)];
                        //f(x1,x2,&y1,&y2, i, j);

                         double m[2][2];

                         if (i %4 == 0)
                         {
                              m[0][0] = cos(i);
                              m[0][1] = sin(i);
                              m[1][0] = -sin(i);
                              m[1][1] = cos(i);
                         }
                         else
                         {
                              m[0][0] = cos(-i);
                              m[0][1] = sin(-i);
                              m[1][0] = -sin(-i);
                              m[1][1] = cos(-i);

                         }                    

                             y1 = m[0][0] * x1 + m[0][1]* x2;
                             y2 = m[1][0] * x1 + m[1][1]* x2;
                      
 
                        sum1 = x1 + y1;
                        sum2 = x2 + y2;
                        a->mat[i*n+j]=sum1;
                        a->mat[(i+1)*n+j]=sum2; 
                      
                }
        }
}

void myversion2(smat_t *a)
{
        register  int i, j;
        double x1,x2,x3,x4,y1,y2,y3,y4;
        double sum1, sum2,sum3,sum4;
        register int n=a->n;
        register double m[2][2],m1[2][2];
       for(j = 0; j < a->n; j++)
        {

               
               for(i = 0; i < a->n; i+=4)
                {
                         x1=a->mat[i*n+j];
                         x2 = a->mat[(i+1)*n+j];
                         x3= a->mat[(i+2)*n+j];
                         x4=a->mat[(i+3)*n+j];



                           m1[0][0]=cos(i);
                           m1[0][1]=sin(i);
                           m[0][0]=cos(-(i+2));
                           m[0][1]=sin(-(i+2));
                            
                           y1 = m1[0][0] * x1 + m1[0][1]* x2;
                           y2 = -(m1[0][1]) * x1 + m1[0][0]* x2;
                           y3 = m[0][0] * x3 + m[0][1]* x4;
                           y4 = -(m[0][1]) * x3 + m[0][0]* x4;



                        sum1 = x1 + y1;
                        sum2 = x2 + y2;
                        sum3 = x3 + y3;
                        sum4 = x4 + y4;
                        a->mat[i*n+j]=sum1;
                        a->mat[(i+1)*n+j]=sum2;
                        a->mat[(i+2)*n+j]=sum3;
                        a->mat[(i+3)*n+j]=sum4;

                }
        }
}

void myversion3(smat_t *a)
{
        register  int i, j,k,l,p,q;
        double x1,x2,x3,x4,y1,y2,y3,y4;
        double sum1, sum2,sum3,sum4;
        register int n=a->n;
        register double m[2][2],m1[2][2];
       for(i = 0; i < a->n; i+=4) 
        {
               k=i*n;
               l=(i+1)*n;
               p=(i+2)*n;
               q=(i+3)*n;
               m1[0][0]=cos(i);
               m1[0][1]=sin(i);
               m[0][0]=cos(-(i+2));
               m[0][1]=sin(-(i+2)); 
               for(j = 0; j < a->n; j++)
                {
                         x1=a->mat[k+j];
                         x2 = a->mat[l+j];
                         x3= a->mat[p+j];
                         x4=a->mat[q+j];
                         
                  
                         
                        
                           y1 = m1[0][0] * x1 + m1[0][1]* x2;
                           y2 = -(m1[0][1]) * x1 + m1[0][0]* x2;  
                           y3 = m[0][0] * x3 + m[0][1]* x4;
                           y4 = -(m[0][1]) * x3 + m[0][0]* x4;
                         


                        sum1 = x1 + y1;
                        sum2 = x2 + y2;
                        sum3 = x3 + y3;
                        sum4 = x4 + y4;
                        a->mat[k+j]=sum1;
                        a->mat[l+j]=sum2;
                        a->mat[p+j]=sum3;
                        a->mat[q+j]=sum4;

                }
        }
}

void myversion4(smat_t *a)
{
        register  int i, j,k,l,p,q,r,s,t,u,v,w,x,y;
        double x1,x2,x3,x4,x5,x6,x7,x8,x9,x10,x11,x12,x13,x14,x15,x16,x17,x18,x19,x20,y1,y2,y3,y4,y5,y6,y7,y8,y9,y10,y11,y12,y13,y14,y15,y16,y17,y18,y19,y20;
        double sum1, sum2,sum3,sum4,sum5,sum6,sum7,sum8,sum9,sum10,sum11,sum12,sum13,sum14,sum15,sum16,sum17,sum18,sum19,sum20;
        register int n=a->n;
        register double m[2][2],m1[2][2],m2[2][2],m3[2][2],m4[2][2],m5[2][2],m6[2][2],m7[2][2],m8[2][2],m9[2][2];
       
       for(i = 0; i < a->n; i+=20) 
        {
               k=i*n;
               l=(i+1)*n;
               p=(i+2)*n;
               q=(i+3)*n;
               r=(i+4)*n;
               s=(i+5)*n;
               t=(i+6)*n;
               u=(i+7)*n;
               v=(i+8)*n;
               w=(i+9)*n;
               x=(i+10)*n;
               y=(i+11)*n;
                 
               m1[0][0]=cos(i);
               m1[0][1]=sin(i);
               m[0][0]=cos(-(i+2));
               m[0][1]=sin(-(i+2)); 
               m2[0][0]=cos(i+4);
               m2[0][1]=sin(i+4);
               m3[0][0]=cos(-(i+6));
               m3[0][1]=sin(-(i+6));
               m4[0][0]=cos(i+8);
               m4[0][1]=sin(i+8);
               m5[0][0]=cos(-(i+10));
               m5[0][1]=sin(-(i+10));
               m6[0][0]=cos(i+12);
               m6[0][1]=sin(i+12);
               m7[0][0]=cos(-(i+14));
               m7[0][1]=sin(-(i+14));
               m8[0][0]=cos(i+16);
               m8[0][1]=sin(i+16);
               m9[0][0]=cos(-(i+18));
               m9[0][1]=sin(-(i+18));

               for(j = 0; j < a->n; j++)
                {
                         x1=a->mat[k+j];
                         x2 = a->mat[l+j];
                         x3= a->mat[p+j];
                         x4=a->mat[q+j];
                         x5=a->mat[r+j];
                         x6=a->mat[s+j];
                         x7=a->mat[t+j];
                         x8=a->mat[u+j];
                         x9=a->mat[v+j];
                         x10=a->mat[w+j];
                         x11=a->mat[x+j];
                         x12=a->mat[y+j];
                         x13=a->mat[(i+12)*n+j];
                         x14=a->mat[(i+13)*n+j];
                         x15=a->mat[(i+14)*n+j];
                         x16=a->mat[(i+15)*n+j];
                         x17=a->mat[(i+16)*n+j];
                         x18=a->mat[(i+17)*n+j];
                         x19=a->mat[(i+18)*n+j];
                         x20=a->mat[(i+19)*n+j];
                  
                         
                        
                           y1 = m1[0][0] * x1 + m1[0][1]* x2;
                           y2 = -(m1[0][1]) * x1 + m1[0][0]* x2;  
                           y3 = m[0][0] * x3 + m[0][1]* x4;
                           y4 = -(m[0][1]) * x3 + m[0][0]* x4;
                           y5 = m2[0][0]*x5+m2[0][1]*x6;
                           y6 = -(m2[0][1])*x5+m2[0][0]*x6;
                           y7 = m3[0][0]*x7+m3[0][1]*x8;
                           y8 = -(m3[0][1])*x7+m3[0][0]*x8;
                           y9 = m4[0][0]*x9+m4[0][1]*x10;
                           y10 = -(m4[0][1])*x9+m4[0][0]*x10;
                           y11 =  m5[0][0]*x11+m5[0][1]*x12;
                           y12 = -(m5[0][1])*x11+m5[0][0]*x12;
                           y13 =  m6[0][0]*x13+m6[0][1]*x14;
                           y14 = -(m6[0][1])*x13+m6[0][0]*x14;
                           y15 =  m7[0][0]*x15+m7[0][1]*x16;
                           y16 = -(m7[0][1])*x15+m7[0][0]*x16;
                           y17 =  m8[0][0]*x17+m8[0][1]*x18;
                           y18 = -(m8[0][1])*x17+m8[0][0]*x18;
                           y19 =  m9[0][0]*x19+m9[0][1]*x20;
                           y20 = -(m9[0][1])*x19+m9[0][0]*x20;

                        sum1 = x1 + y1;
                        sum2 = x2 + y2;
                        sum3 = x3 + y3;
                        sum4 = x4 + y4;
                        sum5 = x5 + y5;
                        sum6 = x6 + y6;
                        sum7 = x7 + y7;
                        sum8 = x8 + y8;
                        sum9 = x9 + y9;
                        sum10 = x10 + y10;
                        sum11 = x11 + y11;
                        sum12 = x12 + y12;
                        sum13 = x13 + y13;
                        sum14 = x14 + y14;
                        sum15 = x15 + y15;
                        sum16 = x16 + y16;
                        sum17 = x17 + y17;
                        sum18 = x18 + y18;
                        sum19 = x19 + y19;
                        sum20 = x20 + y20;
                        a->mat[k+j]=sum1;
                        a->mat[l+j]=sum2;
                        a->mat[p+j]=sum3;
                        a->mat[q+j]=sum4;
                        a->mat[r+j]=sum5; 
                        a->mat[s+j]=sum6;
                        a->mat[t+j]=sum7;
                        a->mat[u+j]=sum8;
                        a->mat[v+j]=sum9;
                        a->mat[w+j]=sum10;
                        a->mat[x+j]=sum11;
                        a->mat[y+j]=sum12;
                        a->mat[(i+12)*n+j]=sum13;
                        a->mat[(i+13)*n+j]=sum14;
                        a->mat[(i+14)*n+j]=sum15;
                        a->mat[(i+15)*n+j]=sum16;
                        a->mat[(i+16)*n+j]=sum17;
                        a->mat[(i+17)*n+j]=sum18;
                        a->mat[(i+18)*n+j]=sum19;
                        a->mat[(i+19)*n+j]=sum20;


                }
        }
}
/* 
* Called by the driver to register your functions
* Use add_function(func, description) to add your own functions
*/
void register_functions()
{
	// Registers comp_superslow with the driver
	add_function(&superslow, "superslow: original function");
        add_function(&myversion1, "version1: optimization 1");
        add_function(&myversion2, "version2: optimization 2");
        add_function(&myversion3, "version3: optimization 3");
        add_function(&myversion4, "version4: optimization 4");
//	add_function(&fast, "fast: optimized version 1");
	//Add your functions here
	//add_function(&superslow2, "superslow: Optimization X");


}
