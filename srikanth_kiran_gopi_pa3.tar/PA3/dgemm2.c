const char* dgemm_desc = "My awesome dgemm.";
void square_dgemm1(const int M, const double *A, const double *B, double *C ) {}
void square_dgemm2(const int M, const double *A, const double *B, double *C ) {}
void square_dgemm3(const int M, const double *A, const double *B, double *C ) {}
void square_dgemm4(const int M, const double *A, const double *B, double *C ) {}

/*void square_dgemm(const int M, const double *A, const double *B, double *C)
{
    int i, j, k;
    for (i = 0; i < M; ++i) {
        for (j = 0; j < M; ++j) {
            double cij = C[j*M+i];
            for (k = 0; k < M; ++k)
                cij += A[k*M+i] * B[j*M+k];
            C[j*M+i] = cij;
        }
    }
}*/



/*void square_dgemm(const int M, const double *A, const double *B, double *C)
{
    int i, j, k;
    for (j = 0; j < M; ++j) {
        for (k = 0; k < M; ++k) {
            double cij = C[k*M+j];
            for (k = 0; k < M; ++k)
                cij += A[k*M+i] * B[j*M+k];
            C[j*M+i] = cij;
        }
    }
}*/



void square_dgemm(const int M, const double *A, const double *B, double *C ) {
    int i,j,k,i1,j1,k1,i2,j2,k2,i3,j3,k3;
     int block =104;
       for( j = 0; j < M; j+=block )
        for( k = 0; k < M; k+=block )
              
            for( i = 0; i < M; i+=block )
                for(j1=j;j1<j+block;j1+=26)
                  for(k1=k;k1<k+block;k1+=26)
             
                      
                    for(i1=i;i1<i+block;i1+=26)
                       for(j2=j1;j2<j1+26;j2+=2)
                         for(k2=k1;k2<k1+26;k2+=2)
            
                         for(i2=i1;i2<i1+26;i2+=2)
                            for(j3=j2;j3<j2+2;j3++)
                               for(k3=k2;k3<k2+2;k3++){
                                 double bjk=B[j3*M+k3];
                                for(i3=i2;i3<i2+2;i3++)
                    C[i3+j3*M] += A[i3+k3*M]*bjk;
   }
        
    }
  


