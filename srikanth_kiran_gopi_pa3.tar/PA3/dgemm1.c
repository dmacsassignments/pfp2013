const char* dgemm_desc = "My awesome dgemm.";
void square_dgemm1(const int M, const double *A, const double *B, double *C ) {}
void square_dgemm2(const int M, const double *A, const double *B, double *C ) {}
void square_dgemm3(const int M, const double *A, const double *B, double *C ) {}
void square_dgemm4(const int M, const double *A, const double *B, double *C ) {}
#define A(i,j) A[ (j)*M + (i) ]
#define B(i,j) B[ (j)*M + (i) ]
#define C(i,j) C[ (j)*M + (i) ]
void AddDot( int, const double *, int,const double *, double * );
void AddDot1x4( const int, const double *,  const double *,  double *  );
void AddDot4x4( const int, const double *,  const double *,  double *  );
void square_dgemm(const int M, const double *A, const double *B, double *C)
{
    int i, j, k;
    for (j = 0; j < M; j+=4) {
        for (i = 0; i < M; i+=4){ 
            //double cij = C[j*M+i];
           // for (k = 0; k < M; ++k)
              //  cij += A[k*M+i] * B[j*M+k];
           // C[j*M+i] = cij;
           AddDot4x4(M,&A(i,0),&B(0,j),&C(i,j));
     //       AddDot( M, &A( i,0 ), M, &B( 0,j+1 ), &C( i,j+1 ) );

      /* Update the C( i,j+2 ) with the inner product of the ith row of A
 *          and the (j+2)th column of B */

     // AddDot( M, &A( i,0 ), M, &B( 0,j+2 ), &C( i,j+2 ) );

      /* Update the C( i,j+3 ) with the inner product of the ith row of A
 *          and the (j+1)th column of B */

     // AddDot( M, &A( i,0 ), M, &B( 0,j+3 ), &C( i,j+3 ) );
        }
    }
}





void AddDot4x4( const int M, const double *A,  const  double *B,  double *C )
{
  /* So, this routine computes a 4x4 block of matrix A
 *
 *            C( 0, 0 ), C( 0, 1 ), C( 0, 2 ), C( 0, 3 ).  
 *                       C( 1, 0 ), C( 1, 1 ), C( 1, 2 ), C( 1, 3 ).  
 *                                  C( 2, 0 ), C( 2, 1 ), C( 2, 2 ), C( 2, 3 ).  
 *                                             C( 3, 0 ), C( 3, 1 ), C( 3, 2 ), C( 3, 3 ).  
 *
 *                                                  Notice that this routine is called with c = C( i, j ) in the
 *                                                       previous routine, so these are actually the elements 
 *
 *                                                                  C( i  , j ), C( i  , j+1 ), C( i  , j+2 ), C( i  , j+3 ) 
 *                                                                             C( i+1, j ), C( i+1, j+1 ), C( i+1, j+2 ), C( i+1, j+3 ) 
 *                                                                                        C( i+2, j ), C( i+2, j+1 ), C( i+2, j+2 ), C( i+2, j+3 ) 
 *                                                                                                   C( i+3, j ), C( i+3, j+1 ), C( i+3, j+2 ), C( i+3, j+3 ) 
 *                                                                                                             
 *                                                                                                                  in the original matrix C 
 *
 *                                                                                                                       In this version, we use pointer to track where in four columns of B we are */

  int p;
  register double 
    /* hold contributions to
 *        C( 0, 0 ), C( 0, 1 ), C( 0, 2 ), C( 0, 3 ) 
 *               C( 1, 0 ), C( 1, 1 ), C( 1, 2 ), C( 1, 3 ) 
 *                      C( 2, 0 ), C( 2, 1 ), C( 2, 2 ), C( 2, 3 ) 
 *                             C( 3, 0 ), C( 3, 1 ), C( 3, 2 ), C( 3, 3 )   */
       c_00_reg,   c_01_reg,   c_02_reg,   c_03_reg,  
       c_10_reg,   c_11_reg,   c_12_reg,   c_13_reg,  
       c_20_reg,   c_21_reg,   c_22_reg,   c_23_reg,  
       c_30_reg,   c_31_reg,   c_32_reg,   c_33_reg,
    /* hold 
 *        A( 0, p ) 
 *               A( 1, p ) 
 *                      A( 2, p ) 
 *                             A( 3, p ) */
       a_0p_reg,
       a_1p_reg,
       a_2p_reg,
       a_3p_reg;
  double 
    /* Point to the current elements in the four columns of B */
    *b_p0_pntr, *b_p1_pntr, *b_p2_pntr, *b_p3_pntr; 
    
  b_p0_pntr = &B( 0, 0 );
  b_p1_pntr = &B( 0, 1 );
  b_p2_pntr = &B( 0, 2 );
  b_p3_pntr = &B( 0, 3 );

  c_00_reg = 0.0;   c_01_reg = 0.0;   c_02_reg = 0.0;   c_03_reg = 0.0;
  c_10_reg = 0.0;   c_11_reg = 0.0;   c_12_reg = 0.0;   c_13_reg = 0.0;
  c_20_reg = 0.0;   c_21_reg = 0.0;   c_22_reg = 0.0;   c_23_reg = 0.0;
  c_30_reg = 0.0;   c_31_reg = 0.0;   c_32_reg = 0.0;   c_33_reg = 0.0;

  for ( p=0; p<M; p++ ){
    a_0p_reg = A( 0, p );
    a_1p_reg = A( 1, p );
    a_2p_reg = A( 2, p );
    a_3p_reg = A( 3, p );

    /* First row */
    c_00_reg += a_0p_reg * *b_p0_pntr;     
    c_01_reg += a_0p_reg * *b_p1_pntr;     
    c_02_reg += a_0p_reg * *b_p2_pntr;     
    c_03_reg += a_0p_reg * *b_p3_pntr;     

    /* Second row */
    c_10_reg += a_1p_reg * *b_p0_pntr;     
    c_11_reg += a_1p_reg * *b_p1_pntr;     
    c_12_reg += a_1p_reg * *b_p2_pntr;     
    c_13_reg += a_1p_reg * *b_p3_pntr;     

    /* Third row */
    c_20_reg += a_2p_reg * *b_p0_pntr;     
    c_21_reg += a_2p_reg * *b_p1_pntr;     
    c_22_reg += a_2p_reg * *b_p2_pntr;     
    c_23_reg += a_2p_reg * *b_p3_pntr;     

    /* Four row */
    c_30_reg += a_3p_reg * *b_p0_pntr++;     
    c_31_reg += a_3p_reg * *b_p1_pntr++;     
    c_32_reg += a_3p_reg * *b_p2_pntr++;     
    c_33_reg += a_3p_reg * *b_p3_pntr++;     
  }

  C( 0, 0 ) += c_00_reg;   C( 0, 1 ) += c_01_reg;   C( 0, 2 ) += c_02_reg;   C( 0, 3 ) += c_03_reg;
  C( 1, 0 ) += c_10_reg;   C( 1, 1 ) += c_11_reg;   C( 1, 2 ) += c_12_reg;   C( 1, 3 ) += c_13_reg;
  C( 2, 0 ) += c_20_reg;   C( 2, 1 ) += c_21_reg;   C( 2, 2 ) += c_22_reg;   C( 2, 3 ) += c_23_reg;
  C( 3, 0 ) += c_30_reg;   C( 3, 1 ) += c_31_reg;   C( 3, 2 ) += c_32_reg;   C( 3, 3 ) += c_33_reg;



  /* So, this routine computes a 4x4 block of matrix A
 *
 *            C( 0, 0 ), C( 0, 1 ), C( 0, 2 ), C( 0, 3 ).  
 *                       C( 1, 0 ), C( 1, 1 ), C( 1, 2 ), C( 1, 3 ).  
 *                                  C( 2, 0 ), C( 2, 1 ), C( 2, 2 ), C( 2, 3 ).  
 *                                             C( 3, 0 ), C( 3, 1 ), C( 3, 2 ), C( 3, 3 ).  
 *
 *                                                  Notice that this routine is called with c = C( i, j ) in the
 *                                                       previous routine, so these are actually the elements 
 *
 *                                                                  C( i  , j ), C( i  , j+1 ), C( i  , j+2 ), C( i  , j+3 ) 
 *                                                                             C( i+1, j ), C( i+1, j+1 ), C( i+1, j+2 ), C( i+1, j+3 ) 
 *                                                                                        C( i+2, j ), C( i+2, j+1 ), C( i+2, j+2 ), C( i+2, j+3 ) 
 *                                                                                                   C( i+3, j ), C( i+3, j+1 ), C( i+3, j+2 ), C( i+3, j+3 ) 
 *                                                                                                             
 *                                                                                                                  in the original matrix C */ 

  /* First row */
/*  AddDot( M, &A( 0, 0 ), M, &B( 0, 0 ), &C( 0, 0 ) );
  AddDot( M, &A( 0, 0 ), M, &B( 0, 1 ), &C( 0, 1 ) );
  AddDot( M, &A( 0, 0 ), M, &B( 0, 2 ), &C( 0, 2 ) );
  AddDot( M, &A( 0, 0 ), M, &B( 0, 3 ), &C( 0, 3 ) );*/

  /* Second row */
/*  AddDot( M, &A( 1, 0 ), M, &B( 0, 0 ), &C( 1, 0 ) );
  AddDot( M, &A( 1, 0 ), M, &B( 0, 1 ), &C( 1, 1 ) );
  AddDot( M, &A( 1, 0 ), M, &B( 0, 2 ), &C( 1, 2 ) );
  AddDot( M, &A( 1, 0 ), M, &B( 0, 3 ), &C( 1, 3 ) );*/

  /* Third row */
/*  AddDot( M, &A( 2, 0 ), M, &B( 0, 0 ), &C( 2, 0 ) );
  AddDot( M, &A( 2, 0 ), M, &B( 0, 1 ), &C( 2, 1 ) );
  AddDot( M, &A( 2, 0 ), M, &B( 0, 2 ), &C( 2, 2 ) );
  AddDot( M, &A( 2, 0 ), M, &B( 0, 3 ), &C( 2, 3 ) );*/

  /* Four row */
/*  AddDot( M, &A( 3, 0 ), M, &B( 0, 0 ), &C( 3, 0 ) );
  AddDot( M, &A( 3, 0 ), M, &B( 0, 1 ), &C( 3, 1 ) );
  AddDot( M, &A( 3, 0 ), M, &B( 0, 2 ), &C( 3, 2 ) );
  AddDot( M, &A( 3, 0 ), M, &B( 0, 3 ), &C( 3, 3 ) );*/
}

void AddDot1x4( const int M,const double *A,   const double *B,  double *C  )
{
  /* So, this routine computes four elements of C: 
 *
 *            C( 0, 0 ), C( 0, 1 ), C( 0, 2 ), C( 0, 3 ).  
 *
 *                 Notice that this routine is called with c = C( i, j ) in the
 *                      previous routine, so these are actually the elements 
 *
 *                                 C( i, j ), C( i, j+1 ), C( i, j+2 ), C( i, j+3 ) 
 *                                           
 *                                                in the original matrix C */ 

/*  AddDot( M, &A( 0, 0 ), M, &B( 0, 0 ), &C( 0, 0 ) );
  AddDot( M, &A( 0, 0 ), M, &B( 0, 1 ), &C( 0, 1 ) );
  AddDot( M, &A( 0, 0 ), M, &B( 0, 2 ), &C( 0, 2 ) );
  AddDot( M, &A( 0, 0 ), M, &B( 0, 3 ), &C( 0, 3 ) );*/
/*  int p;
for ( p=0; p<M; p++ ){
    C( 0, 0 ) += A( 0, p ) * B( p, 0 );     
    C( 0, 1 ) += A( 0, p ) * B( p, 1 );     
    C( 0, 2 ) += A( 0, p ) * B( p, 2 );     
    C( 0, 3 ) += A( 0, p ) * B( p, 3 );     
  }*/

int p;
  register double 
    /* hold contributions to
 *        C( 0, 0 ), C( 0, 1 ), C( 0, 2 ), C( 0, 3 ) */
       c_00_reg,   c_01_reg,   c_02_reg,   c_03_reg,  
    /* holds A( 0, p ) */
       a_0p_reg;
  double 
    /* Point to the current elements in the four columns of B */
    *bp0_pntr, *bp1_pntr, *bp2_pntr, *bp3_pntr; 
    
  bp0_pntr = &B( 0, 0 );
  bp1_pntr = &B( 0, 1 );
  bp2_pntr = &B( 0, 2 );
  bp3_pntr = &B( 0, 3 );    
  c_00_reg = 0.0; 
  c_01_reg = 0.0; 
  c_02_reg = 0.0; 
  c_03_reg = 0.0;
 
  for ( p=0; p<M; p+=4 ){
    a_0p_reg = A( 0, p );

   /* c_00_reg += a_0p_reg * B( p, 0 );     
    c_01_reg += a_0p_reg * B( p, 1 );     
    c_02_reg += a_0p_reg * B( p, 2 );     
    c_03_reg += a_0p_reg * B( p, 3 );*/ 
/*    c_00_reg += a_0p_reg * *bp0_pntr++;
    c_01_reg += a_0p_reg * *bp1_pntr++;
    c_02_reg += a_0p_reg * *bp2_pntr++;
    c_03_reg += a_0p_reg * *bp3_pntr++;

    a_0p_reg = A( 0, p+1 );
    c_00_reg += a_0p_reg * *bp0_pntr++;
    c_01_reg += a_0p_reg * *bp1_pntr++;
    c_02_reg += a_0p_reg * *bp2_pntr++;
    c_03_reg += a_0p_reg * *bp3_pntr++;

    a_0p_reg = A( 0, p+2 );

    c_00_reg += a_0p_reg * *bp0_pntr++;
    c_01_reg += a_0p_reg * *bp1_pntr++;
    c_02_reg += a_0p_reg * *bp2_pntr++;
    c_03_reg += a_0p_reg * *bp3_pntr++;

    a_0p_reg = A( 0, p+3 );

    c_00_reg += a_0p_reg * *bp0_pntr++;
    c_01_reg += a_0p_reg * *bp1_pntr++;
    c_02_reg += a_0p_reg * *bp2_pntr++;
    c_03_reg += a_0p_reg * *bp3_pntr++;    
  }*/
    c_00_reg += a_0p_reg * *bp0_pntr;
    c_01_reg += a_0p_reg * *bp1_pntr;
    c_02_reg += a_0p_reg * *bp2_pntr;
    c_03_reg += a_0p_reg * *bp3_pntr;

    a_0p_reg = A( 0, p+1 );

    c_00_reg += a_0p_reg * *(bp0_pntr+1);
    c_01_reg += a_0p_reg * *(bp1_pntr+1);
    c_02_reg += a_0p_reg * *(bp2_pntr+1);
    c_03_reg += a_0p_reg * *(bp3_pntr+1);

    a_0p_reg = A( 0, p+2 );

    c_00_reg += a_0p_reg * *(bp0_pntr+2);
    c_01_reg += a_0p_reg * *(bp1_pntr+2);
    c_02_reg += a_0p_reg * *(bp2_pntr+2);
    c_03_reg += a_0p_reg * *(bp3_pntr+2);

    a_0p_reg = A( 0, p+3 );

    c_00_reg += a_0p_reg * *(bp0_pntr+3);
    c_01_reg += a_0p_reg * *(bp1_pntr+3);
    c_02_reg += a_0p_reg * *(bp2_pntr+3);
    c_03_reg += a_0p_reg * *(bp3_pntr+3);

    bp0_pntr+=4;
    bp1_pntr+=4;
    bp2_pntr+=4;
    bp3_pntr+=4;
  }

  C( 0, 0 ) += c_00_reg; 
  C( 0, 1 ) += c_01_reg; 
  C( 0, 2 ) += c_02_reg; 
  C( 0, 3 ) += c_03_reg;

}

/* Create macro to let X( i ) equal the ith element of x */

#define X(i) x[ (i)*incx ]

void AddDot( const int k,const double *x, int incx, const double *y, double *gamma )
{
  /* compute gamma := x' * y + gamma with vectors x and y of length n.
 *
 *      Here x starts at location x with increment (stride) incx and y starts at location y and has (implicit) stride of 1.
 *        */
 
  int p;

  for ( p=0; p<k; p++ ){
    *gamma += X( p ) * y[ p ];     
  }
}
/*void square_dgemm(const int M, const double *A, const double *B, double *C)
{
    int i, j, k;
    for (j = 0; j < M; ++j) {
        for (k = 0; k < M; ++k) {
            double cij = C[k*M+j];
            for (k = 0; k < M; ++k)
                cij += A[k*M+i] * B[j*M+k];
            C[j*M+i] = cij;
        }
    }
}*/



/*void square_dgemm(const int M, const double *A, const double *B, double *C ) {
    int i,j,k,i1,j1,k1,i2,j2,k2;
     int block =4;
       for( j = 0; j < M; j+=block )
        for( k = 0; k < M; k+=block )
              // double bjk = B[j*M+k];
            for( i = 0; i < M; i+=block )
                for(j1=j;j1<j+block;j1++)
                  for(k1=k;k1<k+block;k1++){
                        double bjk = B[j1*M+k1];
                      
                    for(i1=i;i1<i+block;i1++)
                     //  for(j2=j1;j2<j1+13;j2++)
                       //  for(k2=k1;k2<k1+13;k2++){
                         //  double bjk= B[j2*M+k2];
                        // for(i2=i1;i2<i1+13;i2++)
                    C[i1+j1*M] += A[i1+k1*M]*bjk;
   }
        
    }*/
  


