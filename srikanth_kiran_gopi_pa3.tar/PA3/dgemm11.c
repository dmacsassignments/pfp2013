#include <emmintrin.h>
#include<smmintrin.h>
#include<nmmintrin.h>
//#include<ia32intrin.h>
#include<immintrin.h>
#include<stdio.h>
#define BLOCK_SIZE 16 
const char* dgemm_desc = "My awesome dgemm.";

void basic_dgemm(const int lda, const int M, const int N, const int K,
                 const double *__restrict__ A, const double * __restrict__ B, double * __restrict__ C)
{
    int i, j, k,q;
    __m128d a,b,c;
   
    for (j = 0;j < N;++j) {
        for (k = 0; k < K; ++k) {
            double bjk = B[j*lda+k];
             b = _mm_set_pd(bjk,bjk);
            for (i = 0; i < M; i+=2) {
                a = _mm_loadu_pd(A + k*lda+i);
                c = _mm_loadu_pd(C +j*lda+i);
                c = _mm_add_pd(c,_mm_mul_pd(a,b));
                _mm_storeu_pd(C + j*lda+i,c);   
               
            }
            
        }
    }
}

void basic_dgemm1(const int lda, const int M, const int N, const int K,
                 const double *A, const double *B, double *C)
{
    int i, j, k,q;
    __m128 a,b,c;

    for (j = 0;j < N;++j) {
        for (k = 0; k < K; ++k) {
            double bjk = B[j*lda+k];
            for (i = 0; i < M; ++i) {
                C[j*lda+i] += A[k*lda+i] * bjk;
            }

        }
    }
}


void do_block(const int lda,
              const double *A, const double *B, double *C,
              const int i, const int j, const int k)
{
    const int M = (i+BLOCK_SIZE > lda? lda-i : BLOCK_SIZE);
    const int N = (j+BLOCK_SIZE > lda? lda-j : BLOCK_SIZE);
    const int K = (k+BLOCK_SIZE > lda? lda-k : BLOCK_SIZE);
    if(M == BLOCK_SIZE)
    basic_dgemm(lda, M, N, K,A + i + k*lda, B + k + j*lda, C + i + j*lda);
    else
    basic_dgemm1(lda,M,N,K,A + i + k*lda, B + k + j*lda, C + i + j*lda);
  
}

/*void basic_dgemm(const int lda, const int M, const int N, const int K,
                 const double *A, const double *B, double *C)
{
    int i, j, k;
    for (j = 0; j < N; ++j) {
        for (k = 0; k < K; ++k) {
            double bjk = B[j*lda+k];
            for (i = 0; i < M; ++i) {
                C[j*lda+i] += A[k*lda+i] * bjk;
            }


      }
    }
}

void do_block(const int lda,
              const double *A, const double *B, double *C,
              const int i, const int j, const int k)
{
    const int M = (i+BLOCK_SIZE > lda? lda-i : BLOCK_SIZE);
    const int N = (j+BLOCK_SIZE > lda? lda-j : BLOCK_SIZE);
    const int K = (k+BLOCK_SIZE > lda? lda-k : BLOCK_SIZE);
    basic_dgemm(lda, M, N, K,
                A + i + k*lda, B + k + j*lda, C + i + j*lda);
}*/

void square_dgemm(const int M, const double * __restrict__ A , const double *__restrict__ B, double *__restrict__ C)
{
    const int n_blocks = M / BLOCK_SIZE + (M%BLOCK_SIZE? 1 : 0);
    int bi, bj, bk;
    for (bi = 0; bi < n_blocks; ++bi) {
        const int i = bi * BLOCK_SIZE;
        for (bj = 0; bj < n_blocks; ++bj) {
            const int j = bj * BLOCK_SIZE;
            for (bk = 0; bk < n_blocks; ++bk) {
                const int k = bk * BLOCK_SIZE;
                do_block(M, A, B, C, i, j, k);
            }
        }
    }
// printf("%lf\n",C[0]);
}

void square_dgemm2(const int M, const double *__restrict__ A, const double *__restrict__ B, double *__restrict__ C ) {
    int i,j,k,i1,j1,k1,i2,j2,k2;
     int block =52;
   
     //printf("squaredgemm2\n");
   //  __m256d a,b,c;
       for( j = 0; j < M; j+=block )
        for( k = 0; k < M; k+=block )

            for( i = 0; i < M; i+=block )
                for(j1=j;j1<j+block;j1+=26)
                  for(k1=k;k1<k+block;k1+=26)

                    for(i1=i;i1<i+block;i1+=26)
                       for(j2=j1;j2<j1+26;j2++)
                         for(k2=k1;k2<k1+26;k2++){
                           double bjk= B[j2*M+k2];
                            
                         for(i2=i1;i2<i1+26;i2++)
            //             a=_mm256_loadu_pd(A+i2+k2*M);
                //         b=_mm256_set_pd(bjk,bjk,bjk,bjk);
              //           c=_mm256_loadu_pd(C+i2+j2*M);

               //          c=_mm256_add_pd(c,_mm256_mul_pd(a,b));
                 //        _mm256_storeu_pd(C+i2+j2*M,c);
              //  }
                           C[i2+j2*M] += A[i2+k2*M]*bjk;
                 
   }

// printf("%lf\n",C[0]);
    }


void square_dgemm3(const int M, const double *A, const double *B, double *C ) {
    int i,j,k,i1,j1,k1,i2,j2,k2,i3,j3,k3;
     int block =96;
       for( j = 0; j < M; j+=block )
        for( k = 0; k < M; k+=block )
              
            for( i = 0; i < M; i+=block )
                for(j1=j;j1<j+block;j1+=32)
                  for(k1=k;k1<k+block;k1+=32)
             

                    for(i1=i;i1<i+block;i1+=32)
                       for(j2=j1;j2<j1+32;j2+=32)
                         for(k2=k1;k2<k1+32;k2+=32)
            
                         for(i2=i1;i2<i1+32;i2+=32)
                            for(j3=j2;j3<j2+2;j3++)
                               for(k3=k2;k3<k2+2;k3++){
                                 double bjk=B[j3*M+k3];
                                for(i3=i2;i3<i2+2;i3++)
                    C[i3+j3*M] += A[i3+k3*M]*bjk;
   }


    }

void square_dgemm1(const int M, const double *__restrict__ A, const double *__restrict__ B, double *__restrict__ C ) {
      int i,j,k,i1,j1,k1,i2,j2,k2;
           int q1,q2,q3,q4;
     int block =4;
     __m128d a,b,c;
     // q1=M%4;
     // q2=M%26;
     // q3=M%104;
     // if(q1==0){
       for( j = 0; j < M; j+=block )
        for( k = 0; k < M; k+=block )
              
            for( i = 0; i < M; i+=block )
                for(j1=j;j1<j+block;j1++)
                  for(k1=k;k1<k+block;k1++){
                        double bjk = B[j1*M+k1];
                        b=_mm_set_pd(bjk,bjk);                    
                    for(i1=i;i1<i+block;i1+=2){
                   a=_mm_load_pd(A+i1+k1*M);
                          
                 c=_mm_load_pd(C+i1+j1*M);
                
                 c=_mm_add_pd(c,_mm_mul_pd(a,b));
                 _mm_store_pd(C+i1+j1*M,c);
               }
               
              }
        //}
       
       /* else if(q2==0)
          square_dgemm2(M,A,B,C);
        
        else if(q3==0)
          square_dgemm3(M,A,B,C);
        else
          square_dgemm1(M,A,B,C);*/

    //       printf("%lf\n",C[0]);  

    }
  



