//*
//* comp.c - contains the function superslow that you need to optimize
//*
//*


#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"
#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif
double f(double x1, double x2, double* y1, double * y2, int i, int j)
{
	double m[2][2];	

	if (i %4 == 0)
	{
		m[0][0] = cos(i);
		m[0][1] = sin(i);
		m[1][0] = -sin(i);
		m[1][1] = cos(i);
	}
	else
	{
		m[0][0] = cos(-i);
		m[0][1] = sin(-i);
		m[1][0] = -sin(-i);
		m[1][1] = cos(-i);

	}

	*y1 = m[0][0] * x1 + m[0][1]* x2;
	*y2 = m[1][0] * x1 + m[1][1]* x2;
}

/* This is the function you need to optimize. It takes one
square matrix as input
*/
void superslow(smat_t *a)
{
	int i, j;
	double x1,x2,y1,y2;
	double sum1, sum2;
	// j is the column of a we're computing right now
	for(j = 0; j < a->n; j++)
	{
	// i is the row of a we're computing right now
          for(i = 0; i < a->n; i=i+2)        
		{            
			// First, compute f(A) for the element of a in question
			x1 = get_elt(a,i,j);
			x2 = get_elt(a,i+1,j);
			f(x1,x2,&y1,&y2, i, j);

			// Add this to the value of a we're computing and store it                
			sum1 = get_elt(a, i, j) + y1;
			sum2 = get_elt(a, i+1, j) + y2;
			set_elt(a, i, j, sum1);
			set_elt(a, i+1, j, sum2);            
		}
	}
}

void mysuperslow1(smat_t *a)
{
  register  int i, j;
  register double x1,x2,y1,y2;
  register  double *mat = a->mat;
  register  int n = a->n;
  register double sum1, sum2 ;
// double m[2][2];
// int index=0;
register  double *ptr1;
//register double *ptr2;
 register  double c,s; 
 register int ni,nj;
 
  for(i= 0;i < a->n; i=i+4)
   { 
       ni=n*i;
       c=cos(i);
       s=sin(i);
       ptr1=mat+ni;
     for(j = 0; j < a->n; j++)
       {  nj=n+j;
          x1=*(ptr1+j);
          x2=*(ptr1+nj); 
        y1 =c * x1 + s*x2;
        y2 =(-s)* x1 + c*x2;
        sum1 =x1 + y1;
        sum2 = x2+ y2;
       *(ptr1+j)  =sum1;
       *(ptr1+nj) =sum2;
       
       }
  }
        
   for(i = 2; i < a->n; i=i+4)
    {
        ni=n*i;
        c=cos(-i);
       s=sin(-i);
        ptr1=mat+ni;
      for(j=0;j<a->n;j++)
       {
          nj=n+j;
          x1=*(ptr1+j);
          x2=*(ptr1+nj);
        
       y1 =c * x1 +s* x2;
        y2 = (-s) * x1 + c* x2; 
        sum1=x1+y1;
                                                                                                                                                               
        sum2 = x2+ y2;
        *(ptr1+j)=sum1;
        *(ptr1+nj)=sum2; 
     }
  }
}
 
void mysuperslow2(smat_t *a)
{
  register  int i, j;
  register double x1,x2,y1,y2;
  register  double *mat = a->mat;
  register  int n = a->n;
  register double sum1, sum2 ;
// double m[2][2];
// int index=0;
register  double *ptr1;
//register double *ptr2;
//register double *temp1,*temp2;
 register  double c,s; 
 register int ni,nj;
 
  for(i= 0;i < a->n; i=i+4)
   { 
       ni=n*i;
       c=cos(i);
       s=sin(i);
       ptr1=mat+ni;
     for(j = 0; j < a->n; j++)
       {  nj=n+j;
           
       //   temp1=ptr1+j;
         //  temp2= ptr1+nj;
           //*temp1=*temp1+(c * *(temp1)+s* *(temp2));
          //  *temp2=*temp2+((-s)* *(temp1))+(c* *(temp2) );
          x1=*(ptr1+j);
          x2=*(ptr1+nj); 
          y1=c * x1 + s*x2;
          y2=(-s)* x1 + c*x2;
          sum1  =x1 + y1;
          sum2 = x2+ y2;
          *(ptr1+j)  =sum1;
          *(ptr1+nj) =sum2;
       
       }
  }
        
   for(i = 2; i < a->n; i=i+4)
    {
        ni=n*i;
        c=cos(-i);
       s=sin(-i);
        ptr1=mat+ni;
      for(j=0;j<a->n;j++)
       {
          nj=n+j;
         // temp1=ptr1+j;
           //temp2= ptr1+nj;
          // *temp1=*temp1+((c * *(temp1))+(s* *(temp2)));
         //   *temp2=*temp2+(((-s)* *(temp1))+(c* *(temp2))) ;
         x1=*(ptr1+j);
         x2=*(ptr1+nj);
         y1=c * x1 +s* x2;
         y2= (-s) * x1 + c* x2; 
      
         sum1=x1+y1;
         sum2=x2+y2;                                                                                                                                                  
       // sum2 = x2+ y2;
       *(ptr1+j)=sum1;
      *(ptr1+nj)=sum2; 
     }
  }
}  
void register_functions()
{
 add_function(&superslow,"superslow: original function");
 add_function(&mysuperslow1,"superslow:optimized version1");
 add_function(&mysuperslow2,"superslow:optimized version2");
 
}
