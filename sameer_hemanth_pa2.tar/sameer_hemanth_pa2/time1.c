#include<stdio.h>
#include<stdlib.h>
#include<time.h>
//#include "rdtsc.h"
#define U 10
void measure()
{
volatile int v = 0; 
volatile int vr = 0; 
volatile int R = 10000000;
register int r1 = vr; 
register int r2 = vr; 
register int i;
struct timeval start ,end;
switch (v) 
{ 
   case 0: i = R/U;
           gettimeofday(&start, NULL);
           loop: 
   case 1: r1 += r2; 
   case 2: r1 += r2; 
   case 3: r1 += r2;
   case 4: r1 += r2;
   case 5: r1 += r2;
   case 6: r1 += r2;
   case 7: r1 += r2;
   case 8: r1 += r2;
   case 9: r1 += r2;
   case 10: r1 += r2;
if (--i)  

goto loop; 

} 

gettimeofday(&end,NULL);
if (!v)  
{
  double time =  ((end.tv_sec * 1000000  + end.tv_usec ) - (start.tv_sec * 1000000  + start.tv_usec));
  /*double time = (end.tv_sec - start.tv_sec) * 1000000.0;
  time += (end.tv_sec - start.tv_sec) / 1000000.0;*/
  time = time/10000;
  time = 1 / time;
  printf("%lf\n" , time );
}
else  

{ 

vr = r1; 

vr = r2; 

}
}
int main()
{
  measure();
  measure();
}
