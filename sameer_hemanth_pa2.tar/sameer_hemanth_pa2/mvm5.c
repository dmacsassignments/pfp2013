/*
 * MVM 5x5
 */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>


#include <tmmintrin.h>
#include <nmmintrin.h>
#include <smmintrin.h>

#include "utils.h"
#include "rdtsc.h"


// Procedure mvm5: Serial code (do not need to modify)

void mvm5(float const * A, float const * x, float * y) {
  int i;
  float t;
  int j;
  for(i = 0; i < 5; i++) {
      t = 0.f;
      for(j = 0; j < 5; j++)
        t += A[i*5+j]*x[j];
      y[i] = t;
  }

}



// Procedure vec_mvm5: vector code
// Implement WITHOUT unaligned instructions

void vec_mvm5(float const * A, float const * x, float * y) {
//IACA_START
  // Substitute from here..
  //printf("Implement vec_mvm5\n");
 // abort();
  // ...to here
const __m128 x1 = _mm_load_ps(x);
const __m128 x2 = _mm_set1_ps(*(x+4));

const __m128 a0 = _mm_load_ps(A);
const __m128 a1 = _mm_load_ps(A+4);
const __m128 a2 = _mm_load_ps(A+8);
const __m128 a3 = _mm_load_ps(A+12);
const __m128 a4 = _mm_load_ps(A+16);
const __m128 a5 = _mm_load_ps(A+20);
const __m128 alast = _mm_load_ss(A+24);


__m128 temp = _mm_dp_ps(a0,x1,0xF1);
//__m128 temp1 = _mm_set1_ps(0);
  __m128 temp1 = _mm_blend_ps(temp1,a1,1);   

        temp1 = _mm_blend_ps(temp1,a2,2);
 __m128 res1 = _mm_castsi128_ps(_mm_alignr_epi8(_mm_castps_si128(a2),_mm_castps_si128(a1),4));
        temp = _mm_blend_ps(temp,_mm_dp_ps(res1,x1,0xF2),2);

        temp1 = _mm_blend_ps(temp1,a3,4);
    __m128 res2 = _mm_castsi128_ps(_mm_alignr_epi8(_mm_castps_si128(a3),_mm_castps_si128(a2),8));
        temp = _mm_blend_ps(temp,_mm_dp_ps(res2,x1,0xF4),4);

        temp1 = _mm_blend_ps(temp1,a4,8);
    __m128 res = _mm_castsi128_ps(_mm_alignr_epi8(_mm_castps_si128(a4),_mm_castps_si128(a3),12));
        temp = _mm_blend_ps(temp,_mm_dp_ps(res,x1,0xF8),8);

  __m128 y1 = _mm_add_ps(temp,_mm_mul_ps(temp1,x2));

  _mm_store_ps(y,y1);

  //y1 = _mm_set1_ps(0);
  //temp = _mm_set1_ps(0);
  __m128 temp2 = _mm_dp_ps(a5,x1,0xF1);
  //temp1 = _mm_set1_ps(0);
  __m128 temp3 =_mm_mul_ss(alast,x2);
   __m128 y2 = _mm_add_ss(temp3,temp2);
    _mm_store_ss(y+4,y2);






//IACA_END


}




/*
 * Do not need to modify from here on
 */

#define RUNS     400
#define CYCLES_REQUIRED 1e7

void verify(float const * A, float const * x, float const * y)
{
  int i;
  double err;
  int j;
  float * temp = (float *) _mm_malloc(sizeof(float)*5, 16);
  setzero(temp, 5, 1);

  for(i = 0; i < 5; i++) {
      for(j = 0; j < 5; j++)
        temp[i] += A[i*5+j]*x[j];
      err = fabs(y[i] - temp[i]);
      if(err > 1E-5)
        {
          printf("Error at y[%d]\n", i);
        }
  }

  _mm_free(temp);

}

void test_vec_mvm5(float const * A, float const * x, float * y)
{
  tsc_counter start, end;
  double cycles = 0.;
  size_t num_runs = RUNS;
  int i;

  //Cache warm-up
  // RDTSCP reads ts register guaranteeing that the execution of all the code
  // we wanted to measure is completed. This way we avoid including the
  // execution of a CPUID in between. The last CPUID guarantees no other
  // instruction can be scheduled before it (and so also before RDTSCP)

  CPUID(); RDTSC(start); CPUID(); RDTSC(end);
  CPUID(); RDTSC(start); CPUID(); RDTSC(end);
  CPUID(); RDTSC(start); CPUID(); RDTSC(end);

  while(1) {
      CPUID(); RDTSC(start);
      for (i = 0; i < num_runs; ++i) {
          vec_mvm5(A, x, y);
      }
      CPUID(); RDTSC(end);

      cycles = (double)(COUNTER_DIFF(end, start));

      if(cycles >= CYCLES_REQUIRED) break;

      num_runs *= 2;

  }

  CPUID(); RDTSC(start);
  for (i = 0; i < num_runs; ++i) {
      vec_mvm5(A, x, y);
  }
  CPUID(); RDTSC(end);

  cycles = (double)(COUNTER_DIFF(end, start))/num_runs;

  printf("Test vec_mvm5  - Performance [flops/cycle]: %f\n", 45/cycles);

#ifdef VERIFY
  verify(A, x, y);
#endif

}


int main()
{
  float * A = (float *) _mm_malloc(sizeof(float)*25, 16);
  float * x = (float *) _mm_malloc(sizeof(float)*5, 16);
  float * y = (float *) _mm_malloc(sizeof(float)*5, 16);

  setrandom(A, 5, 5);
  setrandom(x, 5, 1);

  test_vec_mvm5(A, x, y);

  return 0;
}
