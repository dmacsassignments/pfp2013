==========================
O0 flag
==========================
superslow: original function:
Size 300: 20.836 MFLOPs
Size 600: 19.821 MFLOPs
Average: 20.329 MFLOPs
--------------------------------------
Optimization 1 : Substitute for  get-element 
and set-element method:

Size 300: 26.850 MFLOPs
Size 600: 25.913 MFLOPs
Average: 26.381 MFLOPs
--------------------------------------
Optimization2 : Optimization 1 + loop exchange 
+ bothloops 2 way unroll:
Size 300: 500.076 MFLOPs
Size 600: 507.117 MFLOPs
Average: 503.597 MFLOPs
--------------------------------------
Optimization3 : Optimization 2+ const key words+
6 way unroll of inner loop
 and 2 way unroll of outer loop , replacing sins and coss:
Size 300: 545.537 MFLOPs
Size 600: 545.537 MFLOPs
Average: 554.060 MFLOPs
--------------------------------------
Optimization4 : Optimization 2+ const key words ,
replcing sin and cos  computations in
 the conditionals+12 way inner loop unroll
+2 way unroll of outer loop:
Size 300: 625.537 MFLOPs
Size 600: 608.861 MFLOPs
Average: 617.199 MFLOPs
--------------------------------------
Optimization5 : Optimization 2+ const key words
+12 way unroll of inner loop and 2 way unroll of outer loop:
Size 300: 500.076 MFLOPs
Size 600: 486.559 MFLOPs
Average: 493.3175
--------------------------------------
Best: Optimization4 : Optimization 2+ const key words ,
replcing sin and cos computations in the conditionals:
Perf: 617.199 MFLOPs
--------------------------------------
