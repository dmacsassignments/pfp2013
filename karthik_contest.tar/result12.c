============================
O3 flag
============================
superslow: original function:
Size 300: 59.412 MFLOPs
Size 600: 53.970 MFLOPs
Average: 55.691 MFLOPs
--------------------------------------
Optimization 1 : Substitute for  get-element
 and set-element method:
Size 300: 42.610 MFLOPs
Size 600: 42.434 MFLOPs
Average: 42.522 MFLOPs
--------------------------------------
Optimization2 : Optimization 1 + loop exchange
 + bothloops 2 way unroll:
Size 300: 3600.360 MFLOPs
Size 600: 4000.667 MFLOPs
Average: 3800.513 MFLOPs
--------------------------------------
Optimization3 : Optimization 2+ const key words+
6 way unroll of inner loop 
and 2 way unroll of outer loop:
Size 300: 4000.444 MFLOPs
Size 600: 4000.667 MFLOPs
Average: 4000.556 MFLOPs
--------------------------------------
Optimization4 : Optimization 2+ const key words ,
replcing sin and cos  computations in
 the conditionals+12 way inner loop unroll
+2 way unroll of outer loop:
Size 300: 4049.31  MFLOPs
Size 600: 4186.926 MFLOPs
Average: 4118.118 MFLOPs
--------------------------------------
Optimization5 : Optimization 2+ const key words+
12 way unroll of inner loop and 2 way unroll of outer loop:
Size 300:4000.667
Size 600:3800.892
Average:3900.7795
--------------------------------------
Best:  Optimization4 : Optimization 2+ const key words ,
replcing sin and cos  computations in
 the conditionals+12 way inner loop unroll
+2 way unroll of outer loop:

Perf: 4118.118 MFLOPs
--------------------------------------
