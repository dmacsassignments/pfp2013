/*
* comp.c - contains the function superslow that you need to optimize
*
*
*/

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"
#include<immintrin.h>
/*#ifndef M_PI
#define M_PI           3.14159265358979323846
    #endif
*/// not using any where here in the superslow!!!

/* f(x1,x2, i, j) rotates the input vector
*/
double
f (double x1, double x2, double *y1, double *y2, int i, int j)
{
  double m[2][2];

  if (i % 4 == 0)
    {
      m[0][0] = cos (i);
      m[0][1] = sin (i);
      m[1][0] = -sin (i);
      m[1][1] = cos (i);
    }
  else
    {
      m[0][0] = cos (-i);
      m[0][1] = sin (-i);
      m[1][0] = -sin (-i);
      m[1][1] = cos (-i);

    }

  *y1 = m[0][0] * x1 + m[0][1] * x2;
  *y2 = m[1][0] * x1 + m[1][1] * x2;
}

/* This is the function you need to optimize. It takes one
square matrix as input
*/
void
superslow (smat_t * a)
{
  int i, j;
  double x1, x2, y1, y2;
  double sum1, sum2;
  // j is the column of a we're computing right now
  for (j = 0; j < a->n; j++)
    {
      // i is the row of a we're computing right now
      for (i = 0; i < a->n; i = i + 2)
	{
	  // First, compute f(A) for the element of a in question
	  x1 = get_elt (a, i, j);
	  x2 = get_elt (a, i + 1, j);
	  f (x1, x2, &y1, &y2, i, j);
	  // Add this to the value of a we're computing and store it                
	  sum1 = get_elt (a, i, j) + y1;
	  sum2 = get_elt (a, i + 1, j) + y2;
	  set_elt (a, i, j, sum1);
	  set_elt (a, i + 1, j, sum2);
	}
    }
}

void
superslow2 (smat_t * a)		//replacing the get and set methods
{
  int i, j;
  double y1, y2;
  double *mat = a->mat;
  int n = a->n;
  for (j = 0; j < n; j++)
    {
      for (i = 0; i < n; i = i + 2)
	{
	  register double x1, x2, sum1, sum2;
	  register int ni = i * n;
	  x1 = mat[ni + j];	
	  x2 = mat[(i + 1) * n + j];
	  f (x1, x2, &y1, &y2, i, j);
	  sum1 = x1 + y1;
	  sum2 = x2 + y2;
	  mat[ni + j] = sum1;
	  mat[(i + 1) * n + j] = sum2;
	}
    }
}

void
superslow3 (smat_t * a)		//loop exchange and 2 way unroll of both loops
{
  int i, j;
  double *mat = a->mat;
  int n = a->n;
  for (i = 0; i < n; i = i + 2)
    {
      register int ni = i * n;
      double m[2][2];
      if (i % 4 == 0)
	{
	  m[0][0] = cos (i);
	  m[0][1] = sin (i);
	  m[1][0] = -sin (i);
	  m[1][1] = cos (i);
	}
      else
	{
	  m[0][0] = cos (-i);
	  m[0][1] = sin (-i);
	  m[1][0] = -sin (-i), m[1][1] = cos (-i);
	}
      for (j = 0; j < n; j = j + 2)
	{
	  register double x1, x2, x3, x4, y1, y2, y3, y4, sum1, sum2, sum3,
	    sum4;
	  x1 = mat[ni + j];
	  x2 = mat[(i + 1) * n + j];
	  x3 = mat[ni + j + 1];
	  x4 = mat[(i + 1) * n + j + 1];
	  y1 = m[0][0] * x1 + m[0][1] * x2;
	  y2 = m[1][0] * x1 + m[1][1] * x2;
	  y3 = m[0][0] * x3 + m[0][1] * x4;
	  y4 = m[1][0] * x3 + m[1][1] * x4;
	  sum1 = x1 + y1;
	  sum2 = x2 + y2;
	  sum3 = x3 + y3;
	  sum4 = x4 + y4;
	  mat[ni + j] = sum1;
	  mat[(i + 1) * n + j] = sum2;
	  mat[ni + j + 1] = sum3;
	  mat[(i + 1) * n + j + 1] = sum4;
	}
    }
}

void
superslow4 (smat_t * a)		//inner loop unrolling by 6
{
  int i, j;
  register double *mat = a->mat;
  const int n = a->n;
  for (i = 0; i < n; i = i + 2)
    {
     register double kcos1 = cos(i),ksin1 = sin(i);
      register double kcos2 = cos(-i),ksin2 = sin(-i);
      register int ni = i * n;
      double m[2][2];
      if (i % 4 == 0)
	{
	  m[0][0] = kcos1;
	  m[0][1] = ksin1;
	  m[1][0] = -ksin1;
	  m[1][1] = kcos1;
	}
      else
	{
	  m[0][0] = kcos2;//cos (-i);
	  m[0][1] = ksin2;//sin (-i);
	  m[1][0] = -ksin2;
	  m[1][1] =kcos2;// cos (-i);
	}
      for (j = 0; j < n; j = j + 6)
	{
	  register double x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12;
	  register double y1, y2, y3, y4, y5, y6, y7, y8, y9, y10, y11, y12;
	  register double sum1, sum2, sum3, sum4, sum5, sum6, sum7, sum8,
	    sum9, sum10, sum11, sum12;
	  x1 = mat[ni + j];
	  x2 = mat[(i + 1) * n + j];
	  x3 = mat[ni + j + 1];
	  x4 = mat[(i + 1) * n + j + 1];
	  x5 = mat[ni + j + 2];
	  x6 = mat[(i + 1) * n + j + 2];
	  x7 = mat[ni + j + 3];
	  x8 = mat[(i + 1) * n + j + 3];
	  x9 = mat[ni + j + 4];
	  x10 = mat[(i + 1) * n + j + 4];
	  x11 = mat[ni + j + 5];
	  x12 = mat[(i + 1) * n + j + 5];

	  y1 = m[0][0] * x1 + m[0][1] * x2;
	  y2 = m[1][0] * x1 + m[1][1] * x2;
	  y3 = m[0][0] * x3 + m[0][1] * x4;
	  y4 = m[1][0] * x3 + m[1][1] * x4;
	  y5 = m[0][0] * x5 + m[0][1] * x6;
	  y6 = m[1][0] * x5 + m[1][1] * x6;
	  y7 = m[0][0] * x7 + m[0][1] * x8;
	  y8 = m[1][0] * x7 + m[1][1] * x8;
	  y9 = m[0][0] * x9 + m[0][1] * x10;
	  y10 = m[1][0] * x9 + m[1][1] * x10;
	  y11 = m[0][0] * x11 + m[0][1] * x12;
	  y12 = m[1][0] * x11 + m[1][1] * x12;

	  sum1 = x1 + y1;
	  sum2 = x2 + y2;
	  sum3 = x3 + y3;
	  sum4 = x4 + y4;
	  sum5 = x5 + y5;
	  sum6 = x6 + y6;
	  sum7 = x7 + y7;
	  sum8 = x8 + y8;
	  sum9 = x9 + y9;
	  sum10 = x10 + y10;
	  sum11 = x11 + y11;
	  sum12 = x12 + y12;

	  mat[ni + j] = sum1;
	  mat[(i + 1) * n + j] = sum2;
	  mat[ni + j + 1] = sum3;
	  mat[(i + 1) * n + j + 1] = sum4;
	  mat[ni + j + 2] = sum5;
	  mat[(i + 1) * n + j + 2] = sum6;
	  mat[ni + j + 3] = sum7;
	  mat[(i + 1) * n + j + 3] = sum8;
	  mat[ni + j + 4] = sum9;
	  mat[(i + 1) * n + j + 4] = sum10;
	  mat[ni + j + 5] = sum11;
	  mat[(i + 1) * n + j + 5] = sum12;

	}
    }
}

void
superslow5 (smat_t * a)		// use of temporary vars for sins and coss with 2 way loop unroll
{
  register int i, j;
  register double *mat = a->mat;
  const int n = a->n;
  for (i = 0; i < n; i = i + 2)
    {
      register int ni = i * n;
      register double kcos1 = cos (i), ksin1 = sin (i), kcos3 = cos (-i), ksin3 = sin (-i);	
      double m[2][2];
      if (i % 4 == 0)
	{
	  m[0][0] = kcos1;
	  m[0][1] = ksin1;
	  m[1][0] = -ksin1;
	  m[1][1] = kcos1;
	}
      else
	{
	  m[0][0] = kcos3;
	  m[0][1] = ksin3;
	  m[1][0] = -ksin3;
	  m[1][1] = kcos3;
	}
      for (j = 0; j < n; j = j + 2)
	{
	  register double x1, x2, x3, x4, y1, y2, y3, y4, sum1, sum2, sum3,
	    sum4;
	  x1 = mat[ni + j];
	  x2 = mat[(i + 1) * n + j];
	  x3 = mat[ni + j + 1];
	  x4 = mat[(i + 1) * n + j + 1];
	  y1 = m[0][0] * x1 + m[0][1] * x2;
	  y2 = m[1][0] * x1 + m[1][1] * x2;
	  y3 = m[0][0] * x3 + m[0][1] * x4;
	  y4 = m[1][0] * x3 + m[1][1] * x4;
	  sum1 = x1 + y1;
	  sum2 = x2 + y2;
	  sum3 = x3 + y3;
	  sum4 = x4 + y4;
	  mat[ni + j] = sum1;
	  mat[(i + 1) * n + j] = sum2;
	  mat[ni + j + 1] = sum3;
	  mat[(i + 1) * n + j + 1] = sum4;
	}
    }
}

void
superslow6 (smat_t * a)		//inner loop unrolling by 12 outer by 2 and same as superslow4 and move out cos and sin s
{
  int i, j;
  register double *mat = a->mat;
  const int n = a->n;
  for (i = 0; i < n; i = i + 2)
    {
     register double kcos1 = cos(i),ksin1 = sin(i);
      register double kcos2 = cos(-i),ksin2 = sin(-i);
      register int ni = i * n;
      double m[2][2];
      if (i % 4 == 0)
	{
	  m[0][0] = kcos1;
	  m[0][1] = ksin1;
	  m[1][0] = -ksin1;
	  m[1][1] = kcos1;;
	}
      else
	{
	  m[0][0] = kcos2;
	  m[0][1] = ksin2;
	  m[1][0] = -ksin2;
	  m[1][1] =kcos2;
	}
   for (j = 0; j < n; j = j + 12)
	{
	  register double x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12,
	    x13, x14, x15, x16, x17, x18, x19, x20, x21, x22, x23, x24;
	  register double y1, y2, y3, y4, y5, y6, y7, y8, y9, y10, y11, y12,
	    y13, y14, y15, y16, y17, y18, y19, y20, y21, y22, y23, y24;
	  register double sum1, sum2, sum3, sum4, sum5, sum6, sum7, sum8,
	    sum9, sum10, sum11, sum12;
	  register double sum13, sum14, sum15, sum16, sum17, sum18, sum19,
	    sum20, sum21, sum22, sum23, sum24;
	  x1 = mat[ni + j];
	  x2 = mat[(i + 1) * n + j];
	  x3 = mat[ni + j + 1];
	  x4 = mat[(i + 1) * n + j + 1];
	  x5 = mat[ni + j + 2];
	  x6 = mat[(i + 1) * n + j + 2];
	  x7 = mat[ni + j + 3];
	  x8 = mat[(i + 1) * n + j + 3];
	  x9 = mat[ni + j + 4];
	  x10 = mat[(i + 1) * n + j + 4];
	  x11 = mat[ni + j + 5];
	  x12 = mat[(i + 1) * n + j + 5];
	  x13 = mat[ni + j + 6];
	  x14 = mat[(i + 1) * n + j + 6];
	  x15 = mat[ni + j + 7];
	  x16 = mat[(i + 1) * n + j + 7];
	  x17 = mat[ni + j + 8];
	  x18 = mat[(i + 1) * n + j + 8];
	  x19 = mat[ni + j + 9];
	  x20 = mat[(i + 1) * n + j + 9];
	  x21 = mat[ni + j + 10];
	  x22 = mat[(i + 1) * n + j + 10];
	  x23 = mat[ni + j + 11];
	  x24 = mat[(i + 1) * n + j + 11];

	  y1 = m[0][0] * x1 + m[0][1] * x2;
	  y2 = m[1][0] * x1 + m[1][1] * x2;
	  y3 = m[0][0] * x3 + m[0][1] * x4;
	  y4 = m[1][0] * x3 + m[1][1] * x4;
	  y5 = m[0][0] * x5 + m[0][1] * x6;
	  y6 = m[1][0] * x5 + m[1][1] * x6;
	  y7 = m[0][0] * x7 + m[0][1] * x8;
	  y8 = m[1][0] * x7 + m[1][1] * x8;
	  y9 = m[0][0] * x9 + m[0][1] * x10;
	  y10 = m[1][0] * x9 + m[1][1] * x10;
	  y11 = m[0][0] * x11 + m[0][1] * x12;
	  y12 = m[1][0] * x11 + m[1][1] * x12;
	  y13 = m[0][0] * x13 + m[0][1] * x14;
	  y14 = m[1][0] * x13 + m[1][1] * x14;
	  y15 = m[0][0] * x15 + m[0][1] * x16;
	  y16 = m[1][0] * x15 + m[1][1] * x16;
	  y17 = m[0][0] * x17 + m[0][1] * x18;
	  y18 = m[1][0] * x17 + m[1][1] * x18;
	  y19 = m[0][0] * x19 + m[0][1] * x20;
	  y20 = m[1][0] * x19 + m[1][1] * x20;
	  y21 = m[0][0] * x21 + m[0][1] * x22;
	  y22 = m[1][0] * x21 + m[1][1] * x22;
	  y23 = m[0][0] * x23 + m[0][1] * x24;
	  y24 = m[1][0] * x23 + m[1][1] * x24;

	  sum1 = x1 + y1;
	  sum2 = x2 + y2;
	  sum3 = x3 + y3;
	  sum4 = x4 + y4;
	  sum5 = x5 + y5;
	  sum6 = x6 + y6;
	  sum7 = x7 + y7;
	  sum8 = x8 + y8;
	  sum9 = x9 + y9;
	  sum10 = x10 + y10;
	  sum11 = x11 + y11;
	  sum12 = x12 + y12;
	  sum13 = x13 + y13;
	  sum14 = x14 + y14;
	  sum15 = x15 + y15;
	  sum16 = x16 + y16;
	  sum17 = x17 + y17;
	  sum18 = x18 + y18;
	  sum19 = x19 + y19;
	  sum20 = x20 + y20;
	  sum21 = x21 + y21;
	  sum22 = x22 + y22;
	  sum23 = x23 + y23;
	  sum24 = x24 + y24;

	  mat[ni + j] = sum1;
	  mat[(i + 1) * n + j] = sum2;
	  mat[ni + j + 1] = sum3;
	  mat[(i + 1) * n + j + 1] = sum4;
	  mat[ni + j + 2] = sum5;
	  mat[(i + 1) * n + j + 2] = sum6;
	  mat[ni + j + 3] = sum7;
	  mat[(i + 1) * n + j + 3] = sum8;
	  mat[ni + j + 4] = sum9;
	  mat[(i + 1) * n + j + 4] = sum10;
	  mat[ni + j + 5] = sum11;
	  mat[(i + 1) * n + j + 5] = sum12;
	  mat[ni + j + 6] = sum13;
	  mat[(i + 1) * n + j + 6] = sum14;
	  mat[ni + j + 7] = sum15;
	  mat[(i + 1) * n + j + 7] = sum16;
	  mat[ni + j + 8] = sum17;
	  mat[(i + 1) * n + j + 8] = sum18;
	  mat[ni + j + 9] = sum19;
	  mat[(i + 1) * n + j + 9] = sum20;
	  mat[ni + j + 10] = sum21;
	  mat[(i + 1) * n + j + 10] = sum22;
	  mat[ni + j + 11] = sum23;
	  mat[(i + 1) * n + j + 11] = sum24;

	}
    }
}

/* 
* Called by the driver to register your functions
* Use add_function(func, description) to add your own functions
*/
void
register_functions ()
{
  // Registers comp_superslow with the driver
  add_function (&superslow, "superslow: original function");
  add_function (&superslow2,
		"Optimization 1 : Substitute for  get-element and set-element method");
  //Add your functions here
   add_function (&superslow3,
		"Optimization2 : Optimization 1 + loop exchange + bothloops 2 way unroll");
  add_function (&superslow4,
		"Optimization3 : Optimization 2+ const key words+6 way unroll of inner loop and 2 way unroll of outer loop , replcing sins and coss");
    add_function (&superslow5,
		"Optimization4 : Optimization 2+ const key words ,replcing sin and cos computations in the conditionals");
   add_function (&superslow6,
		"Optimization5 : Optimization 2+ const key words+12 way unroll of inner loop and 2 way unroll of outer loop");
}
