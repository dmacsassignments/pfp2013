#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define n 2000
#define m 3000

int main()
{
  double **a, **b, norm;
  int i, j, l;
  double a1,a2,a3,a4,norm1,norm2,norm3,norm4;
  a = (double**)malloc(n*sizeof(double*));
  b = (double**)malloc(n*sizeof(double*));

  for(i=0; i<n; i++)
    {
      a[i] = (double*)malloc(m*sizeof(double));
      for(j=0; j<n; j++) a[i][j] = drand48();
    }
    
  for(i=0; i<n; i++) b[i] = (double*)calloc(m, sizeof(double));
 
    for(l=0;l<=30;l++)
    {
      for(i=0;i<n;i+=2)
       {     
          for(j=0;j<m;j+=2)
	   {
		b[i][j] =  13*b[i][j]+a[i][j];
		b[i+1][j] =   13*b[i+1][j]+a[i+1][j];
		b[i][j+1] =   13*b[i][j+1]-a[i][j+1];
		b[i+1][j+1] =  13*b[i+1][j+1]-a[i+1][j+1];
	    }
       }
     }
norm = 0.0;
  for(i=0; i<n; i+=2)
   {
    for(j=0; j<m; j+=2)
    {
       a1=b[i][j];
       a2=b[i+1][j];
	a3=b[i][j+1];
	a4=b[i+1][j+1];
        norm1 = fabs(a1*a1);
	norm2 = norm1+fabs(a2*a2);
	norm3 = norm2+fabs(a3*a3);
	norm4 = norm3+fabs(a4*a4);
     norm =norm+ norm4 ;

    }}
  printf("norm: %10.4e    Value: %10.4e\n",norm, b[10][10]);
}
