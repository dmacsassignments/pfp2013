/*
 * comp.c - contains the function superslow that you need to optimize
 *
 *
 */

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


/* f(x, i, j) multiplies or divides by a sine expression depending
   on i + j being odd or even
*/
double f(double x, int i, int j)
{
    if((i + j) & 0x1)
        return x / (1 + sin(M_PI/(i+1)));
    else
        return x * sin(M_PI/(i+1));
}

/* This is the function you need to optimize. It takes one
   square matrix as input
*/
void superslow(smat_t *a)
{
    int i, j;
    double x,x2;

    // i is the column of a we're computing right now
    for(i = 0; i < a->n; i++)
    {
        // j is the row of a we're computing right now
        for(j = 0; j < a->n; j++)
        {
                // First, compute f(A) for the element of a in question
                        x = get_elt(a, i, j);
                x = f(x, i, j);

                // Add this to the value of a we're computing and store it
                x2 = get_elt(a, i, j);
                        x = x * x2;
                set_elt(a, i, j, x);

        }
    }
}

void superslow_kiran(smat_t *a)
{
    int i, j,an,in1,in2,in1j,in2j;
    double x11,x12,x21,x22,x31,x32,x41,x42;
    double sin_value1,sin_value2;
     an = a->n;
     double *mat = a->mat;
    for(i = 0; i < an; i+=2)
    {
	sin_value1=sin(M_PI/(i+1));
	sin_value2=sin(M_PI/(i+2));
	in1= i *an;
        in2 = (i+1) * an;
        for(j = 0; j < an; j+=2)
        {   
	 in1j = in1 + j ;
	 in2j = in2 + j ;       
		       x11= mat[in1j];
		       x21 = mat[in2j];
			x31 = mat[in1j+1];
			x41 = mat[in2j+1];
                if((i + j) & 0x1)
      	           x12= x11 / (1 + sin_value1);
  		else
	           x12= x11 * sin_value1;
		if(((i+1) + j) & 0x1)
		   x22 = x21 / (1 + sin_value2);
		else
		   x22 = x21 * sin_value2;
		if((i + (j+1)) & 0x1)
		   x32 = x31 / (1 + sin_value1);
		else
		   x32 = x31 * sin_value1;
		if(((i+1) + (j+1)) & 0x1)
		   x42 = x41 / (1 + sin_value2);
		else
		   x42 = x41 * sin_value2;

			mat[in1j] = x12 * x11;
			mat[in2j] = x22 * x21;
			mat[in1j+1] = x32 * x31;
			mat[in2j+1] = x42 * x41;
        }
    }
}
void superslow_kirru(smat_t *a)
{
    int i, j,an,in1,in2,in1j,in2j;
    int in1j1,in2j1;
    double x11,x12,x21,x22,x31,x32,x41,x42;
    double sin_value1,sin_value2;
     an = a->n;
     double *mat = a->mat;
    for(i = 0; i < an; i+=2)
    {
        sin_value1=sin(M_PI/(i+1));
        sin_value2=sin(M_PI/(i+2));
        in1= i *an;
        in2 =in1+an;
        for(j = 0; j < an; j+=2)
        {
         in1j = in1 + j ;
         in2j = in2 + j ;
	 in1j1 = in1j + 1;
         in2j1 = in2j + 1;

                       x11= mat[in1j];
                       x21 = mat[in2j];
                        x31 = mat[in1j1];
                        x41 = mat[in2j1];
		x12 = x11 * sin_value1;
		x22 = x21 / (1 + sin_value2);
		x32 = x31 / (1 + sin_value1);
		x42 = x41 * sin_value2;
                        mat[in1j] = x12 * x11;
                        mat[in2j] = x22 * x21;
                        mat[in1j1] = x32 * x31;
                        mat[in2j1] = x42 * x41;
        }
    }
}

void superslow_saikirru(smat_t *a)
{
    int i, j,an,in1,in2,in1j,in2j;
    int in1j1,in2j1;
    double x12,x22,x32,x42;
    double sin_value1,sin_value2;
     an = a->n;
     double *mat = a->mat;
    for(i = 0; i < an; i+=2)
    {
        sin_value1=sin(M_PI/(i+1));
        sin_value2=sin(M_PI/(i+2));
        in1= i *an;
        in2 = (i+1) * an;
        for(j = 0; j < an; j+=2)
        {
         in1j = in1 + j ;
         in2j = in2 + j ;
	 in1j1 = in1j + 1;
	 in2j1 = in2j + 1;
                    /*   x11= mat[in1j];
                       x21 = mat[in2j];
                        x31 = mat[in1j+1];
                        x41 = mat[in2j+1];*/
                x12 = mat[in1j] * sin_value1;
                x22 = mat[in2j] / (1 + sin_value2);
                x32 = mat[in1j1] / (1 + sin_value1);
                x42 = mat[in2j1] * sin_value2;
                        mat[in1j] = x12 * mat[in1j];
                        mat[in2j] = x22 * mat[in2j];
                        mat[in1j1] = x32 * mat[in1j1];
                        mat[in2j1] = x42 * mat[in2j1];
        }
    }
}
 
/* Called by the driver to register your functions
 * Use add_function(func, description) to add your own functions
 */
void register_functions()
{
    // Registers comp_superslow with the driver
     add_function(&superslow, "superslow: original function");
     add_function(&superslow_kiran, "superslow_kiran: changed function");
     add_function(&superslow_kirru,"superslow_kirru: changed function again");
     add_function(&superslow_saikirru,"superslow_saikirru: changed function again and again");	
	//Add your functions here
	//add_function(&superslow2, "superslow: Optimization X");
	
	
}
