#include<stdio.h>
#include<stdlib.h>
#include<error.h>
//#define  LARGE 100000
main(int argc ,char* argv[])
{
 if(argc != 2)
   perror("usage::./a.out <size of array>");
  double b=0;
   
   long long int c=0,a=0;
   c=atoll(argv[1]);
  long long int buffer[c];
  srand(1);
  for(a=0; a<c ; a++) // Initializing the array of long ints
  {
   buffer[a]=rand();
   b +=buffer[a];
  }
  
/*  for(a=0; a<c ; a++)
  {
    b +=buffer[a];
  }*/
  printf("%f\n",b);
}
