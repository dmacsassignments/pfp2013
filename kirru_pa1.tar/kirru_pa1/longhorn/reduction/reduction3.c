#include<stdio.h>
#include<stdlib.h>
#include<error.h>
//#define  LARGE 100000
main(int argc ,char* argv[])
{
 if(argc != 2)
   perror("usage::./a.out <size of array>");
  double b=0,b1=0,b2=0;
   long long int a=0,c;
//  long long int buffer[atoll(argv[1])];
  srand(1);
   c= atoll(argv[1]);
 long long int buffer[atoll(argv[1])];
  for(a=0; a< c  ; a+=2) // Initializing the array of long ints
  {
   buffer[a]=rand();
   buffer[a+1]=rand();
   b+= buffer[a];
   b1+=buffer[a+1];
   b = b+b1;
  // printf("%ld\n",buffer[a]);
  }
  
/*  for(a=0; a<atoll(argv[1]) ; a++)
  {
    b +=buffer[a];
  }*/
  printf("%f\n",b);
}
