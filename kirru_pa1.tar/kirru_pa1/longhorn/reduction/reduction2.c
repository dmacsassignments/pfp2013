#include<stdio.h>
#include<stdlib.h>
#include<error.h>
//#define  LARGE 100000
main(int argc ,char* argv[])
{
 if(argc != 2)
   perror("usage::./a.out <size of array>");
  double b=0,b1=0,b2=0,b3=0,b4=0,b5=0;
   
   long long int c=0,a=0;
   c=atoll(argv[1]);
  long long int buffer[c];
  srand(1);
  for(a=0; a<c ; a+=5) // Initializing the array of long ints
  {
   buffer[a]=rand();
   buffer[a+1]=rand();
   buffer[a+2]=rand();
   buffer[a+3]=rand();
   buffer[a+4]=rand();
//   b +=buffer[a];
  }
  
  for(a=0; a<c ; a+=6)
  {
    b +=buffer[a];
    b1 +=buffer[a+1];
    b2 +=buffer[a+2];
    b3 += buffer[a+3];
    b4 += buffer[a+4];
    b5 += buffer[a+5];
    b = b+b1+b2+b3+b4+b5;
  }
  printf("%f\n",b);
}
