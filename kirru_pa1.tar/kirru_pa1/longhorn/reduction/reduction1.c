#include<stdio.h>
#include<stdlib.h>
#include<error.h>
//#define  LARGE 100000
main(int argc ,char* argv[])
{
 if(argc != 2)
   perror("usage::./a.out <size of array>");
  double b;
   long long int a=0;
  long long int buffer[atoll(argv[1])];
  srand(1);
  for(a=0; a<atoll(argv[1]) ; a++) // Initializing the array of long ints
  {
   buffer[a]=rand();
  // printf("%ld\n",buffer[a]);
  }
  
  for(a=0; a<atoll(argv[1]) ; a++)
  {
    b +=buffer[a];
  }
  printf("%f\n",b);
}
