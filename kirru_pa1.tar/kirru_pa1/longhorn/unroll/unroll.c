
#include<stdlib.h>
#include <stdio.h>
#include <math.h>
#include "rdtsc.h"
#define N 100
#define NUM_RUNS 5
 typedef int data_t;
inline void Unrollx(data_t *y)
{
	float t1;
	int i,j;
	long int a1,a2,a3,a,a4,a5,a6,a7,a8;
	for ( i = 0; i < N; i+=8)
	{
		a+=y[i];
		a1+=y[i+1];
		a2+=y[i+2];
		a3+=y[i+3];
		a4+=y[i+4];
		a5+=y[i+5];
		a6+=y[i+6];
		a7+=y[i+7];
	}
/*        for(j=i;j<N;j++)
		a6+=y[j];*/

	a=a+a1+a2+a3+a4+a5+a6+a7;
}
int main()
{	
	 data_t * buffer;
	tsc_counter a, b;
	double cycles, baseline;
         int i;
	buffer = (int*)malloc(sizeof(int)*N*N);
	for ( i = 0; i<N; i++){
			buffer[i] = rand();	
	}
	Unrollx(buffer);

	CPUID(); RDTSC(a); CPUID(); RDTSC(b);
	CPUID(); RDTSC(a); CPUID(); RDTSC(b);

	RDTSC(a);
	for( i=0; i<NUM_RUNS; ++i)
	{ 
		Unrollx(buffer);
	}
	RDTSC(b);
	cycles = ((double)COUNTER_DIFF(b, a)) / ((double) NUM_RUNS);
	printf("%lf cycles \n",cycles);
	return 0;
}

