~~~~~~~~~~~~~~~~~~~~~~stampede~~~~~~~~~~~~~~~~~~~
tat -e L1-dcache-loads -e L1-dcache-stores ./unroll
4.000000 cycles

 Performance counter stats for './unroll':

           418,947 L1-dcache-loads                                           
           242,328 L1-dcache-stores                                          

       0.001239796 seconds time elapsed
~~~~~~~~~~~~~~~~~~~~~~~~unroll 2
c557-602$ time ./unroll
5.600000 cycles

real    0m0.002s
user    0m0.000s
sys     0m0.001s
c557-602$ ls
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~unroll = 4
c557-602$ time ./unroll
4.000000 cycles

real    0m0.002s
user    0m0.001s
sys     0m0.001s
c557-602$ vi unroll.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~unroll = 5
c557-602$ icc -unroll=0 unroll.c -o unroll
c557-602$ time ./unroll
7.200000 cycles

real    0m0.002s
user    0m0.000s
sys     0m0.002s


~~~~~~~~~~~~~~~~~~~~~~~~~~~Longhorn~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~unroll = 0~~~~~
c210-107% time ./unroll
4.000000 cycles
0.000u 0.001s 0:00.00 0.0%      0+0k 0+0io 0pf+0w
~~~~~~~~~~~~~~~~~~unroll = 2 ~~~~~~~
c210-107% icc -unroll=0 unroll.c -o unroll
c210-107% time ./unroll
4.000000 cycles
0.000u 0.000s 0:00.00 0.0%      0+0k 0+0io 0pf+0w
~~~~~~~~~~~~~~~~~~~~~~unroll = 3~~~~~~
c210-107% time ./unroll
4.000000 cycles
0.000u 0.001s 0:00.00 0.0%      0+0k 0+0io 0pf+0w
~~~~~~~~~~~~~~~~~~~~~~~unroll = 4~~~~~~
c210-107% time ./unroll
6.400000 cycles
0.000u 0.000s 0:00.00 0.0%      0+0k 0+0io 0pf+0w
~~~~~~~~~~~~~~~~~~~~~~~~~~~unroll = 5~~~~~
c210-107% time ./unroll
6.400000 cycles
0.000u 0.000s 0:00.00 0.0%      0+0k 0+0io 0pf+0w
~~~~~~~~~~~~~~~~~~~~~~ unroll = 6 ~~~~~~~
c210-107% time ./unroll
4.800000 cycles
0.000u 0.000s 0:00.00 0.0%      0+0k 0+0io 0pf+0w
~~~~~~~~~~~~~~~~~~~~~~ unroll = 7~~~~~~~~~~
c210-107% time ./unroll
4.800000 cycles
0.000u 0.000s 0:00.00 0.0%      0+0k 0+0io 0pf+0w
~~~~~~~~~~~~~~~~~~~~~~ unroll = 8 ~~~~~~
c210-105% time ./unroll
4.000000 cycles
0.000u 0.001s 0:00.00 0.0%      0+0k 0+0io 0pf+0w

