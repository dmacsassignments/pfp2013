#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/* print_shortest - prints the shortest of two strings */

char *shortest(char *str1, char *str2)
{
char *equal = "equal";
int len1 = strlen(str1);
int len2 = strlen(str2);
if (len1 == len2)
return equal;
else
return (len1 < len2 ? str1 : str2);
}

void print_shortest(char *str1, char *str2)
{
printf("The shortest string is %s\n", shortest(str1, str2));
}

int main(){
char* s1 ="hello";
char* s2 = "world1";
print_shortest(s1,s2);
}
