/*
* strndup - An attempt to write a safe version of strdup
*
* Note: For this problem, assume that if the function returns a
* non-NULL pointer to dest, then the caller eventually frees the dest
buffer.
*/
#include<stdio.h>
#include<stdlib.h>


/* Note: For this problem, asssume that if the function returns a non-
NULL
* pointer to node, then the caller eventually frees node. */
struct Node {
int data;
struct Node *next;
};

struct List {
struct Node *head;
};

struct Node *push(struct List *list, int data)
{
struct Node *node = (struct Node *)malloc(sizeof(struct Node));
if (!(list && node))
return NULL;
node->data = data;
node->next = list->head;
list->head = node;
return node;
}

int main(){
struct Node *n1 = (struct Node *)malloc(sizeof(struct Node));
n1->data = 7;
n1->next = NULL;
struct List *l1 = (struct List *)malloc(sizeof(struct List));
l1->head=n1;
struct Node *n2 = push(l1,9);
printf("result=%d\n",n2->data);
free(n1);
free(l1);
return 0;
}
