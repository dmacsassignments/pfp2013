/*
* strndup - An attempt to write a safe version of strdup
*
* Note: For this problem, assume that if the function returns a
* non-NULL pointer to dest, then the caller eventually frees the dest
buffer.
*/
#include<stdio.h>
#include<stdlib.h>
char *strndup1(char *src, int max)
{
char *dest;
int i;
if (!src || max <= 0)
return NULL;
dest = malloc(max+1);
for (i=0; i < max && src[i] != 0; i++)
dest[i] = src[i];
dest[i] = 0;
return dest;
}

int main(){

char* str = strndup1("hello world",20);
printf("new string:%s\n", str);
free(str);

}
