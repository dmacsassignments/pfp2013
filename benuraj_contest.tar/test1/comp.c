/*
* comp.c - contains the function superslow that you need to optimize
*
*
*/

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


/* f(x1,x2, i, j) rotates the input vector
*/
//#pragma auto_inline(on)
inline double f(double x1, double x2, double* y1, double * y2, int i, int j)
{
	double m[2][2];	

	if (i %4 == 0)
	{
		m[0][0] = cos(i);
		m[0][1] = sin(i);
		m[1][0] = -sin(i);
		m[1][1] = cos(i);
	}
	else
	{
		m[0][0] = cos(-i);
		m[0][1] = sin(-i);
		m[1][0] = -sin(-i);
		m[1][1] = cos(-i);

	}

	*y1 = m[0][0] * x1 + m[0][1]* x2;
	*y2 = m[1][0] * x1 + m[1][1]* x2;
return 0;
}

/* This is the function you need to optimize. It takes one
square matrix as input
*/
void superslow(smat_t *a)
{
	int i, j;
	double x1,x2,y1,y2;
	double sum1, sum2;


	// j is the column of a we're computing right now
	for(j = 0; j < a->n; j++)
	{

		// i is the row of a we're computing right now
		for(i = 0; i < a->n; i=i+2)        
		{            
			// First, compute f(A) for the element of a in question
			x1 = get_elt(a,i,j);
			x2 = get_elt(a,i+1,j);
			f(x1,x2,&y1,&y2, i, j);

			// Add this to the value of a we're computing and store it                
			sum1 = get_elt(a, i, j) + y1;
			sum2 = get_elt(a, i+1, j) + y2;
			set_elt(a, i, j, sum1);
			set_elt(a, i+1, j, sum2);            
		}
	}
}


void superslow1(smat_t *a)
{
	int i, j;
	double x1,x2,y1,y2;
	double sum1, sum2;

	int n = a->n;
        double *matrix = a->mat;	


	// j is the column of a we're computing right now
	for(j = 0; j < n; j++)
	{

		// i is the row of a we're computing right now
		for(i = 0; i < n; i=i+2)        
		{            
			// First, compute f(A) for the element of a in question
			x1 = get_elt(a,i,j);
			//x1 = matrix[i*n + j];
			x2 =get_elt(a,i+1,j);
			//x2 = matrix[(i+1) * n + j];
			
			f(x1,x2,&y1,&y2, i, j);

			// Add this to the value of a we're computing and store it                
			//sum1 = get_elt(a, i, j) + y1;
			//sum2 = get_elt(a, i+1, j) + y2;
			sum1 = x1 + y1;
			sum2 = x2 + y2;
			set_elt(a, i, j, sum1);
			set_elt(a, i+1, j, sum2);            
		}
	}
}



void superslow2(smat_t *a)
{
	int i, j;
	double x1,x2,y1,y2;
	double sum1, sum2;

	int n = a->n;
        double *matrix = a->mat;	


	// j is the column of a we're computing right now
	for(j = 0; j < n; j++)
	{

		// i is the row of a we're computing right now
		for(i = 0; i < n; i=i+2)        
		{            
			// First, compute f(A) for the element of a in question
			//x1 = get_elt(a,i,j);
			x1 = matrix[i*n + j];
			//x2 =get_elt(a,i+1,j);
			x2 = matrix[(i+1) * n + j];
			
			f(x1,x2,&y1,&y2, i, j);

			// Add this to the value of a we're computing and store it                
			//sum1 = get_elt(a, i, j) + y1;
			//sum2 = get_elt(a, i+1, j) + y2;
			sum1 = x1 + y1;
			sum2 = x2 + y2;

			set_elt(a, i, j, sum1);
			set_elt(a, i+1, j, sum2);            
		}
	}
}


void superslow3(smat_t *a)
{
	int i, j;
	double x1,x2,y1,y2;
	double sum1, sum2;
	register int n = a->n;
        register double *matrix = a->mat;	

	// j is the column of a we're computing right now

		// i is the row of a we're computing right now
		for(i = 0; i < n; i=i+2)        
		{            
			for(j = 0; j < n; j++)
			{
			// First, compute f(A) for the element of a in question
			//x1 = get_elt(a,i,j);
				x1 = matrix[i*n + j];
			//x2 =get_elt(a,i+1,j);
				x2 = matrix[(i+1) * n + j];
			
				f(x1,x2,&y1,&y2, i, j);

			// Add this to the value of a we're computing and store it                
			//sum1 = get_elt(a, i, j) + y1;
			//sum2 = get_elt(a, i+1, j) + y2;
				sum1 = x1 + y1;
				sum2 = x2 + y2;

			//set_elt(a, i, j, sum1);
				matrix[i*n + j] = sum1;
			//set_elt(a, i+1, j, sum2);            
				matrix[(i+1)*n + j] = sum2;
			}
		}
}


void superslow4(smat_t *a)
{
	int i, j;
	double x1,x2,y1,y2;
	double sum1, sum2;

	register double tmp1, tmp2;
	register int n = a->n;
        register double *matrix = a->mat;	

	// j is the column of a we're computing right now

		// i is the row of a we're computing right now
		for(i = 0; i < n; i=i+2)        
		{            
			for(j = 0; j < n; j++)
			{
				x1 = matrix[i*n + j];
				x2 = matrix[(i+1) * n + j];
			
			//f(x1,x2,&y1,&y2, i, j);
				tmp1 = cos(i);
				tmp2 = sin(i);
				if(i%4 == 0){
					y1 = tmp1 * x1 + tmp2 * x2;
					y2 = tmp1 * x2 - tmp2 * x1;
				}
				else{
					y1 = tmp1 * x1 - tmp2 * x2;
					y2 = tmp1 * x2 + tmp2 * x1;
				}

				sum1 = x1 + y1;
				sum2 = x2 + y2;

				matrix[i*n + j] = sum1;
				matrix[(i+1)*n + j] = sum2;
			}
		}
}

void superslow5(smat_t *a)
{
	int i, j;
	double x1,x2,y1,y2;
	double sum1, sum2;

	register double tmp1, tmp2;
	register int n = a->n;
        register double *matrix = a->mat;	

	// j is the column of a we're computing right now

		// i is the row of a we're computing right now
		for(i = 0; i < n; i=i+2)        
		{            
				tmp1 = cos(i);
				tmp2 = sin(i);
			for(j = 0; j < n; j++)
			{
				x1 = matrix[i*n + j];
				x2 = matrix[(i+1) * n + j];
			//	x3 = matrix[(i+2) * n + j];
			//	x4 = matrix[(i+3) * n + j];
			
			//f(x1,x2,&y1,&y2, i, j);
			/*	y11 = tmp1 * x1 + tmp2 * x2;
				y21 = tmp1 * x2 - tmp2 * x1;
				
				y12 = tmp1 * x1 - tmp2 * x2;
				y22 = tmp1 * x2 + tmp2 * x1;
				
				y13 = tmp1 * x3 - tmp2 * x4;
				y23 = tmp1 * x4 + tmp2 * x3;
				*/if(i%4 == 0){
					y1 = tmp1 * x1 + tmp2 * x2;
					y2 = tmp1 * x2 - tmp2 * x1;
				}
				else{
					y1 = tmp1 * x1 - tmp2 * x2;
					y2 = tmp1 * x2 + tmp2 * x1;
				}

				sum1 = x1 + y1;
				sum2 = x2 + y2;
				

				matrix[i*n + j] = sum1;
				matrix[(i+1)*n + j] = sum2;
			}
		}
}

void superslow6(smat_t *a)
{
	int i, j;
	double x1,x2,x3,x4,y1,y2,y3,y4;
	register double sum1, sum2,sum3,sum4;

	register double tmp1, tmp2,tmp3,tmp4;
	register int n = a->n;
        register double *matrix = a->mat;	


		// i is the row of a we're computing right now
		for(i = 0; i < n; i=i+4)        
		{            
			tmp1 = cos(i);
			tmp2 = sin(i);
			tmp3 = cos(i+2);
			tmp4 = sin(i+2);
				// j is the column of a we're computing right now
			for(j = 0; j < n; j++)
			{
				x1 = matrix[i*n + j];
				x2 = matrix[(i+1) * n + j];
				x3 = matrix[(i+2) * n + j];
				x4 = matrix[(i+3) * n + j];
			
				y1 = tmp1 * x1 + tmp2 * x2;
				y2 = tmp1 * x2 - tmp2 * x1;
				
				y3 = tmp3 * x3 - tmp4 * x4;
				y4 = tmp3 * x4 + tmp4 * x3;
				
				//f(x1,x2,&y1,&y2, i, j);
				//y5 = tmp1 * x3 - tmp2 * x4;
				//y6 = tmp1 * x4 + tmp2 * x3;
				/*if(i%4 == 0){
					y1 = tmp1 * x1 + tmp2 * x2;
					y2 = tmp1 * x2 - tmp2 * x1;
				}
				else{
					y1 = tmp1 * x1 - tmp2 * x2;
					y2 = tmp1 * x2 + tmp2 * x1;
				}*/
				sum1 = x1 + y1;
				sum2 = x2 + y2;
				sum3 = x3 + y3;
				sum4 = x4 + y4;
				

				matrix[i*n + j] = sum1;
				matrix[(i+1)*n + j] = sum2;
				matrix[(i+2)*n + j] = sum3;
				matrix[(i+3)*n + j] = sum4;
			}
		}
}


/* 
* Called by the driver to register your functions
* Use add_function(func, description) to add your own functions
*/
void register_functions()
{
	// Registers comp_superslow with the driver
	add_function(&superslow, "superslow: original function");
	add_function(&superslow1, "superslow: optimization1");
	add_function(&superslow2, "superslow: optimization2");
	add_function(&superslow3, "superslow: optimization3");
	add_function(&superslow4, "superslow: optimization4");
	add_function(&superslow5, "superslow: optimization5");
	add_function(&superslow6, "superslow: optimization6");
//	add_function(&fast, "fast: optimized version 1");
	//Add your functions here
	//add_function(&superslow2, "superslow: Optimization X");


}
