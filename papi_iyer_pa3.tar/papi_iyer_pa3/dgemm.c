const char* dgemm_desc = "Simple blocked dgemm.";
#include<stdlib.h>
#include<smmintrin.h> 
#include<nmmintrin.h>
#include <immintrin.h>
#define RB ((int)4)
//#define BLOCK_SIZE ((int)64)
/*
  A is M-by-K
  B is K-by-N
  C is M-by-N

  lda is the leading dimension of the matrix (the M of square_dgemm).
*/
int BLOCK_SIZE=0;


void avx_dgemm(const int M, 
                  const double* __restrict__ A, const double* __restrict__ B, double* __restrict__ C)
{
   register int i,j,ii,jj,kk,temp,temp1,nb;
   register double *jtemp,*j1temp;
   register double *aPointer =NULL;
   register double *bPointer =NULL;
   register double *cPointer =NULL;
   register double *aaligned =NULL;
   nb=BLOCK_SIZE;
   /*    aaligned=memalign(32,BLOCK_SIZE*BLOCK_SIZE*sizeof(double));
       for(i=0;i<nb;++i){
        temp = i*nb;
        temp1 =i*M;
         for(j=0;j<nb;j+=8){

          jtemp= aaligned+temp+j;
          j1temp = A+temp1+j;      
             *(jtemp)=*(j1temp);jtemp++;j1temp++;
	     *(jtemp)=*(j1temp);jtemp++;j1temp++;
             *(jtemp)=*(j1temp);jtemp++;j1temp++;
             *(jtemp)=*(j1temp);jtemp++;j1temp++;
             *(jtemp)=*(j1temp);jtemp++;j1temp++;
             *(jtemp)=*(j1temp);jtemp++;j1temp++;
             *(jtemp)=*(j1temp);jtemp++;j1temp++;
             *(jtemp)=*(j1temp);
  } 

}*/

		for (jj= 0; jj <BLOCK_SIZE ; jj+=RB) {
                    for (kk= 0; kk <BLOCK_SIZE; kk+=RB) {
                       bPointer = B+kk+jj*M;
                        for (ii= 0; ii <BLOCK_SIZE; ii+=RB){

 
//              aPointer = aaligned +ii+kk*BLOCK_SIZE;
                aPointer = A +ii+kk*M;

                cPointer = C+ii+jj*M;
 

		 __m256d a0 = _mm256_loadu_pd(aPointer);
		 __m256d a1 = _mm256_loadu_pd(aPointer + M);
                 __m256d a2 = _mm256_loadu_pd(aPointer + 2*M);
		 __m256d a3 = _mm256_loadu_pd(aPointer + 3*M);

	
	
		 __m256d c0 = _mm256_add_pd(
			_mm256_add_pd(
				_mm256_mul_pd(a0,  _mm256_set1_pd(*(bPointer))),
				_mm256_mul_pd(a1,  _mm256_set1_pd(*(bPointer+1)))
			),
			_mm256_add_pd(
				_mm256_mul_pd(a2,  _mm256_set1_pd(*(bPointer+2))),
				_mm256_mul_pd(a3,  _mm256_set1_pd(*(bPointer+3)))
			)
		);

		 
			


		
		 __m256d c1 = _mm256_add_pd(
			_mm256_add_pd(
				_mm256_mul_pd(a0,  _mm256_set1_pd(*(bPointer+M))),
				_mm256_mul_pd(a1,  _mm256_set1_pd(*(bPointer+M+1)))
			),
			_mm256_add_pd(
				_mm256_mul_pd(a2,  _mm256_set1_pd(*(bPointer+M+2))),
				_mm256_mul_pd(a3,  _mm256_set1_pd(*(bPointer+M+3)))
			)
		);

	 	 __m256d c2 = _mm256_add_pd(
			_mm256_add_pd(
				_mm256_mul_pd(a0,  _mm256_set1_pd(*(bPointer+2*M))),
				_mm256_mul_pd(a1,  _mm256_set1_pd(*(bPointer+2*M+1)))
			),
			_mm256_add_pd(
				_mm256_mul_pd(a2,  _mm256_set1_pd(*(bPointer+2*M+2))),
				_mm256_mul_pd(a3,  _mm256_set1_pd(*(bPointer+2*M+3)))
			)
		);

		 __m256d c3 = _mm256_add_pd(
			_mm256_add_pd(
				_mm256_mul_pd(a0,  _mm256_set1_pd(*(bPointer+3*M))),
				_mm256_mul_pd(a1,  _mm256_set1_pd(*(bPointer+3*M+1)))
			),
			_mm256_add_pd(
				_mm256_mul_pd(a2,  _mm256_set1_pd(*(bPointer+3*M+2))),
				_mm256_mul_pd(a3,  _mm256_set1_pd(*(bPointer+3*M+3)))
			)
		);
		



		 __m256d c4 = _mm256_loadu_pd(cPointer );
		 __m256d c5 = _mm256_loadu_pd(cPointer + M);
		 __m256d c6 = _mm256_loadu_pd(cPointer + 2*M);
		 __m256d c7 = _mm256_loadu_pd(cPointer + 3*M);

		  c4 = _mm256_add_pd(c0,c4);
		  c5 = _mm256_add_pd(c1,c5);
		  c6 = _mm256_add_pd(c2,c6);
		  c7 = _mm256_add_pd(c3,c7);

		_mm256_storeu_pd(cPointer, c4);
		_mm256_storeu_pd(cPointer + M, c5);
		_mm256_storeu_pd(cPointer + 2*M, c6);
		_mm256_storeu_pd(cPointer + 3*M, c7);

	  


			               
                                           }
                                       }
                                   }
                               
                          
                      
                 



//free(aaligned);

}
             
void basic_dgemm(const int lda, const int M, const int N, const int K,
                 const double *__restrict__ A, const double *__restrict__ B, double *__restrict__ C)
{  

   if(M==BLOCK_SIZE && M==N && N==K)
	avx_dgemm(lda,A,B,C);
   else
   {

  register int i, j, k;
  register double b1, b2, b3, b4, b5, b6, b7, b8;
  for (j = 0; j < N; ++j) {
  for (k = 0; k < (K - 7); k += 8) {
  b1 = B[j*lda + k];
  b2 = B[j*lda + k + 1];
  b3 = B[j*lda + k + 2];
  b4 = B[j*lda + k + 3];
  b5 = B[j*lda + k + 4];
  b6 = B[j*lda + k + 5];
  b7 = B[j*lda + k + 6];
  b8 = B[j*lda + k + 7];
  for (i = 0; i < M; ++i) {
   C[j*lda + i] += A[k*lda + i] * b1;
   C[j*lda + i] += A[(k+1)*lda + i] * b2;
   C[j*lda + i] += A[(k+2)*lda + i] * b3;
   C[j*lda + i] += A[(k+3)*lda + i] * b4;
   C[j*lda + i] += A[(k+4)*lda + i] * b5;
   C[j*lda + i] += A[(k+5)*lda + i] * b6;
   C[j*lda + i] += A[(k+6)*lda + i] * b7;
   C[j*lda + i] += A[(k+7)*lda + i] * b8;
   }
   }
   if(K % 8) {
   do {
   b1 = B[j*lda + k];
   for (i = 0; i < M; ++i) {
   C[j*lda + i] += A[k*lda + i] * b1;
   }
   }
   while(++k < K);
   }
   }

 
   }
}
void do_block(const int lda,
              const double * __restrict__ A, const double * __restrict__ B, double * __restrict__ C,
              const int i, const int j, const int k)
{
    register const int M = (i+BLOCK_SIZE > lda? lda-i : BLOCK_SIZE);
    register const int N = (j+BLOCK_SIZE > lda? lda-j : BLOCK_SIZE);
    register const int K = (k+BLOCK_SIZE > lda? lda-k : BLOCK_SIZE);
    basic_dgemm(lda, M, N, K,
                A + i + k*lda, B + k + j*lda, C + i + j*lda);
}

void square_dgemm(const int M, const double * __restrict__ A, const double *__restrict__ B, double *__restrict__ C,register int NB)
{ 
BLOCK_SIZE=NB;
    register const int n_blocks = M / BLOCK_SIZE + (M%BLOCK_SIZE? 1 : 0);
    register int bi, bj, bk;
    for (bi = 0; bi < n_blocks; ++bi) {
        const int i = bi * BLOCK_SIZE;
        for (bj = 0; bj < n_blocks; ++bj) {
            const int j = bj * BLOCK_SIZE;
            for (bk = 0; bk < n_blocks; ++bk) {
                const int k = bk * BLOCK_SIZE;
                do_block(M, A, B, C, i, j, k);
            }
        }
    }
}

