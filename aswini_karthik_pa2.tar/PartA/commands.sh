 make clean
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home1/02240/pkarthik/iaca-lin32/lib

make
 ~/iaca-lin32/bin/iaca -64 -arch SNB -o Vec_saxpy.txt ./saxpy
~/iaca-lin32/bin/iaca -64 -arch SNB -analysis LATENCY -o Vec_saxpy_latency.txt ./saxpy

