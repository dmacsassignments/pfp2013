/*
 * MVM 5x5
 */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <tmmintrin.h>
#include<smmintrin.h>
#include "utils.h"
#include "rdtsc.h"


// Procedure mvm5: Serial code (do not need to modify)

void mvm5(float const * A, float const * x, float * y) {
  int i;
  float t;
  int j;
  for(i = 0; i < 5; i++) {
      t = 0.f;
      for(j = 0; j < 5; j++)
       {    t += A[i*5+j]*x[j];
             printf("i = %d ,J = %d A[i*5+j]*x[j] = %f * %f \t\n",i,j,A[i*5+j],x[j]);} 
      y[i] = t;
  }

}



// Procedure vec_mvm5: vector code
// Implement WITHOUT unaligned instructions

void vec_mvm5(float const * A, float const * x, float * y) {

  __m128 a0 = _mm_load_ps(A);                       /* loading the matrix A*/
  __m128 a1 = _mm_load_ps(A + 4);
  __m128 a2 = _mm_load_ps(A + 8);
  __m128 a3 = _mm_load_ps(A + 12);
  __m128 a4 = _mm_load_ps(A + 16);
  __m128 a5 = _mm_load_ps(A + 20);
  __m128 a6 = _mm_load_ss(A + 24);

  __m128 x0 = _mm_load_ps(x);			/* loading the vector X*/
  __m128 x1 = _mm_load_ps1(x + 4);


  __m128i a1i = _mm_castps_si128(a1);
  __m128i a2i = _mm_castps_si128(a2);
  __m128i a3i = _mm_castps_si128(a3);
  __m128i a4i = _mm_castps_si128(a4);
  __m128 a22 = _mm_castsi128_ps(_mm_alignr_epi8(a2i, a1i, 4));  /* getting 5,6,7,8 elements of A*/
  __m128 a33 = _mm_castsi128_ps(_mm_alignr_epi8(a3i, a2i, 8)); /* getting 10,11,12,13 elements of A*/
  __m128 a44 = _mm_castsi128_ps(_mm_alignr_epi8(a4i, a3i, 12));/* getting 15,16,17,18 elements of A*/

  __m128 t1 = _mm_shuffle_ps(a1, a2, _MM_SHUFFLE(1,1,0,0));  
  __m128 t2 = _mm_shuffle_ps(a3, a4, _MM_SHUFFLE(3,3,2,2));  
  __m128 a11 = _mm_shuffle_ps(t1, t2, _MM_SHUFFLE(2,0,2,0));  /* getting 4,9,14,19 elements of A*/

 
__m128 bv = _mm_set_ps(0.0,0.0,0.0,0.0);
__m128 b0 = _mm_dp_ps(a0,x0,241);bv = _mm_add_ps(bv,b0); /* dot products*/
__m128 b1 = _mm_dp_ps(a22,x0,242); bv = _mm_add_ps(bv,b1);
__m128 b2 = _mm_dp_ps(a33,x0,244);bv=_mm_add_ps(bv,b2);
__m128 b3 = _mm_dp_ps(a44,x0,248);bv=_mm_add_ps(bv,b3);

__m128 v = _mm_mul_ps(a11,x1);bv =_mm_add_ps(bv,v);


		__m128 y1 = _mm_dp_ps(a5,x0,241); /* for the last row to be part of last element of the product */
		__m128 y2 = _mm_dp_ps(a6,x1,241);
		__m128 kv1 = _mm_add_ss(y1,y2);
		
		_mm_store_ss(y+4,kv1);	_mm_store_ps(y, bv); /* finally storing the product vector in y */

}




/*
 * Do not need to modify from here on
 */

#define RUNS     400
#define CYCLES_REQUIRED 1e7

void verify(float const * A, float const * x, float const * y)
{
  int i;
  double err;
  int j;
  float * temp = (float *) _mm_malloc(sizeof(float)*5, 16);
  setzero(temp, 5, 1);

  for(i = 0; i < 5; i++) {
      for(j = 0; j < 5; j++)
        temp[i] += A[i*5+j]*x[j];
      err = fabs(y[i] - temp[i]);
      if(err > 1E-5)
        {
          printf("Error at y[%d]\n", i);
        }
  }

  _mm_free(temp);

}

void test_vec_mvm5(float const * A, float const * x, float * y)
{
  tsc_counter start, end;
  double cycles = 0.;
  size_t num_runs = RUNS;
  int i;

  //Cache warm-up
  // RDTSCP reads ts register guaranteeing that the execution of all the code
  // we wanted to measure is completed. This way we avoid including the
  // execution of a CPUID in between. The last CPUID guarantees no other
  // instruction can be scheduled before it (and so also before RDTSCP)

  CPUID(); RDTSC(start); CPUID(); RDTSC(end);
  CPUID(); RDTSC(start); CPUID(); RDTSC(end);
  CPUID(); RDTSC(start); CPUID(); RDTSC(end);

 while(1) {
      CPUID(); RDTSC(start);
      for (i = 0; i < num_runs; ++i) {
          vec_mvm5(A, x, y);
      }
      CPUID(); RDTSC(end);

      cycles = (double)(COUNTER_DIFF(end, start));

      if(cycles >= CYCLES_REQUIRED) break;

      num_runs *= 2;

  }

  CPUID(); RDTSC(start);
 for (i = 0; i<num_runs; ++i) {
    vec_mvm5(A, x, y);
  }
  CPUID(); RDTSC(end);

  cycles = (double)(COUNTER_DIFF(end, start))/num_runs;

  printf("Test vec_mvm5  - Performance [flops/cycle]: %f\n", 45/cycles);

#ifdef VERIFY
  verify(A, x, y);
#endif

}


int main()
{
  float * A = (float *) _mm_malloc(sizeof(float)*25, 16);
  float * x = (float *) _mm_malloc(sizeof(float)*5, 16);
  float * y = (float *) _mm_malloc(sizeof(float)*5, 16);

  setrandom(A, 5, 5);
  setrandom(x, 5, 1);

  test_vec_mvm5(A, x, y);
 _mm_free(A);_mm_free(x);_mm_free(y);
  return 0;
}
