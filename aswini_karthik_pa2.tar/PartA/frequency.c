#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<sys/time.h>
#define R 1000000000
main()
{
  volatile int v = 0;
  volatile int vr = 0;
  register int r1 = vr;
  register int r2 = vr;
  struct timeval start, end;
  register float t1;
  register int U=10,i = R / U;
 
    /*  WARM UP */
  
  switch (v)
  {
	case 0: loop1:
	case 1: r1 += r2;
	case 2: r1 += r2;
	case 3: r1 += r2;
	case 4: r1 += r2;
	case 5: r1 += r2;
	case 6: r1 += r2;
	case 7: r1 += r2;
	case 8: r1 += r2;
	case 9: r1 += r2;
	case 10: r1 += r2;
	if (--i) goto loop1;
  }    /* WARM UP ENDS */
  
  v=0; vr=0;   r1=vr;  r2=vr;  U=10; i=R/U;  

  gettimeofday(&start,NULL);
  switch (v)
  {
	case 0: loop:
	case 1: r1 += r2;
	case 2: r1 += r2;
	case 3: r1 += r2;
	case 4: r1 += r2;
	case 5: r1 += r2;
	case 6: r1 += r2;
	case 7: r1 += r2;
	case 8: r1 += r2;
	case 9: r1 += r2;
	case 10: r1 += r2;
	if (--i) goto loop;
  }
  gettimeofday(&end,NULL);
  if (!v)
  {
    t1 = ((end.tv_sec * 1000000 + end.tv_usec) - (start.tv_sec * 1000000 + start.tv_usec));
    printf("Observed Frequency of the processor :  %f GHz\n", 100000/t1);
  }
}
