/*
 * MVM 5x5
 */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

#include <tmmintrin.h>

#include "utils.h"
#include "rdtsc.h"


// Procedure mvm5: Serial code (do not need to modify)

void mvm5(float const * A, float const * x, float * y) {
  int i;
  float t;
  int j;
  for(i = 0; i < 5; i++) {
      t = 0.f;
      for(j = 0; j < 5; j++)
        t += A[i*5+j]*x[j];
      y[i] = t;
  }

}



// Procedure vec_mvm5: vector code
// Implement WITHOUT unaligned instructions

void vec_mvm5(float const * A, float const * x, float * y) {

__m128 r0 = _mm_load_ps(&A[0]);
__m128 r1 = _mm_load_ps(&A[5]);
__m128 r2 = _mm_load_ps(&A[10]);
__m128 r3 = _mm_load_ps(&A[15]);
__m128 r4 = _mm_load_ps(&A[20]);
__m128 r5 = _mm_set_ps(A[19],A[14],A[9],A[4]);
__m128 r6 = _mm_set1_ps(A[24]);

__m128 v1 = _mm_load_ps(&x[0]);
__m128 v2 = _mm_set1_ps(x[4]);

__m128 o0 = _mm_mul_ps(r0,v1);
o0 = _mm_hadd_ps(o0,o0);
o0 = _mm_hadd_ps(o0,o0);
__m128 o1 = _mm_mul_ps(r1,v1);
o1 = _mm_hadd_ps(o1,o1);
o1 = _mm_hadd_ps(o1,o1);
__m128 o2 = _mm_mul_ps(r2,v1);
o2 = _mm_hadd_ps(o2,o2);
o2 = _mm_hadd_ps(o2,o2);
__m128 o3 = _mm_mul_ps(r3,v1);
o3 = _mm_hadd_ps(o3,o3);
o3 = _mm_hadd_ps(o3,o3);
__m128 o4 = _mm_mul_ps(r4,v1);
o4 = _mm_hadd_ps(o4,o4);
o4 = _mm_hadd_ps(o4,o4);

__m128 o5 = _mm_mul_ps(r5,v2);

o0 = _mm_add_ps(o0,o5);
o1 = _mm_add_ps(o1,o5);
o2 = _mm_add_ps(o2,o5);
o3 = _mm_add_ps(o3,o5);

r6  = _mm_mul_ps(r6,v2);
o4  = _mm_add_ps(r6,o4);

//_mm_store_ps(y,o4);

__m128 c = _mm_shuffle_ps(o0,o1,_MM_SHUFFLE(1,1,0,0));

__m128 s = _mm_shuffle_ps(o2,o3,_MM_SHUFFLE(3,3,2,2));
__m128 temp = _mm_shuffle_ps(c,s,_MM_SHUFFLE(2,0,2,0));

_mm_store_ps(y,temp);
_mm_store_ss((y+4),o4);
//printf("%f %f %f %f %f",y[0],y[1],y[2],y[3],y[4]);
}




/*
 * Do not need to modify from here on
 */

#define RUNS     400
#define CYCLES_REQUIRED 1e7

void verify(float const * A, float const * x, float const * y)
{
  int i;
  double err;
  int j;
  float * temp = (float *) _mm_malloc(sizeof(float)*5, 16);
  setzero(temp, 5, 1);

  for(i = 0; i < 5; i++) {
      for(j = 0; j < 5; j++)
        temp[i] += A[i*5+j]*x[j];
      err = fabs(y[i] - temp[i]);
      printf("%f\n",temp[i]);
      printf("%f\n",y[i]);
      if(err > 1E-5)
        {
          printf("Error at y[%d]\n", i);
        }
  }

  _mm_free(temp);

}

void test_vec_mvm5(float const * A, float const * x, float * y)
{
  tsc_counter start, end;
  double cycles = 0.;
  size_t num_runs = RUNS;
  int i;

  //Cache warm-up
  // RDTSCP reads ts register guaranteeing that the execution of all the code
  // we wanted to measure is completed. This way we avoid including the
  // execution of a CPUID in between. The last CPUID guarantees no other
  // instruction can be scheduled before it (and so also before RDTSCP)

  CPUID(); RDTSC(start); CPUID(); RDTSC(end);
  CPUID(); RDTSC(start); CPUID(); RDTSC(end);
  CPUID(); RDTSC(start); CPUID(); RDTSC(end);

  while(1) {
      CPUID(); RDTSC(start);
      for (i = 0; i < num_runs; ++i) {
          vec_mvm5(A, x, y);
      }
      CPUID(); RDTSC(end);

      cycles = (double)(COUNTER_DIFF(end, start));

      if(cycles >= CYCLES_REQUIRED) break;

      num_runs *= 2;

  }

  CPUID(); RDTSC(start);
  for (i = 0; i < num_runs; ++i) {
      vec_mvm5(A, x, y);
  }
  CPUID(); RDTSC(end);

  cycles = (double)(COUNTER_DIFF(end, start))/num_runs;

  printf("Test vec_mvm5  - Performance [flops/cycle]: %f\n", 45/cycles);

#ifdef VERIFY
  verify(A, x, y);
#endif

}


int main()
{
  float * A = (float *) _mm_malloc(sizeof(float)*25, 16);
  float * x = (float *) _mm_malloc(sizeof(float)*5, 16);
  float * y = (float *) _mm_malloc(sizeof(float)*5, 16);

  setrandom(A, 5, 5);
  setrandom(x, 5, 1);

  test_vec_mvm5(A, x, y);

  return 0;
}
