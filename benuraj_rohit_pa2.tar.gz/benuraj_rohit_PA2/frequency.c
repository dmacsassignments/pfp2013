#include<stdlib.h>
#include<stdio.h>
#include<sys/time.h>

#define R 1000000

int main(){
	
	volatile int v0 = 0;
	volatile int v1 = 0;

	register int r1 = v1;
	register int r2 = v1;
	
	int i;
	struct timeval start, end;
	//tsc_counter start, end;
	i = R/10;
	gettimeofday(&start, NULL);
	switch(v0){
		case 0:
			//RDTSC(start);
			loop:
		case 1:
			r1 += r2;
		case 2:
			r1 += r2;
		case 3:
			r1 += r2;
		case 4:
			r1 += r2;
		case 5:
			r1 += r2;
		case 6:
			r1 += r2;
		case 7:
			r1 += r2;
		case 8:
			r1 += r2;
		case 9:
			r1 += r2;
		case 10:
			r1 += r2;
			if(--i)	
				goto loop;
			//RDTSC(end) ;
			if(!v0){
				
				gettimeofday(&end,NULL);
				printf("Time Elapsed %f\n", (double)((end.tv_sec * 1000000+ end.tv_usec) - (start.tv_sec *1000000 + start.tv_usec))/1000);
			}


	}
	v1 =r1;
	v1 =r2;
return 0;
}


