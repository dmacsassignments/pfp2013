/*
* comp.c - contains the function superslow that you need to optimize
*
*
*/

#include <math.h>
#include <stdio.h>
#include "comp.h"
#include "perf.h"

#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif


/* f(x1,x2, i, j) rotates the input vector
*/
double f(double x1, double x2, double* y1, double * y2, int i, int j)
{
	double m[2][2];	

	if (i %4 == 0)
	{
		m[0][0] = cos(i);
		m[0][1] = sin(i);
		m[1][0] = -sin(i);
		m[1][1] = cos(i);
	}
	else
	{
		m[0][0] = cos(-i);
		m[0][1] = sin(-i);
		m[1][0] = -sin(-i);
		m[1][1] = cos(-i);

	}

	*y1 = m[0][0] * x1 + m[0][1]* x2;
	*y2 = m[1][0] * x1 + m[1][1]* x2;
}

/* This is the function you need to optimize. It takes one
square matrix as input
*/
void superslow(smat_t *a)
{
	int i, j;
	double x1,x2,y1,y2;
	double sum1, sum2;


	// j is the column of a we're computing right now
	for(j = 0; j < a->n; j++)
	{

		// i is the row of a we're computing right now
		for(i = 0; i < a->n; i=i+2)        
		{            
			// First, compute f(A) for the element of a in question
			x1 = get_elt(a,i,j);
			x2 = get_elt(a,i+1,j);
			f(x1,x2,&y1,&y2, i, j);

			// Add this to the value of a we're computing and store it                
			sum1 = get_elt(a, i, j) + y1;
			sum2 = get_elt(a, i+1, j) + y2;
			set_elt(a, i, j, sum1);
			set_elt(a, i+1, j, sum2);            
		}
	}
}
void fast(smat_t *a)
{
  register int i,j,j1;
  register double x1,x2;
  register double *mat = a -> mat;
  register int n = a -> n;
  for(j1 = 0 ; j1 < n ; j1++)
  {
    mat[j1] = 2*mat[j1];
    mat[j1 + n] = 2*mat[j1 + n];
  }
  for(i = 2; i < n - 2 ; i = i + 4)
  {
     register int in = i*n;
     register double cosi = cos(i);
     register double sini = -sin(i);
     register double cos2i = cos(i + 2);
     register double sinus2 = sin(i + 2);
     for(j = 0; j < n; j++)
     {
        register int tmp1 = in + j;
        register int tmp2 = in + j + n;
        x1 = mat[tmp1];
        x2 = mat[tmp2];
        register double cosi1 = cosi + 1;
        mat[tmp1] = x1*cosi1 + sini*x2;
        mat[tmp2] = x2*cosi1 - sini*x1;       
        tmp1 = tmp1 + (n << 1);
        tmp2 = tmp2 + (n << 1);
        x1 = mat[tmp1];
        x2 = mat[tmp2];
        //y1 = cos2i*x1 + sinus2*x2;
        //y2 = -sinus2*x1 + cos2i*x2;
        cosi1 = cos2i + 1;
        mat[tmp1] = x1*cosi1 + sinus2*x2;
        mat[tmp2] = x2*cosi1 - sinus2*x1;


     }
  }
}
void fast1(smat_t *a)
{
  register int i,j;
  register double x1,x2;
  //y1,y2;
  register double *mat = a -> mat;
  register int n = a -> n;
  register int flag = 0;
  for(i = 0; i < n; i = i + 2)
  {
     register int in = i*n;
     register double cosi = cos(i);
     register double sini = sin(i);
     register double sinus = sin(-i);
     for(j = 0; j < n - 1 ; j = j + 2)
     {
        register int tmp1 = in + j;
        register int tmp2 = in + j + n;
        register double cosi1 = cosi + 1;
        int flag1 = 1 - flag;
        register double fs1 = flag1 * sini;
        register double fs2 = flag*sinus;
        register double fsum = fs1 + fs2;
        x1 = mat[tmp1];
        x2 = mat[tmp2];
        mat[tmp1] = x1*cosi1 + fsum * x2;
        mat[tmp2] = x2*cosi1 - fsum * x1;
       /* x1 = mat[tmp1+1];
        x2 = mat[tmp2+1];
        mat[tmp1+1] = x1*cosi1 + fsum * x2;
        mat[tmp2+1] = x2*cosi1 - fsum * x1;*/

     }
     flag++;
     flag = flag%2;
  }
}   
void fast2(smat_t *a)
{
  register int i,j;
  register double x1,x2;
  register double *mat = a -> mat;
  register int n = a -> n;
  for(i = 0; i < n - 2; i = i + 4)
  {
     register int in = i*n;
     register double cosi = cos(i);
     register double sini = sin(i);
     register double cos2i = cos(i + 2);
     register double sinus2 = -sin(i + 2);
     for(j = 0; j < n - 1; j = j+2)
     {
        register int tmp1 = in + j;
        register int tmp2 = tmp1 + n;
        x1 = mat[tmp1];
        x2 = mat[tmp2];
        register double cosi1 = cosi + 1;
        mat[tmp1] = x1*cosi1 + sini*x2;
        mat[tmp2] = x2*cosi1 - sini*x1;
        tmp1 = tmp1 + (n << 1);
        tmp2 = tmp2 + (n << 1);
        x1 = mat[tmp1];
        x2 = mat[tmp2];
        cosi1 = cos2i + 1;
        mat[tmp1] = x1*cosi1 + sinus2*x2;
        mat[tmp2] = x2*cosi1 - sinus2*x1;

 
     }
  }
}
void fast4(smat_t * a)
{
  register int i,j;
  register double x1,x2;
  register double *mat = a -> mat;
  register int n = a -> n;
  for(i = 0; i < n - 2; i = i + 4)
  {
     register int in = i*n;
     register double cosi = cos(i);
     register double sini = sin(i);
     register double cos2i = cos(i + 2);
     register double sinus2 = -sin(i + 2);
     for(j = 0; j < n; j++)
     {
        register int tmp1 = in + j;
        register int tmp2 = tmp1 + n;
        x1 = mat[tmp1];
        x2 = mat[tmp2];
        register double cosi1 = cosi + 1;
        mat[tmp1] = x1*cosi1 + sini*x2;
        mat[tmp2] = x2*cosi1 - sini*x1;
        tmp1 = tmp1 + (n << 1);
        tmp2 = tmp2 + (n << 1);
        x1 = mat[tmp1];
        x2 = mat[tmp2];
        cosi1 = cos2i + 1;
        mat[tmp1] = x1*cosi1 + sinus2*x2;
        mat[tmp2] = x2*cosi1 - sinus2*x1;


     }
  }
}
void fast3(smat_t * a)
{
  register int i,j,i1,j1;
  register double x1,x2,y1,y2;
  register double *mat = a -> mat;
  register int n = a -> n;
  for(i = 0; i < n; i = i + 4)
  {
     register int in = i*n;
     register double cosi = cos(i);
     register double sini = sin(i);
     //register double sinus = sin(-i);
     for(j = 0; j < n - 1; j= j + 2)
     {
       /* register int tmp1 = in + j;
        register int tmp2 = tmp1 + n;
        x1 = *(mat + tmp1);
        x2 = *(mat + tmp2);
        y1 = cosi*x1 + sini*x2;
        y2 = -sini*x1 + cosi*x2;
        *(mat + tmp1) = x1 + y1;
        *(mat + tmp2) = x2 + y2;*/
        register int tmp1 = in + j;
        register int tmp2 = tmp1 + n;
        x1 = mat[tmp1];
        x2 = mat[tmp2];
        y1 = cosi*x1 + sini*x2;
        mat[tmp1] = mat[tmp1] + y1;
        y2 = -sini*x1 + cosi*x2;
        mat[tmp2] = mat[tmp2] + y2;
        tmp1 = tmp1 + 1;
        tmp2 = tmp2 + 1;
        x1 = mat[tmp1];
        x2 = mat[tmp2];
        y1 = cosi*x1 + sini*x2;
        mat[tmp1] = x1 + y1;
        y2 = -sini*x1 + cosi*x2;
        mat[tmp2] = x2 + y2;
     }
  }
  for(i1 = 2; i1 < n; i1 = i1 + 4)
  {
     register int in = i1 * n;
     register double cosi = cos(i1);
     //register double sini = sin(i);
     register double sinus = sin(-i1);
     for(j1 = 0; j1 < n - 1; j1=j1 + 2)
     {
        register int tmp1 = in + j1;
        register int tmp2 = tmp1 + n;
        x1 = mat[tmp1];
        x2 = mat[tmp2];
        y1 = cosi*x1 + sinus*x2;
        mat[tmp1] = mat[tmp1] + y1;
        y2 = -sinus*x1 + cosi*x2;
        mat[tmp2] = mat[tmp2] + y2;
        tmp1 = tmp1 + 1;
        tmp2 = tmp2 + 1;
        x1 = mat[tmp1];
        x2 = mat[tmp2];
        y1 = cosi*x1 + sinus*x2;
        mat[tmp1] = x1 + y1;
        y2 = -sinus*x1 + cosi*x2;
        //mat[tmp1] = mat[tmp1] + y1;
        mat[tmp2] = x2 + y2;

     }
  }

}


/* 
* Called by the driver to register your functions
* Use add_function(func, description) to add your own functions
*/
void register_functions()
{
	// Registers comp_superslow with the driver
	add_function(&superslow, "superslow: original function");
        add_function(&fast,"fast: optimized version 1");
        add_function(&fast2,"fast: optimized version 2");
        add_function(&fast3,"fast: optimized version 3");
        add_function(&fast1,"fast: improvised optimized version 1");
        add_function(&fast4,"fast: ");
//	add_function(&fast, "fast: optimized version 1");
	//Add your functions here
	//add_function(&superslow2, "superslow: Optimization X");


}
